import { useMemo, useState } from "react";
import titimiLogo from "./assets/titimi-logo.png";

type Page =
  | "dashboard"
  | "appointments"
  | "schedule"
  | "patients"
  | "consultations"
  | "records"
  | "prescriptions"
  | "profile";
type AppointmentStatus = "Chờ xác nhận" | "Đã xác nhận" | "Hoàn thành" | "Đã hủy";

type Appointment = {
  id: string;
  patientId: string;
  patient: string;
  date: string;
  time: string;
  reason: string;
  type: string;
  modality?: "Khám trực tiếp" | "Tư vấn trực tuyến";
  status: AppointmentStatus;
};

type Patient = {
  id: string;
  name: string;
  gender: string;
  dob: string;
  phone: string;
  email: string;
  latest: string;
  blood: string;
  allergies: string;
};

type Medication = {
  name: string;
  dosage: string;
  frequency: string;
  duration: string;
  instructions: string;
};

const navItems: { id: Page; label: string; icon: IconName }[] = [
  { id: "dashboard", label: "Dashboard", icon: "grid" },
  { id: "appointments", label: "Lịch hẹn", icon: "calendar" },
  { id: "schedule", label: "Lịch làm việc", icon: "clock" },
  { id: "patients", label: "Bệnh nhân", icon: "users" },
  { id: "consultations", label: "Phiên khám", icon: "stethoscope" },
  { id: "records", label: "Hồ sơ bệnh án", icon: "file" },
  { id: "prescriptions", label: "Đơn thuốc", icon: "pill" },
  { id: "profile", label: "Hồ sơ cá nhân", icon: "user" },
];

const initialAppointments: Appointment[] = [
  {
    id: "LH-240612",
    patientId: "BN-1024",
    patient: "Trần Thu Hà",
    date: "2025-06-18",
    time: "08:30",
    reason: "Đau đầu kéo dài, mất ngủ",
    type: "Khám mới",
    status: "Đã xác nhận",
  },
  {
    id: "LH-240613",
    patientId: "BN-1031",
    patient: "Nguyễn Hoàng Nam",
    date: "2025-06-18",
    time: "09:15",
    reason: "Tái khám huyết áp",
    type: "Tái khám",
    status: "Chờ xác nhận",
  },
  {
    id: "LH-240614",
    patientId: "BN-0988",
    patient: "Lê Minh Tuấn",
    date: "2025-06-18",
    time: "10:00",
    reason: "Đau dạ dày",
    type: "Khám mới",
    status: "Hoàn thành",
  },
  {
    id: "LH-240615",
    patientId: "BN-1042",
    patient: "Phạm Ngọc Mai",
    date: "2025-06-18",
    time: "10:45",
    reason: "Tái khám sau điều trị",
    type: "Tái khám",
    status: "Đã xác nhận",
  },
  {
    id: "LH-240616",
    patientId: "BN-1017",
    patient: "Vũ Hải Yến",
    date: "2025-06-19",
    time: "08:00",
    reason: "Dị ứng thời tiết",
    type: "Khám mới",
    status: "Chờ xác nhận",
  },
  {
    id: "LH-240617",
    patientId: "BN-1050",
    patient: "Đỗ Quang Huy",
    date: "2025-06-19",
    time: "09:30",
    reason: "Kiểm tra sức khỏe",
    type: "Khám định kỳ",
    status: "Đã xác nhận",
  },
  {
    id: "LH-240618",
    patientId: "BN-1002",
    patient: "Bùi Thanh Lan",
    date: "2025-06-20",
    time: "14:00",
    reason: "Đau lưng kéo dài",
    type: "Tái khám",
    status: "Đã hủy",
  },
];

const patients: Patient[] = [
  {
    id: "BN-1024",
    name: "Trần Thu Hà",
    gender: "Nữ",
    dob: "12/04/1991",
    phone: "090 321 4588",
    email: "thuha@example.com",
    latest: "18/06/2025",
    blood: "O+",
    allergies: "Penicillin",
  },
  {
    id: "BN-1031",
    name: "Nguyễn Hoàng Nam",
    gender: "Nam",
    dob: "28/09/1984",
    phone: "091 775 2031",
    email: "hoangnam@example.com",
    latest: "18/06/2025",
    blood: "A+",
    allergies: "Không ghi nhận",
  },
  {
    id: "BN-0988",
    name: "Lê Minh Tuấn",
    gender: "Nam",
    dob: "03/02/1978",
    phone: "098 220 1198",
    email: "minhtuan@example.com",
    latest: "18/06/2025",
    blood: "B+",
    allergies: "Hải sản",
  },
  {
    id: "BN-1042",
    name: "Phạm Ngọc Mai",
    gender: "Nữ",
    dob: "19/11/1995",
    phone: "093 842 6651",
    email: "ngocmai@example.com",
    latest: "18/06/2025",
    blood: "AB+",
    allergies: "Không ghi nhận",
  },
  {
    id: "BN-1017",
    name: "Vũ Hải Yến",
    gender: "Nữ",
    dob: "07/07/1989",
    phone: "097 314 9270",
    email: "haiyen@example.com",
    latest: "22/05/2025",
    blood: "O-",
    allergies: "Bụi nhà",
  },
  {
    id: "BN-1050",
    name: "Đỗ Quang Huy",
    gender: "Nam",
    dob: "15/01/1990",
    phone: "086 525 1790",
    email: "quanghuy@example.com",
    latest: "03/06/2025",
    blood: "A-",
    allergies: "Không ghi nhận",
  },
];

const consultations = [
  {
    id: "PK-25061801",
    patientId: "BN-0988",
    patient: "Lê Minh Tuấn",
    appointment: "18/06/2025",
    date: "18/06/2025",
    diagnosis: "Viêm dạ dày cấp",
    status: "Hoàn thành",
  },
  {
    id: "PK-25061204",
    patientId: "BN-1024",
    patient: "Trần Thu Hà",
    appointment: "12/06/2025",
    date: "12/06/2025",
    diagnosis: "Rối loạn giấc ngủ",
    status: "Đã lưu",
  },
  {
    id: "PK-25060302",
    patientId: "BN-1050",
    patient: "Đỗ Quang Huy",
    appointment: "03/06/2025",
    date: "03/06/2025",
    diagnosis: "Khám sức khỏe định kỳ",
    status: "Hoàn thành",
  },
  {
    id: "PK-25052203",
    patientId: "BN-1017",
    patient: "Vũ Hải Yến",
    appointment: "22/05/2025",
    date: "22/05/2025",
    diagnosis: "Viêm mũi dị ứng",
    status: "Hoàn thành",
  },
];

const initialPrescriptions = [
  {
    id: "DT-25061801",
    patientId: "BN-0988",
    patient: "Lê Minh Tuấn",
    date: "18/06/2025",
    count: 2,
    status: "Đã kê",
  },
  {
    id: "DT-25061202",
    patientId: "BN-1024",
    patient: "Trần Thu Hà",
    date: "12/06/2025",
    count: 1,
    status: "Đã kê",
  },
  {
    id: "DT-25052201",
    patientId: "BN-1017",
    patient: "Vũ Hải Yến",
    date: "22/05/2025",
    count: 2,
    status: "Hết hạn",
  },
];

type IconName =
  | "grid"
  | "calendar"
  | "calendarPlus"
  | "clock"
  | "users"
  | "stethoscope"
  | "file"
  | "pill"
  | "user"
  | "search"
  | "bell"
  | "chevron"
  | "menu"
  | "x"
  | "arrow"
  | "check"
  | "plus"
  | "trash"
  | "edit"
  | "settings"
  | "logout"
  | "more"
  | "phone"
  | "mail"
  | "heart"
  | "briefcase";

const iconPaths: Record<IconName, React.ReactNode> = {
  grid: (
    <>
      <rect x="3" y="3" width="7" height="7" rx="1" />
      <rect x="14" y="3" width="7" height="7" rx="1" />
      <rect x="3" y="14" width="7" height="7" rx="1" />
      <rect x="14" y="14" width="7" height="7" rx="1" />
    </>
  ),
  calendar: (
    <>
      <rect x="3" y="5" width="18" height="16" rx="2" />
      <path d="M16 3v4M8 3v4M3 10h18" />
    </>
  ),
  calendarPlus: (
    <>
      <rect x="3" y="5" width="18" height="16" rx="2" />
      <path d="M16 3v4M8 3v4M3 10h18M12 13v5M9.5 15.5h5" />
    </>
  ),
  clock: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="M12 7v5l3 2" />
    </>
  ),
  users: (
    <>
      <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
      <circle cx="9" cy="7" r="4" />
      <path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" />
    </>
  ),
  stethoscope: (
    <>
      <path d="M6 3v5a6 6 0 0 0 12 0V3M4 3h4M16 3h4M12 14v2a4 4 0 0 0 8 0v-1" />
      <circle cx="20" cy="12" r="2" />
    </>
  ),
  file: (
    <>
      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
      <path d="M14 2v6h6M8 13h8M8 17h6" />
    </>
  ),
  pill: (
    <>
      <path d="m10.5 20.5-7-7a5 5 0 0 1 7-7l7 7a5 5 0 0 1-7 7Z" />
      <path d="m7 10 7 7" />
    </>
  ),
  user: (
    <>
      <circle cx="12" cy="8" r="4" />
      <path d="M4 21a8 8 0 0 1 16 0" />
    </>
  ),
  search: (
    <>
      <circle cx="11" cy="11" r="7" />
      <path d="m20 20-4-4" />
    </>
  ),
  bell: (
    <>
      <path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4" />
    </>
  ),
  chevron: <path d="m9 18 6-6-6-6" />,
  menu: <path d="M4 6h16M4 12h16M4 18h16" />,
  x: <path d="M18 6 6 18M6 6l12 12" />,
  arrow: <path d="m15 18-6-6 6-6" />,
  check: <path d="m5 12 4 4L19 6" />,
  plus: <path d="M12 5v14M5 12h14" />,
  trash: (
    <>
      <path d="M3 6h18M8 6V4h8v2M19 6l-1 15H6L5 6M10 11v6M14 11v6" />
    </>
  ),
  edit: (
    <>
      <path d="M12 20h9" />
      <path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L8 18l-4 1 1-4Z" />
    </>
  ),
  settings: (
    <>
      <circle cx="12" cy="12" r="3" />
      <path d="M19.4 15a1.7 1.7 0 0 0 .34 1.88l.06.06-2.83 2.83-.06-.06a1.7 1.7 0 0 0-1.88-.34 1.7 1.7 0 0 0-1.03 1.56V21h-4v-.09A1.7 1.7 0 0 0 9 19.37a1.7 1.7 0 0 0-1.88.34l-.06.06-2.83-2.83.06-.06A1.7 1.7 0 0 0 4.63 15 1.7 1.7 0 0 0 3.09 14H3v-4h.09A1.7 1.7 0 0 0 4.63 9a1.7 1.7 0 0 0-.34-1.88l-.06-.06 2.83-2.83.06.06A1.7 1.7 0 0 0 9 4.63 1.7 1.7 0 0 0 10 3.09V3h4v.09A1.7 1.7 0 0 0 15 4.63a1.7 1.7 0 0 0 1.88-.34l.06-.06 2.83 2.83-.06.06A1.7 1.7 0 0 0 19.37 9 1.7 1.7 0 0 0 20.91 10H21v4h-.09A1.7 1.7 0 0 0 19.4 15Z" />
    </>
  ),
  logout: (
    <>
      <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9" />
    </>
  ),
  more: (
    <>
      <circle cx="5" cy="12" r="1" />
      <circle cx="12" cy="12" r="1" />
      <circle cx="19" cy="12" r="1" />
    </>
  ),
  phone: (
    <path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 2 .7 2.8a2 2 0 0 1-.4 2.1L8.1 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2Z" />
  ),
  mail: (
    <>
      <rect x="3" y="5" width="18" height="14" rx="2" />
      <path d="m3 7 9 6 9-6" />
    </>
  ),
  heart: (
    <path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8l1.1 1.1L12 21l7.8-7.5 1.1-1.1a5.5 5.5 0 0 0-.1-7.8Z" />
  ),
  briefcase: (
    <>
      <rect x="3" y="7" width="18" height="13" rx="2" />
      <path d="M8 7V4h8v3M3 12h18M10 12v2h4v-2" />
    </>
  ),
};

function Icon({ name, size = 18 }: { name: IconName; size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {iconPaths[name]}
    </svg>
  );
}

function Avatar({ name, size = "md" }: { name: string; size?: "sm" | "md" | "lg" }) {
  const initials = name
    .split(" ")
    .slice(-2)
    .map((x) => x[0])
    .join("");
  return <span className={`avatar avatar-${size}`}>{initials}</span>;
}

function StatusBadge({ status }: { status: string }) {
  const kind =
    status.includes("Hoàn") || status === "Đã kê"
      ? "success"
      : status.includes("Chờ")
        ? "pending"
        : status.includes("hủy") || status === "Hết hạn"
          ? "danger"
          : "confirmed";
  return (
    <span className={`status status-${kind}`}>
      <i />
      {status}
    </span>
  );
}

function Button({
  children,
  variant = "primary",
  icon,
  onClick,
  type = "button",
  disabled = false,
}: {
  children: React.ReactNode;
  variant?: "primary" | "secondary" | "ghost" | "danger";
  icon?: IconName;
  onClick?: () => void;
  type?: "button" | "submit";
  disabled?: boolean;
}) {
  return (
    <button type={type} className={`btn btn-${variant}`} onClick={onClick} disabled={disabled}>
      {icon && <Icon name={icon} size={16} />}
      {children}
    </button>
  );
}

function Field({
  label,
  value,
  onChange,
  placeholder,
  type = "text",
  required = false,
  disabled = false,
}: {
  label?: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  type?: string;
  required?: boolean;
  disabled?: boolean;
}) {
  return (
    <label className="field">
      {label && (
        <span>
          {label}
          {required && <b> *</b>}
        </span>
      )}
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        required={required}
        disabled={disabled}
      />
    </label>
  );
}

function SearchBox({
  value,
  onChange,
  placeholder,
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder: string;
}) {
  return (
    <label className="search-box">
      <Icon name="search" size={17} />
      <input value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} />
    </label>
  );
}

function Toast({ message, onClose }: { message: string; onClose: () => void }) {
  return (
    <div className="toast">
      <span className="toast-icon">
        <Icon name="check" size={15} />
      </span>
      <div>
        <strong>Thành công</strong>
        <p>{message}</p>
      </div>
      <button onClick={onClose} aria-label="Đóng">
        <Icon name="x" size={16} />
      </button>
    </div>
  );
}

function ConfirmDialog({
  title,
  message,
  onConfirm,
  onClose,
}: {
  title: string;
  message: string;
  onConfirm: () => void;
  onClose: () => void;
}) {
  return (
    <div className="modal-backdrop" onMouseDown={onClose}>
      <div className="modal" onMouseDown={(e) => e.stopPropagation()}>
        <div className="modal-danger">
          <Icon name="trash" />
        </div>
        <h3>{title}</h3>
        <p>{message}</p>
        <div className="modal-actions">
          <Button variant="secondary" onClick={onClose}>
            Quay lại
          </Button>
          <Button variant="danger" onClick={onConfirm}>
            Xác nhận hủy
          </Button>
        </div>
      </div>
    </div>
  );
}

function Sidebar({
  page,
  setPage,
  open,
  onClose,
}: {
  page: Page;
  setPage: (p: Page) => void;
  open: boolean;
  onClose: () => void;
}) {
  const navigate = (p: Page) => {
    setPage(p);
    onClose();
  };
  return (
    <>
      {open && <div className="sidebar-overlay" onClick={onClose} />}
      <aside className={`sidebar ${open ? "sidebar-open" : ""}`}>
        <div className="brand">
          <img className="brand-logo" src={titimiLogo} alt="TiTiMi" />
          <div>
            <strong>TiTiMi</strong>
            <small>DOCTOR PORTAL</small>
          </div>
          <button className="mobile-close" onClick={onClose}>
            <Icon name="x" />
          </button>
        </div>
        <nav>
          <span className="nav-label">KHÔNG GIAN LÀM VIỆC</span>
          {navItems.map((item) => (
            <button
              key={item.id}
              className={page === item.id ? "active" : ""}
              onClick={() => navigate(item.id)}
            >
              <Icon name={item.icon} />
              <span>{item.label}</span>
              {page === item.id && <i />}
            </button>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <button className="side-action">
            <Icon name="settings" />
            <span>Cài đặt</span>
          </button>
          <button className="side-action">
            <Icon name="logout" />
            <span>Đăng xuất</span>
          </button>
          <div className="doctor-mini">
            <Avatar name="Nguyễn Minh Anh" />
            <div>
              <strong>BS. Nguyễn Minh Anh</strong>
              <span>Nội tổng quát</span>
            </div>
            <Icon name="more" />
          </div>
        </div>
      </aside>
    </>
  );
}

function Header({ title, onMenu }: { title: string; onMenu: () => void }) {
  const [profileOpen, setProfileOpen] = useState(false);
  const [notiOpen, setNotiOpen] = useState(false);
  return (
    <header className="topbar">
      <div className="topbar-title">
        <button className="menu-btn" onClick={onMenu}>
          <Icon name="menu" />
        </button>
        <div>
          <span>Doctor Portal&nbsp; / &nbsp;</span>
          <strong>{title}</strong>
        </div>
      </div>
      <div className="header-actions">
        <div className="date-display">
          <Icon name="calendar" size={17} />
          <span>Thứ Tư, 18/06/2025</span>
        </div>
        <div className="dropdown-wrap">
          <button
            className="icon-btn"
            onClick={() => setNotiOpen(!notiOpen)}
            aria-label="Thông báo"
          >
            <Icon name="bell" />
            <i />
          </button>
          {notiOpen && (
            <div className="popover notifications">
              <strong>Thông báo</strong>
              <p>
                <b>Lịch hẹn mới</b>
                <br />
                Nguyễn Hoàng Nam đang chờ xác nhận.
              </p>
              <p>
                <b>Sắp đến giờ khám</b>
                <br />
                Lịch khám lúc 10:45 còn 30 phút.
              </p>
            </div>
          )}
        </div>
        <div className="divider" />
        <div className="dropdown-wrap">
          <button className="profile-trigger" onClick={() => setProfileOpen(!profileOpen)}>
            <Avatar name="Nguyễn Minh Anh" size="sm" />
            <div>
              <strong>Nguyễn Minh Anh</strong>
              <span>Bác sĩ</span>
            </div>
            <Icon name="chevron" size={15} />
          </button>
          {profileOpen && (
            <div className="popover profile-pop">
              <button>
                <Icon name="user" />
                Hồ sơ cá nhân
              </button>
              <button>
                <Icon name="settings" />
                Cài đặt
              </button>
              <button>
                <Icon name="logout" />
                Đăng xuất
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}

function StatCard({
  icon,
  label,
  value,
  note,
  tone,
}: {
  icon: IconName;
  label: string;
  value: number;
  note: string;
  tone: string;
}) {
  return (
    <div className="stat-card">
      <div className={`stat-icon tone-${tone}`}>
        <Icon name={icon} />
      </div>
      <div>
        <span>{label}</span>
        <strong>{value}</strong>
        <small>{note}</small>
      </div>
    </div>
  );
}

function PageHeading({
  eyebrow,
  title,
  description,
  action,
}: {
  eyebrow?: string;
  title: string;
  description: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="page-heading">
      <div>
        {eyebrow && <span>{eyebrow}</span>}
        <h1>{title}</h1>
        <p>{description}</p>
      </div>
      {action}
    </div>
  );
}

function AppointmentTable({
  items,
  onView,
  compact = false,
}: {
  items: Appointment[];
  onView: (a: Appointment) => void;
  compact?: boolean;
}) {
  return (
    <div className="table-wrap">
      <table>
        <thead>
          <tr>
            {!compact && <th>MÃ LỊCH HẸN</th>}
            <th>BỆNH NHÂN</th>
            <th>NGÀY & GIỜ</th>
            <th>LÝ DO KHÁM</th>
            <th>TRẠNG THÁI</th>
            <th />
          </tr>
        </thead>
        <tbody>
          {items.map((a) => (
            <tr key={a.id}>
              {!compact && (
                <td>
                  <b>{a.id}</b>
                </td>
              )}
              <td>
                <div className="patient-cell">
                  <Avatar name={a.patient} size="sm" />
                  <div>
                    <strong>{a.patient}</strong>
                    <span>{a.patientId}</span>
                  </div>
                </div>
              </td>
              <td>
                <strong>{a.time}</strong>
                <span>{a.date.split("-").reverse().join("/")}</span>
              </td>
              <td>
                <strong>{a.reason}</strong>
                <span className={`type-pill ${a.type === "Tái khám" ? "type-follow-up" : ""}`}>
                  {a.type}
                </span>
              </td>
              <td>
                <StatusBadge status={a.status} />
              </td>
              <td>
                <button className="view-link" onClick={() => onView(a)}>
                  Chi tiết <Icon name="chevron" size={14} />
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {items.length === 0 && <div className="empty">Không tìm thấy lịch hẹn phù hợp.</div>}
    </div>
  );
}

function Dashboard({
  appointments,
  navigate,
  viewAppointment,
}: {
  appointments: Appointment[];
  navigate: (p: Page) => void;
  viewAppointment: (a: Appointment) => void;
}) {
  const today = appointments.filter((a) => a.date === "2025-06-18");
  return (
    <div className="page">
      <section className="welcome">
        <div>
          <span>THỨ TƯ, 18 THÁNG 6</span>
          <h1>Xin chào, Bác sĩ Nguyễn Minh Anh</h1>
          <p>
            Hôm nay bác sĩ có <b>{today.length} lịch hẹn</b>. Ca khám tiếp theo bắt đầu lúc 08:30.
          </p>
        </div>
        <div className="welcome-calendar">
          <Icon name="calendar" />
          <div>
            <span>LỊCH HÔM NAY</span>
            <strong>18</strong>
            <small>Tháng 06, 2025</small>
          </div>
        </div>
      </section>
      <div className="stats-grid">
        <StatCard
          icon="calendar"
          label="Lịch hẹn hôm nay"
          value={today.length}
          note="4 ca còn lại"
          tone="teal"
        />
        <StatCard
          icon="clock"
          label="Chờ xác nhận"
          value={appointments.filter((a) => a.status === "Chờ xác nhận").length}
          note="Cần xử lý"
          tone="amber"
        />
        <StatCard
          icon="check"
          label="Đã hoàn thành"
          value={12}
          note="+8% so với tuần trước"
          tone="green"
        />
        <StatCard
          icon="users"
          label="Tổng bệnh nhân"
          value={128}
          note="+6 bệnh nhân tháng này"
          tone="blue"
        />
      </div>
      <div className="dashboard-grid">
        <section className="card appointments-card">
          <div className="card-header">
            <div>
              <h2>Lịch hẹn hôm nay</h2>
              <p>Các lịch khám trong ngày của bác sĩ</p>
            </div>
            <button onClick={() => navigate("appointments")}>
              Xem tất cả <Icon name="chevron" size={14} />
            </button>
          </div>
          <AppointmentTable items={today.slice(0, 4)} onView={viewAppointment} compact />
        </section>
        <aside className="dashboard-side">
          <section className="card upcoming">
            <div className="card-header">
              <div>
                <h2>Sắp tới</h2>
                <p>Lịch khám tiếp theo</p>
              </div>
            </div>
            {today.slice(0, 3).map((a, i) => (
              <button key={a.id} className="upcoming-item" onClick={() => viewAppointment(a)}>
                <div className={i === 0 ? "time active-time" : "time"}>
                  <strong>{a.time}</strong>
                  <span>{i === 0 ? "Sắp tới" : "Hôm nay"}</span>
                </div>
                <div>
                  <strong>{a.patient}</strong>
                  <span>{a.reason}</span>
                </div>
                <Icon name="chevron" size={15} />
              </button>
            ))}
          </section>
          <section className="card quick">
            <div className="card-header">
              <div>
                <h2>Truy cập nhanh</h2>
              </div>
            </div>
            <button onClick={() => navigate("appointments")}>
              <span>
                <Icon name="calendar" />
              </span>
              <div>
                <strong>Tất cả lịch hẹn</strong>
                <small>Quản lý và cập nhật lịch khám</small>
              </div>
              <Icon name="chevron" />
            </button>
            <button onClick={() => navigate("schedule")}>
              <span>
                <Icon name="clock" />
              </span>
              <div>
                <strong>Lịch làm việc</strong>
                <small>Xem lịch hôm nay</small>
              </div>
              <Icon name="chevron" />
            </button>
            <button onClick={() => navigate("patients")}>
              <span>
                <Icon name="users" />
              </span>
              <div>
                <strong>Danh sách bệnh nhân</strong>
                <small>128 hồ sơ bệnh nhân</small>
              </div>
              <Icon name="chevron" />
            </button>
          </section>
        </aside>
      </div>
    </div>
  );
}

function AppointmentsPage({
  appointments,
  setAppointments,
  viewAppointment,
  toast,
}: {
  appointments: Appointment[];
  setAppointments: React.Dispatch<React.SetStateAction<Appointment[]>>;
  viewAppointment: (a: Appointment) => void;
  toast: (m: string) => void;
}) {
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("Tất cả");
  const [date, setDate] = useState("");
  const [cancelId, setCancelId] = useState<string | null>(null);
  const filtered = appointments.filter(
    (a) =>
      (status === "Tất cả" || a.status === status) &&
      (!date || a.date === date) &&
      `${a.patient} ${a.patientId} ${a.id}`.toLowerCase().includes(search.toLowerCase()),
  );
  const update = (id: string, next: AppointmentStatus) => {
    setAppointments((xs) => xs.map((a) => (a.id === id ? { ...a, status: next } : a)));
    toast(next === "Đã xác nhận" ? "Đã xác nhận lịch hẹn." : "Đã hủy lịch hẹn.");
    setCancelId(null);
  };
  return (
    <div className="page">
      <PageHeading
        title="Quản lý lịch hẹn"
        description="Theo dõi và xử lý các lịch hẹn với bệnh nhân."
      />
      <div className="tabs">
        {["Tất cả", "Chờ xác nhận", "Đã xác nhận", "Hoàn thành", "Đã hủy"].map((x) => (
          <button className={status === x ? "active" : ""} onClick={() => setStatus(x)} key={x}>
            {x}
            <span>
              {x === "Tất cả"
                ? appointments.length
                : appointments.filter((a) => a.status === x).length}
            </span>
          </button>
        ))}
      </div>
      <section className="card">
        <div className="filter-bar">
          <SearchBox
            value={search}
            onChange={setSearch}
            placeholder="Tìm theo tên, mã bệnh nhân..."
          />
          <label className="select-field">
            <Icon name="calendar" size={17} />
            <input
              aria-label="Lọc theo ngày"
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
            />
          </label>
          <select
            value={status}
            onChange={(e) => setStatus(e.target.value)}
            aria-label="Trạng thái"
          >
            <option>Tất cả</option>
            <option>Chờ xác nhận</option>
            <option>Đã xác nhận</option>
            <option>Hoàn thành</option>
            <option>Đã hủy</option>
          </select>
          {(date || search) && (
            <Button
              variant="ghost"
              onClick={() => {
                setDate("");
                setSearch("");
              }}
            >
              Xóa lọc
            </Button>
          )}
        </div>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>MÃ LỊCH HẸN</th>
                <th>BỆNH NHÂN</th>
                <th>NGÀY & GIỜ</th>
                <th>LÝ DO KHÁM</th>
                <th>TRẠNG THÁI</th>
                <th>THAO TÁC</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((a) => (
                <tr key={a.id}>
                  <td>
                    <b>{a.id}</b>
                  </td>
                  <td>
                    <div className="patient-cell">
                      <Avatar name={a.patient} size="sm" />
                      <div>
                        <strong>{a.patient}</strong>
                        <span>{a.patientId}</span>
                      </div>
                    </div>
                  </td>
                  <td>
                    <strong>{a.date.split("-").reverse().join("/")}</strong>
                    <span>{a.time}</span>
                  </td>
                  <td>
                    <strong>{a.reason}</strong>
                    <span className={`type-pill ${a.type === "Tái khám" ? "type-follow-up" : ""}`}>
                      {a.type}
                    </span>
                  </td>
                  <td>
                    <StatusBadge status={a.status} />
                  </td>
                  <td>
                    <div className="row-actions">
                      <button onClick={() => viewAppointment(a)}>Xem</button>
                      {a.status === "Chờ xác nhận" && (
                        <button
                          className="confirm-link"
                          onClick={() => update(a.id, "Đã xác nhận")}
                        >
                          Xác nhận
                        </button>
                      )}
                      {a.status !== "Hoàn thành" && a.status !== "Đã hủy" && (
                        <button className="cancel-link" onClick={() => setCancelId(a.id)}>
                          Hủy
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filtered.length === 0 && (
            <div className="empty">Không có lịch hẹn phù hợp với bộ lọc.</div>
          )}
        </div>
      </section>
      {cancelId && (
        <ConfirmDialog
          title="Hủy lịch hẹn?"
          message="Hành động này sẽ cập nhật trạng thái lịch hẹn thành Đã hủy. Bạn có chắc chắn muốn tiếp tục?"
          onClose={() => setCancelId(null)}
          onConfirm={() => update(cancelId, "Đã hủy")}
        />
      )}
    </div>
  );
}

function AppointmentDetail({
  appointment,
  setAppointments,
  back,
  toast,
  startConsultation,
}: {
  appointment: Appointment;
  setAppointments: React.Dispatch<React.SetStateAction<Appointment[]>>;
  back: () => void;
  toast: (m: string) => void;
  startConsultation: () => void;
}) {
  const [item, setItem] = useState(appointment);
  const [cancel, setCancel] = useState(false);
  const patient = patients.find((p) => p.id === item.patientId) || patients[0];
  const update = (status: AppointmentStatus) => {
    setItem({ ...item, status });
    setAppointments((xs) => xs.map((a) => (a.id === item.id ? { ...a, status } : a)));
    toast(`Đã cập nhật lịch hẹn thành "${status}".`);
    setCancel(false);
  };
  return (
    <div className="page detail-page">
      <button className="back-link" onClick={back}>
        <Icon name="arrow" /> Quay lại danh sách lịch hẹn
      </button>
      <PageHeading
        eyebrow="CHI TIẾT LỊCH HẸN"
        title={item.id}
        description="Thông tin lịch hẹn và bệnh nhân."
        action={<StatusBadge status={item.status} />}
      />
      <div className="detail-layout">
        <main>
          <section className="card detail-card">
            <div className="section-title">
              <span>
                <Icon name="calendar" />
              </span>
              <div>
                <h2>Thông tin lịch hẹn</h2>
                <p>Chi tiết về thời gian và nội dung khám</p>
              </div>
            </div>
            <div className="info-grid">
              <Info label="Ngày hẹn" value={item.date.split("-").reverse().join("/")} />
              <Info label="Thời gian" value={item.time} />
              <Info label="Hình thức" value={item.modality || "Khám trực tiếp"} />
              <Info label="Loại lịch hẹn" value={item.type} />
              <Info label="Lý do khám" value={item.reason} wide />
              <Info label="Trạng thái" value={item.status} />
            </div>
          </section>
          <section className="card detail-card">
            <div className="section-title">
              <span>
                <Icon name="user" />
              </span>
              <div>
                <h2>Thông tin bệnh nhân</h2>
                <p>Thông tin cá nhân và liên hệ</p>
              </div>
            </div>
            <div className="patient-hero">
              <Avatar name={patient.name} size="lg" />
              <div>
                <h3>{patient.name}</h3>
                <p>
                  {patient.id} · Nhóm máu {patient.blood}
                </p>
              </div>
            </div>
            <div className="info-grid">
              <Info label="Giới tính" value={patient.gender} />
              <Info label="Ngày sinh" value={patient.dob} />
              <Info label="Số điện thoại" value={patient.phone} />
              <Info label="Email" value={patient.email} />
            </div>
          </section>
        </main>
        <aside className="card action-panel">
          <h2>Thao tác</h2>
          <p>Cập nhật trạng thái hoặc bắt đầu phiên khám.</p>
          {item.status === "Chờ xác nhận" && (
            <Button icon="check" onClick={() => update("Đã xác nhận")}>
              Xác nhận lịch hẹn
            </Button>
          )}
          {item.status !== "Hoàn thành" && item.status !== "Đã hủy" && (
            <Button variant="secondary" icon="stethoscope" onClick={startConsultation}>
              Mở phiếu khám
            </Button>
          )}
          {item.status === "Đã xác nhận" && (
            <Button variant="secondary" icon="check" onClick={() => update("Hoàn thành")}>
              Đánh dấu hoàn thành
            </Button>
          )}
          {item.status !== "Đã hủy" && item.status !== "Hoàn thành" && (
            <Button variant="ghost" icon="x" onClick={() => setCancel(true)}>
              Hủy lịch hẹn
            </Button>
          )}
          <div className="action-note">
            <Icon name="file" />
            <p>Mọi thay đổi trạng thái đều được lưu trong phiên làm việc này.</p>
          </div>
        </aside>
      </div>
      {cancel && (
        <ConfirmDialog
          title="Hủy lịch hẹn?"
          message={`Bạn sắp hủy lịch hẹn ${item.id} của ${item.patient}.`}
          onClose={() => setCancel(false)}
          onConfirm={() => update("Đã hủy")}
        />
      )}
    </div>
  );
}

function Info({ label, value, wide = false }: { label: string; value: string; wide?: boolean }) {
  return (
    <div className={`info ${wide ? "wide" : ""}`}>
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  );
}

function SchedulePage({
  appointments,
  viewAppointment,
}: {
  appointments: Appointment[];
  viewAppointment: (a: Appointment) => void;
}) {
  const [view, setView] = useState("Tuần");
  const [weekOffset, setWeekOffset] = useState(0);
  const [selectedDay, setSelectedDay] = useState(18);
  const week = [16, 17, 18, 19, 20, 21, 22].map((d) => d + weekOffset * 7);
  const mapped: Record<number, Appointment[]> = {
    18: appointments.filter((a) => a.date === "2025-06-18"),
    19: appointments.filter((a) => a.date === "2025-06-19"),
    20: appointments.filter((a) => a.date === "2025-06-20"),
  };
  return (
    <div className="page">
      <PageHeading
        title="Lịch làm việc"
        description="Theo dõi lịch khám và khung giờ làm việc của bác sĩ."
      />
      <div className="calendar-toolbar">
        <div>
          <Button variant="secondary" onClick={() => setWeekOffset((x) => x - 1)}>
            <Icon name="arrow" />
          </Button>
          <Button variant="secondary" onClick={() => setWeekOffset(0)}>
            Hôm nay
          </Button>
          <Button variant="secondary" onClick={() => setWeekOffset((x) => x + 1)}>
            <span className="flip">
              <Icon name="arrow" />
            </span>
          </Button>
          <strong>16 – 22 tháng 06, 2025</strong>
        </div>
        <div className="segmented">
          {["Ngày", "Tuần", "Tháng"].map((x) => (
            <button key={x} onClick={() => setView(x)} className={view === x ? "active" : ""}>
              {x}
            </button>
          ))}
        </div>
      </div>
      <div className="schedule-layout">
        <section className="card calendar-card">
          <div className="week-head">
            <span>GMT+7</span>
            {week.map((d, i) => (
              <button
                key={d}
                className={selectedDay === d ? "today" : ""}
                onClick={() => setSelectedDay(d)}
              >
                <small>{["T2", "T3", "T4", "T5", "T6", "T7", "CN"][i]}</small>
                <strong>{d}</strong>
              </button>
            ))}
          </div>
          <div className="week-body">
            {["08:00", "09:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00"].map(
              (time, row) => (
                <div className="time-row" key={time}>
                  <span>{time}</span>
                  {week.map((d) => (
                    <div className="day-cell" key={d}>
                      {(mapped[d] || [])
                        .filter((a) => Number(a.time.slice(0, 2)) === 8 + row)
                        .map((a) => (
                          <button
                            key={a.id}
                            className={`event event-${a.status === "Hoàn thành" ? "done" : a.status === "Chờ xác nhận" ? "pending" : a.status === "Đã hủy" ? "cancelled" : "confirmed"}`}
                            onClick={() => viewAppointment(a)}
                          >
                            <b>{a.time}</b>
                            <span>{a.patient}</span>
                          </button>
                        ))}
                    </div>
                  ))}
                </div>
              ),
            )}
          </div>
        </section>
        <aside>
          <section className="card day-summary">
            <h2>Lịch ngày {selectedDay}/06</h2>
            <p>{(mapped[selectedDay] || []).length} lịch hẹn</p>
            {(mapped[selectedDay] || []).map((a) => (
              <button key={a.id} onClick={() => viewAppointment(a)}>
                <time>{a.time}</time>
                <div>
                  <strong>{a.patient}</strong>
                  <span>{a.reason}</span>
                </div>
                <StatusBadge status={a.status} />
              </button>
            ))}
            {!(mapped[selectedDay] || []).length && (
              <div className="empty-small">Không có lịch hẹn.</div>
            )}
          </section>
          <section className="card slots">
            <h2>Khung giờ trống</h2>
            <div>
              {["11:30", "13:30", "15:00", "16:30"].map((x) => (
                <span key={x}>{x}</span>
              ))}
            </div>
          </section>
        </aside>
      </div>
    </div>
  );
}

function PatientsPage({ openPatient }: { openPatient: (p: Patient) => void }) {
  const [search, setSearch] = useState("");
  const filtered = patients.filter((p) =>
    `${p.name} ${p.id}`.toLowerCase().includes(search.toLowerCase()),
  );
  return (
    <div className="page">
      <PageHeading
        title="Danh sách bệnh nhân"
        description="Tra cứu và quản lý hồ sơ bệnh nhân đang theo dõi."
      />
      <section className="card">
        <div className="filter-bar">
          <SearchBox
            value={search}
            onChange={setSearch}
            placeholder="Tìm theo tên hoặc mã bệnh nhân..."
          />
          <span className="result-count">{filtered.length} bệnh nhân</span>
        </div>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>BỆNH NHÂN</th>
                <th>GIỚI TÍNH</th>
                <th>NGÀY SINH</th>
                <th>LIÊN HỆ</th>
                <th>LẦN KHÁM GẦN NHẤT</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {filtered.map((p) => (
                <tr key={p.id}>
                  <td>
                    <div className="patient-cell">
                      <Avatar name={p.name} size="sm" />
                      <div>
                        <strong>{p.name}</strong>
                        <span>{p.id}</span>
                      </div>
                    </div>
                  </td>
                  <td>{p.gender}</td>
                  <td>{p.dob}</td>
                  <td>
                    <strong>{p.phone}</strong>
                    <span>{p.email}</span>
                  </td>
                  <td>{p.latest}</td>
                  <td>
                    <button className="view-link" onClick={() => openPatient(p)}>
                      Xem hồ sơ <Icon name="chevron" size={14} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}

function PatientDetail({
  patient,
  back,
  openConsultations,
  openRecords,
  openPrescriptions,
}: {
  patient: Patient;
  back: () => void;
  openConsultations: () => void;
  openRecords: () => void;
  openPrescriptions: () => void;
}) {
  const [tab, setTab] = useState("Tổng quan");
  const tabs = ["Tổng quan", "Lịch sử hẹn", "Phiên khám", "Đơn thuốc"];
  return (
    <div className="page detail-page">
      <button className="back-link" onClick={back}>
        <Icon name="arrow" /> Quay lại danh sách bệnh nhân
      </button>
      <section className="card patient-profile-head">
        <Avatar name={patient.name} size="lg" />
        <div>
          <span>{patient.id}</span>
          <h1>{patient.name}</h1>
          <p>
            {patient.gender} · {patient.dob} · Nhóm máu {patient.blood}
          </p>
        </div>
        <div className="profile-contact">
          <span>
            <Icon name="phone" />
            {patient.phone}
          </span>
          <span>
            <Icon name="mail" />
            {patient.email}
          </span>
        </div>
      </section>
      <div className="tabs detail-tabs">
        {tabs.map((x) => (
          <button className={tab === x ? "active" : ""} onClick={() => setTab(x)} key={x}>
            {x}
          </button>
        ))}
      </div>
      {tab === "Tổng quan" && (
        <div className="two-col">
          <section className="card detail-card">
            <div className="section-title">
              <span>
                <Icon name="user" />
              </span>
              <div>
                <h2>Thông tin cơ bản</h2>
              </div>
            </div>
            <div className="info-grid">
              <Info label="Họ và tên" value={patient.name} />
              <Info label="Mã bệnh nhân" value={patient.id} />
              <Info label="Giới tính" value={patient.gender} />
              <Info label="Ngày sinh" value={patient.dob} />
              <Info label="Số điện thoại" value={patient.phone} />
              <Info label="Email" value={patient.email} />
            </div>
          </section>
          <section className="card detail-card">
            <div className="section-title">
              <span>
                <Icon name="heart" />
              </span>
              <div>
                <h2>Thông tin y khoa</h2>
              </div>
            </div>
            <div className="medical-summary">
              <div>
                <span>Nhóm máu</span>
                <strong>{patient.blood}</strong>
              </div>
              <div>
                <span>Dị ứng đã ghi nhận</span>
                <strong>{patient.allergies}</strong>
              </div>
              <div>
                <span>Bệnh nền</span>
                <strong>Chưa ghi nhận</strong>
              </div>
            </div>
            <Button variant="secondary" onClick={openRecords}>
              Xem hồ sơ bệnh án
            </Button>
          </section>
        </div>
      )}
      {tab === "Lịch sử hẹn" && (
        <section className="card list-panel">
          <h2>Lịch sử lịch hẹn</h2>
          {initialAppointments
            .filter((a) => a.patientId === patient.id)
            .map((a) => (
              <div className="list-row" key={a.id}>
                <span className="list-icon">
                  <Icon name="calendar" />
                </span>
                <div>
                  <strong>
                    {a.date.split("-").reverse().join("/")} · {a.time}
                  </strong>
                  <p>{a.reason}</p>
                </div>
                <StatusBadge status={a.status} />
              </div>
            ))}
        </section>
      )}
      {tab === "Phiên khám" && (
        <section className="card list-panel">
          <div className="card-header">
            <h2>Phiên khám trước đây</h2>
            <Button variant="secondary" onClick={openConsultations}>
              Xem tất cả
            </Button>
          </div>
          {consultations
            .filter((c) => c.patientId === patient.id)
            .map((c) => (
              <div className="list-row" key={c.id}>
                <span className="list-icon">
                  <Icon name="stethoscope" />
                </span>
                <div>
                  <strong>
                    {c.id} · {c.date}
                  </strong>
                  <p>{c.diagnosis}</p>
                </div>
                <StatusBadge status={c.status} />
              </div>
            ))}
        </section>
      )}
      {tab === "Đơn thuốc" && (
        <section className="card list-panel">
          <div className="card-header">
            <h2>Đơn thuốc</h2>
            <Button variant="secondary" onClick={openPrescriptions}>
              Quản lý đơn thuốc
            </Button>
          </div>
          {initialPrescriptions
            .filter((r) => r.patientId === patient.id)
            .map((r) => (
              <div className="list-row" key={r.id}>
                <span className="list-icon">
                  <Icon name="pill" />
                </span>
                <div>
                  <strong>
                    {r.id} · {r.date}
                  </strong>
                  <p>{r.count} loại thuốc</p>
                </div>
                <StatusBadge status={r.status} />
              </div>
            ))}
        </section>
      )}
    </div>
  );
}

function ConsultationsPage({
  selected,
  setSelected,
  toast,
  createFollowUp,
}: {
  selected: string | null;
  setSelected: (id: string | null) => void;
  toast: (m: string) => void;
  createFollowUp: (appointment: Appointment) => void;
}) {
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("Tất cả");
  const [date, setDate] = useState("");
  if (selected) {
    const c = consultations.find((x) => x.id === selected) || consultations[0];
    return (
      <ConsultationDetail
        consultation={c}
        back={() => setSelected(null)}
        toast={toast}
        createFollowUp={createFollowUp}
      />
    );
  }
  const displayDate = date ? date.split("-").reverse().join("/") : "";
  const filtered = consultations.filter(
    (c) =>
      `${c.id} ${c.patient}`.toLowerCase().includes(search.toLowerCase()) &&
      (status === "Tất cả" || c.status === status) &&
      (!date || c.date === displayDate),
  );
  return (
    <div className="page">
      <PageHeading
        title="Quản lý phiên khám"
        description="Xem và cập nhật các phiếu khám của bệnh nhân."
      />
      <section className="card">
        <div className="filter-bar">
          <SearchBox
            value={search}
            onChange={setSearch}
            placeholder="Tìm bệnh nhân hoặc mã phiên khám..."
          />
          <input
            className="date-input"
            type="date"
            aria-label="Lọc ngày"
            value={date}
            onChange={(e) => setDate(e.target.value)}
          />
          <select value={status} onChange={(e) => setStatus(e.target.value)}>
            <option>Tất cả</option>
            <option>Hoàn thành</option>
            <option>Đã lưu</option>
          </select>
          {(date || search) && (
            <Button
              variant="ghost"
              onClick={() => {
                setDate("");
                setSearch("");
              }}
            >
              Xóa lọc
            </Button>
          )}
        </div>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>MÃ PHIÊN KHÁM</th>
                <th>BỆNH NHÂN</th>
                <th>NGÀY HẸN</th>
                <th>NGÀY KHÁM</th>
                <th>CHẨN ĐOÁN TÓM TẮT</th>
                <th>TRẠNG THÁI</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {filtered.map((c) => (
                <tr key={c.id}>
                  <td>
                    <b>{c.id}</b>
                  </td>
                  <td>
                    <div className="patient-cell">
                      <Avatar name={c.patient} size="sm" />
                      <div>
                        <strong>{c.patient}</strong>
                        <span>{c.patientId}</span>
                      </div>
                    </div>
                  </td>
                  <td>{c.appointment}</td>
                  <td>{c.date}</td>
                  <td>{c.diagnosis}</td>
                  <td>
                    <StatusBadge status={c.status} />
                  </td>
                  <td>
                    <button className="view-link" onClick={() => setSelected(c.id)}>
                      Mở phiếu <Icon name="chevron" size={14} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filtered.length === 0 && <div className="empty">Không tìm thấy phiên khám phù hợp.</div>}
        </div>
      </section>
    </div>
  );
}

function ConsultationDetail({
  consultation,
  back,
  toast,
  createFollowUp,
}: {
  consultation: (typeof consultations)[0];
  back: () => void;
  toast: (m: string) => void;
  createFollowUp: (appointment: Appointment) => void;
}) {
  const [followUpOpen, setFollowUpOpen] = useState(false);
  const [form, setForm] = useState({
    complaint: "Đau âm ỉ vùng thượng vị, tăng sau khi ăn.",
    symptoms: "Đầy hơi, ợ chua, không sốt. Triệu chứng xuất hiện khoảng 5 ngày.",
    diagnosis: consultation.diagnosis,
    notes: "Bệnh nhân tỉnh táo, tiếp xúc tốt. Bụng mềm, ấn đau nhẹ vùng thượng vị.",
    plan: "Điều chỉnh chế độ ăn, hạn chế đồ cay nóng và theo dõi trong 7 ngày.",
  });
  const set = (key: keyof typeof form, value: string) => setForm({ ...form, [key]: value });
  return (
    <div className="page detail-page">
      <button className="back-link" onClick={back}>
        <Icon name="arrow" /> Quay lại danh sách phiên khám
      </button>
      <PageHeading
        eyebrow="PHIÊN KHÁM"
        title={consultation.id}
        description={`Bệnh nhân ${consultation.patient} · ${consultation.date}`}
        action={<StatusBadge status={consultation.status} />}
      />
      <form
        onSubmit={(e) => {
          e.preventDefault();
          toast("Đã lưu nội dung phiếu khám.");
        }}
      >
        <div className="consult-layout">
          <main>
            <section className="card form-card">
              <h2>Thông tin thăm khám</h2>
              <p>Ghi nhận thông tin lâm sàng trong phiên khám.</p>
              <label className="field">
                <span>Lý do khám</span>
                <textarea
                  value={form.complaint}
                  onChange={(e) => set("complaint", e.target.value)}
                />
              </label>
              <label className="field">
                <span>Triệu chứng</span>
                <textarea value={form.symptoms} onChange={(e) => set("symptoms", e.target.value)} />
              </label>
              <label className="field">
                <span>
                  Chẩn đoán <b>*</b>
                </span>
                <textarea
                  value={form.diagnosis}
                  required
                  onChange={(e) => set("diagnosis", e.target.value)}
                />
              </label>
              <label className="field">
                <span>Ghi chú của bác sĩ</span>
                <textarea value={form.notes} onChange={(e) => set("notes", e.target.value)} />
              </label>
              <label className="field">
                <span>Kế hoạch điều trị</span>
                <textarea value={form.plan} onChange={(e) => set("plan", e.target.value)} />
              </label>
              <div className="follow-up-action">
                <div>
                  <strong>Lịch tái khám</strong>
                  <span>Tạo lịch hẹn tiếp theo cho bệnh nhân sau phiên khám này.</span>
                </div>
                <Button
                  variant="secondary"
                  icon="calendarPlus"
                  onClick={() => setFollowUpOpen(true)}
                >
                  Đặt lịch tái khám
                </Button>
              </div>
            </section>
          </main>
          <aside>
            <section className="card patient-side">
              <h2>Thông tin bệnh nhân</h2>
              <Avatar name={consultation.patient} size="lg" />
              <strong>{consultation.patient}</strong>
              <span>{consultation.patientId}</span>
              <hr />
              <Info label="Ngày hẹn" value={consultation.appointment} />
              <Info label="Ngày khám" value={consultation.date} />
              <Info label="Trạng thái" value={consultation.status} />
            </section>
            <Button type="submit" icon="check">
              Lưu phiếu khám
            </Button>
          </aside>
        </div>
      </form>
      {followUpOpen && (
        <FollowUpModal
          consultation={consultation}
          onClose={() => setFollowUpOpen(false)}
          onCreate={(appointment) => {
            createFollowUp(appointment);
            setFollowUpOpen(false);
            toast("Đã tạo lịch tái khám. Lịch mới đã được thêm vào mục Lịch hẹn.");
          }}
        />
      )}
    </div>
  );
}

function FollowUpModal({
  consultation,
  onClose,
  onCreate,
}: {
  consultation: (typeof consultations)[0];
  onClose: () => void;
  onCreate: (appointment: Appointment) => void;
}) {
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [modality, setModality] = useState<"Khám trực tiếp" | "Tư vấn trực tuyến">(
    "Khám trực tiếp",
  );
  const [reason, setReason] = useState("");
  const [error, setError] = useState("");
  const timeSlots = ["08:00", "08:30", "09:30", "10:30", "14:00", "15:00", "16:00"];

  const submit = () => {
    if (!date || !time) {
      setError("Vui lòng chọn ngày và giờ tái khám.");
      return;
    }
    onCreate({
      id: `LH-${Date.now().toString().slice(-6)}`,
      patientId: consultation.patientId,
      patient: consultation.patient,
      date,
      time,
      reason: reason.trim() || "Tái khám theo kế hoạch điều trị",
      type: "Tái khám",
      modality,
      status: "Chờ xác nhận",
    });
  };

  return (
    <div className="modal-backdrop" onMouseDown={onClose}>
      <div
        className="follow-up-modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="follow-up-title"
        onMouseDown={(e) => e.stopPropagation()}
      >
        <div className="follow-up-modal-head">
          <span>
            <Icon name="calendarPlus" />
          </span>
          <div>
            <h3 id="follow-up-title">Đặt lịch tái khám</h3>
            <p>Tạo lịch hẹn tiếp theo từ phiên khám hiện tại.</p>
          </div>
          <button onClick={onClose} aria-label="Đóng">
            <Icon name="x" />
          </button>
        </div>

        <div className="follow-up-patient">
          <Avatar name={consultation.patient} size="md" />
          <div>
            <span>BỆNH NHÂN</span>
            <strong>{consultation.patient}</strong>
            <small>{consultation.patientId}</small>
          </div>
          <span className="locked-label">Đã chọn từ phiên khám</span>
        </div>

        <div className="follow-up-fields">
          <label className="field">
            <span>
              Ngày tái khám <b>*</b>
            </span>
            <input
              type="date"
              min="2025-06-19"
              value={date}
              onChange={(e) => {
                setDate(e.target.value);
                setError("");
              }}
            />
          </label>

          <fieldset className="slot-field">
            <legend>
              Giờ tái khám <b>*</b>
            </legend>
            <div className="time-slots">
              {timeSlots.map((slot) => (
                <button
                  type="button"
                  className={time === slot ? "selected" : ""}
                  onClick={() => {
                    setTime(slot);
                    setError("");
                  }}
                  key={slot}
                >
                  {slot}
                </button>
              ))}
            </div>
          </fieldset>

          <fieldset className="modality-field">
            <legend>Hình thức khám</legend>
            <div>
              {(["Khám trực tiếp", "Tư vấn trực tuyến"] as const).map((option) => (
                <label className={modality === option ? "selected" : ""} key={option}>
                  <input
                    type="radio"
                    name="follow-up-modality"
                    value={option}
                    checked={modality === option}
                    onChange={() => setModality(option)}
                  />
                  <span>
                    <Icon name={option === "Khám trực tiếp" ? "stethoscope" : "phone"} />
                  </span>
                  <strong>{option}</strong>
                </label>
              ))}
            </div>
          </fieldset>

          <label className="field">
            <span>Lý do tái khám</span>
            <input
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="Ví dụ: Đánh giá đáp ứng điều trị"
              maxLength={120}
            />
          </label>
          {error && <div className="form-error">{error}</div>}
        </div>

        <div className="follow-up-modal-actions">
          <Button variant="secondary" onClick={onClose}>
            Hủy
          </Button>
          <Button icon="calendarPlus" onClick={submit}>
            Xác nhận tạo lịch
          </Button>
        </div>
      </div>
    </div>
  );
}

function MedicalRecordsPage() {
  const [query, setQuery] = useState("");
  const [patientId, setPatientId] = useState("BN-1024");
  const selected = patients.find((p) => p.id === patientId) || patients[0];
  const choices = patients.filter((p) =>
    `${p.name} ${p.id}`.toLowerCase().includes(query.toLowerCase()),
  );
  return (
    <div className="page">
      <PageHeading
        title="Hồ sơ bệnh án"
        description="Tra cứu lịch sử sức khỏe và quá trình điều trị của bệnh nhân."
      />
      <div className="records-layout">
        <aside className="card patient-selector">
          <SearchBox value={query} onChange={setQuery} placeholder="Tìm bệnh nhân..." />
          <div>
            {choices.map((p) => (
              <button
                className={p.id === patientId ? "active" : ""}
                onClick={() => setPatientId(p.id)}
                key={p.id}
              >
                <Avatar name={p.name} size="sm" />
                <span>
                  <strong>{p.name}</strong>
                  <small>{p.id}</small>
                </span>
                <Icon name="chevron" />
              </button>
            ))}
          </div>
        </aside>
        <main>
          <section className="card record-header">
            <Avatar name={selected.name} size="lg" />
            <div>
              <span>HỒ SƠ BỆNH NHÂN</span>
              <h2>{selected.name}</h2>
              <p>
                {selected.id} · {selected.gender} · {selected.dob}
              </p>
            </div>
            <div className="record-facts">
              <div>
                <span>Nhóm máu</span>
                <strong>{selected.blood}</strong>
              </div>
              <div>
                <span>Dị ứng</span>
                <strong>{selected.allergies}</strong>
              </div>
            </div>
          </section>
          <section className="card timeline-card">
            <div className="card-header">
              <div>
                <h2>Dòng thời gian y khoa</h2>
                <p>Các sự kiện sức khỏe đã được ghi nhận</p>
              </div>
            </div>
            <div className="timeline">
              <div>
                <i />
                <time>12/06/2025</time>
                <section>
                  <span className="timeline-type">PHIÊN KHÁM</span>
                  <h3>Rối loạn giấc ngủ</h3>
                  <p>
                    Bệnh nhân báo cáo khó ngủ kéo dài. Đã tư vấn điều chỉnh thói quen sinh hoạt và
                    theo dõi.
                  </p>
                  <small>BS. Nguyễn Minh Anh · TiTiMi Clinic</small>
                </section>
              </div>
              <div>
                <i />
                <time>18/03/2025</time>
                <section>
                  <span className="timeline-type diagnosis">CHẨN ĐOÁN</span>
                  <h3>Đau đầu căng thẳng</h3>
                  <p>
                    Không ghi nhận dấu hiệu thần kinh khu trú. Hướng dẫn nghỉ ngơi và theo dõi triệu
                    chứng.
                  </p>
                  <small>BS. Nguyễn Minh Anh · TiTiMi Clinic</small>
                </section>
              </div>
              <div>
                <i />
                <time>05/11/2024</time>
                <section>
                  <span className="timeline-type treatment">ĐIỀU TRỊ</span>
                  <h3>Viêm họng cấp</h3>
                  <p>Hoàn thành liệu trình điều trị, triệu chứng đã cải thiện.</p>
                  <small>BS. Trần Anh Dũng · TiTiMi Clinic</small>
                </section>
              </div>
            </div>
          </section>
        </main>
      </div>
    </div>
  );
}

function PrescriptionsPage({ toast }: { toast: (m: string) => void }) {
  const [mode, setMode] = useState<"list" | "new" | "detail">("list");
  const [selected, setSelected] = useState(initialPrescriptions[0]);
  const [search, setSearch] = useState("");
  const [date, setDate] = useState("");
  const [status, setStatus] = useState("Tất cả trạng thái");
  const displayDate = date ? date.split("-").reverse().join("/") : "";
  const filtered = initialPrescriptions.filter(
    (r) =>
      `${r.id} ${r.patient}`.toLowerCase().includes(search.toLowerCase()) &&
      (!date || r.date === displayDate) &&
      (status === "Tất cả trạng thái" || r.status === status),
  );
  if (mode === "new") return <PrescriptionForm back={() => setMode("list")} toast={toast} />;
  if (mode === "detail")
    return <PrescriptionDetail prescription={selected} back={() => setMode("list")} />;
  return (
    <div className="page">
      <PageHeading
        title="Quản lý đơn thuốc"
        description="Theo dõi và tạo đơn thuốc cho bệnh nhân."
        action={
          <Button icon="plus" onClick={() => setMode("new")}>
            Tạo đơn thuốc
          </Button>
        }
      />
      <section className="card">
        <div className="filter-bar">
          <SearchBox
            value={search}
            onChange={setSearch}
            placeholder="Tìm bệnh nhân hoặc mã đơn thuốc..."
          />
          <input
            className="date-input"
            type="date"
            aria-label="Lọc ngày"
            value={date}
            onChange={(e) => setDate(e.target.value)}
          />
          <select
            aria-label="Trạng thái"
            value={status}
            onChange={(e) => setStatus(e.target.value)}
          >
            <option>Tất cả trạng thái</option>
            <option>Đã kê</option>
            <option>Hết hạn</option>
          </select>
          {(date || search) && (
            <Button
              variant="ghost"
              onClick={() => {
                setDate("");
                setSearch("");
              }}
            >
              Xóa lọc
            </Button>
          )}
        </div>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>MÃ ĐƠN THUỐC</th>
                <th>BỆNH NHÂN</th>
                <th>NGÀY TẠO</th>
                <th>SỐ LOẠI THUỐC</th>
                <th>TRẠNG THÁI</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {filtered.map((r) => (
                <tr key={r.id}>
                  <td>
                    <b>{r.id}</b>
                  </td>
                  <td>
                    <div className="patient-cell">
                      <Avatar name={r.patient} size="sm" />
                      <div>
                        <strong>{r.patient}</strong>
                        <span>{r.patientId}</span>
                      </div>
                    </div>
                  </td>
                  <td>{r.date}</td>
                  <td>{r.count} loại</td>
                  <td>
                    <StatusBadge status={r.status} />
                  </td>
                  <td>
                    <button
                      className="view-link"
                      onClick={() => {
                        setSelected(r);
                        setMode("detail");
                      }}
                    >
                      Xem chi tiết <Icon name="chevron" size={14} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filtered.length === 0 && <div className="empty">Không tìm thấy đơn thuốc phù hợp.</div>}
        </div>
      </section>
      <p className="disclaimer">
        Thông tin trong bản mẫu chỉ nhằm minh họa giao diện, không phải tư vấn y khoa và không kết
        nối với nhà thuốc.
      </p>
    </div>
  );
}

function PrescriptionDetail({
  prescription,
  back,
}: {
  prescription: (typeof initialPrescriptions)[0];
  back: () => void;
}) {
  return (
    <div className="page detail-page">
      <button className="back-link" onClick={back}>
        <Icon name="arrow" /> Quay lại danh sách đơn thuốc
      </button>
      <PageHeading
        eyebrow="ĐƠN THUỐC"
        title={prescription.id}
        description={`Ngày kê: ${prescription.date}`}
        action={<StatusBadge status={prescription.status} />}
      />
      <div className="two-col prescription-detail">
        <section className="card detail-card">
          <div className="section-title">
            <span>
              <Icon name="pill" />
            </span>
            <div>
              <h2>Danh sách thuốc</h2>
              <p>{prescription.count} loại thuốc trong đơn</p>
            </div>
          </div>
          <div className="med-list">
            <div>
              <b>01</b>
              <section>
                <h3>Omeprazole 20mg</h3>
                <p>1 viên · 1 lần/ngày · 14 ngày</p>
                <small>Uống trước bữa sáng 30 phút.</small>
              </section>
            </div>
            {prescription.count > 1 && (
              <div>
                <b>02</b>
                <section>
                  <h3>Gaviscon 10ml</h3>
                  <p>1 gói · 2 lần/ngày · 7 ngày</p>
                  <small>Uống sau bữa ăn.</small>
                </section>
              </div>
            )}
          </div>
        </section>
        <aside className="card detail-card">
          <h2>Thông tin kê đơn</h2>
          <div className="prescription-people">
            <Avatar name={prescription.patient} />
            <div>
              <span>Bệnh nhân</span>
              <strong>{prescription.patient}</strong>
              <small>{prescription.patientId}</small>
            </div>
          </div>
          <div className="prescription-people">
            <Avatar name="Nguyễn Minh Anh" />
            <div>
              <span>Bác sĩ kê đơn</span>
              <strong>BS. Nguyễn Minh Anh</strong>
              <small>Nội tổng quát · BS-00128</small>
            </div>
          </div>
          <Info label="Ngày kê đơn" value={prescription.date} />
        </aside>
      </div>
      <p className="disclaimer">
        Đơn thuốc mẫu không thay thế chỉ định chuyên môn và không được sử dụng cho mục đích điều trị
        thực tế.
      </p>
    </div>
  );
}

function PrescriptionForm({ back, toast }: { back: () => void; toast: (m: string) => void }) {
  const empty: Medication = { name: "", dosage: "", frequency: "", duration: "", instructions: "" };
  const [patient, setPatient] = useState("");
  const [meds, setMeds] = useState<Medication[]>([
    {
      name: "Omeprazole 20mg",
      dosage: "1 viên",
      frequency: "1 lần/ngày",
      duration: "14 ngày",
      instructions: "Uống trước bữa sáng 30 phút",
    },
  ]);
  const [error, setError] = useState("");
  const update = (i: number, key: keyof Medication, value: string) =>
    setMeds(meds.map((m, index) => (index === i ? { ...m, [key]: value } : m)));
  const save = () => {
    if (!patient || meds.some((m) => !m.name || !m.dosage || !m.frequency || !m.duration)) {
      setError("Vui lòng chọn bệnh nhân và điền đủ các trường bắt buộc.");
      return;
    }
    setError("");
    toast("Đã lưu đơn thuốc mới trong phiên làm việc.");
    back();
  };
  return (
    <div className="page detail-page">
      <button className="back-link" onClick={back}>
        <Icon name="arrow" /> Quay lại danh sách đơn thuốc
      </button>
      <PageHeading
        title="Tạo đơn thuốc mới"
        description="Điền thông tin bệnh nhân và chỉ định thuốc."
      />
      <section className="card form-card prescription-form">
        <h2>Thông tin chung</h2>
        <div className="form-grid">
          <label className="field">
            <span>
              Bệnh nhân <b>*</b>
            </span>
            <select value={patient} onChange={(e) => setPatient(e.target.value)}>
              <option value="">Chọn bệnh nhân</option>
              {patients.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} — {p.id}
                </option>
              ))}
            </select>
          </label>
          <Field label="Ngày kê đơn" value="18/06/2025" onChange={() => {}} />
        </div>
      </section>
      <section className="card form-card prescription-form">
        <div className="card-header">
          <div>
            <h2>Thuốc kê đơn</h2>
            <p>Thêm thuốc và hướng dẫn sử dụng.</p>
          </div>
          <Button variant="secondary" icon="plus" onClick={() => setMeds([...meds, { ...empty }])}>
            Thêm thuốc
          </Button>
        </div>
        {meds.map((med, i) => (
          <div className="med-row" key={i}>
            <div className="med-row-head">
              <strong>Thuốc {String(i + 1).padStart(2, "0")}</strong>
              {meds.length > 1 && (
                <button onClick={() => setMeds(meds.filter((_, index) => index !== i))}>
                  <Icon name="trash" /> Xóa
                </button>
              )}
            </div>
            <div className="med-fields">
              <Field
                label="Tên thuốc"
                value={med.name}
                required
                onChange={(v) => update(i, "name", v)}
                placeholder="Ví dụ: Omeprazole 20mg"
              />
              <Field
                label="Liều dùng"
                value={med.dosage}
                required
                onChange={(v) => update(i, "dosage", v)}
                placeholder="Ví dụ: 1 viên"
              />
              <Field
                label="Tần suất"
                value={med.frequency}
                required
                onChange={(v) => update(i, "frequency", v)}
                placeholder="Ví dụ: 2 lần/ngày"
              />
              <Field
                label="Thời gian"
                value={med.duration}
                required
                onChange={(v) => update(i, "duration", v)}
                placeholder="Ví dụ: 7 ngày"
              />
              <div className="wide-field">
                <Field
                  label="Hướng dẫn sử dụng"
                  value={med.instructions}
                  onChange={(v) => update(i, "instructions", v)}
                  placeholder="Uống sau bữa ăn..."
                />
              </div>
            </div>
          </div>
        ))}
      </section>
      {error && <div className="form-error">{error}</div>}
      <div className="form-actions">
        <Button variant="secondary" onClick={back}>
          Hủy
        </Button>
        <Button icon="check" onClick={save}>
          Lưu đơn thuốc
        </Button>
      </div>
      <p className="disclaimer">
        Chỉ sử dụng dữ liệu mẫu. Prototype không cung cấp tư vấn y khoa hoặc kết nối nhà thuốc.
      </p>
    </div>
  );
}

function ProfilePage({ toast }: { toast: (m: string) => void }) {
  const original = {
    name: "Nguyễn Minh Anh",
    email: "minhanh.nguyen@titimi.vn",
    phone: "090 845 2210",
    gender: "Nữ",
    dob: "14/08/1985",
    specialty: "Nội tổng quát",
    license: "CCHN-012345/HCM",
    experience: "12 năm",
  };
  const [data, setData] = useState(original);
  const [editing, setEditing] = useState(false);
  const [error, setError] = useState("");
  const set = (key: keyof typeof data, value: string) => setData({ ...data, [key]: value });
  const save = () => {
    if (!data.name || !data.email.includes("@") || !data.phone) {
      setError("Vui lòng nhập họ tên, email và số điện thoại hợp lệ.");
      return;
    }
    setError("");
    setEditing(false);
    toast("Đã cập nhật hồ sơ cá nhân.");
  };
  return (
    <div className="page">
      <PageHeading
        title="Hồ sơ cá nhân"
        description="Quản lý thông tin cá nhân và chuyên môn của bác sĩ."
        action={
          !editing ? (
            <Button icon="edit" onClick={() => setEditing(true)}>
              Chỉnh sửa hồ sơ
            </Button>
          ) : undefined
        }
      />
      <section className="card profile-hero">
        <Avatar name={data.name} size="lg" />
        <div>
          <span>BÁC SĨ PHỤ TRÁCH</span>
          <h2>BS. {data.name}</h2>
          <p>{data.specialty} · Mã bác sĩ BS-00128</p>
        </div>
        <button className="avatar-edit" disabled={!editing}>
          <Icon name="edit" size={15} />
        </button>
      </section>
      <div className="profile-grid">
        <section className="card form-card">
          <div className="section-title">
            <span>
              <Icon name="user" />
            </span>
            <div>
              <h2>Thông tin cá nhân</h2>
              <p>Thông tin định danh của bác sĩ</p>
            </div>
          </div>
          <div className="form-grid">
            <Field
              label="Họ và tên"
              value={data.name}
              disabled={!editing}
              onChange={(v) => set("name", v)}
            />
            <Field label="Mã bác sĩ" value="BS-00128" disabled onChange={() => {}} />
            <Field
              label="Giới tính"
              value={data.gender}
              disabled={!editing}
              onChange={(v) => set("gender", v)}
            />
            <Field
              label="Ngày sinh"
              value={data.dob}
              disabled={!editing}
              onChange={(v) => set("dob", v)}
            />
          </div>
        </section>
        <section className="card form-card">
          <div className="section-title">
            <span>
              <Icon name="mail" />
            </span>
            <div>
              <h2>Thông tin liên hệ</h2>
              <p>Kênh liên lạc tại phòng khám</p>
            </div>
          </div>
          <div className="form-grid">
            <Field
              label="Email"
              type="email"
              value={data.email}
              disabled={!editing}
              onChange={(v) => set("email", v)}
            />
            <Field
              label="Số điện thoại"
              value={data.phone}
              disabled={!editing}
              onChange={(v) => set("phone", v)}
            />
          </div>
        </section>
        <section className="card form-card wide-card">
          <div className="section-title">
            <span>
              <Icon name="briefcase" />
            </span>
            <div>
              <h2>Thông tin chuyên môn</h2>
              <p>Thông tin hành nghề và kinh nghiệm</p>
            </div>
          </div>
          <div className="form-grid thirds">
            <Field
              label="Chuyên khoa"
              value={data.specialty}
              disabled={!editing}
              onChange={(v) => set("specialty", v)}
            />
            <Field
              label="Chứng chỉ hành nghề"
              value={data.license}
              disabled={!editing}
              onChange={(v) => set("license", v)}
            />
            <Field
              label="Kinh nghiệm"
              value={data.experience}
              disabled={!editing}
              onChange={(v) => set("experience", v)}
            />
          </div>
        </section>
      </div>
      {error && <div className="form-error">{error}</div>}
      {editing && (
        <div className="form-actions">
          <Button
            variant="secondary"
            onClick={() => {
              setData(original);
              setEditing(false);
              setError("");
            }}
          >
            Hủy thay đổi
          </Button>
          <Button icon="check" onClick={save}>
            Lưu thay đổi
          </Button>
        </div>
      )}
    </div>
  );
}

export default function App() {
  const [page, setPage] = useState<Page>("dashboard");
  const [appointments, setAppointments] = useState(initialAppointments);
  const [appointmentDetail, setAppointmentDetail] = useState<Appointment | null>(null);
  const [patientDetail, setPatientDetail] = useState<Patient | null>(null);
  const [consultationDetail, setConsultationDetail] = useState<string | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState("");
  const title = useMemo(() => navItems.find((n) => n.id === page)?.label || "Dashboard", [page]);
  const navigate = (p: Page) => {
    setPage(p);
    setAppointmentDetail(null);
    setPatientDetail(null);
    if (p !== "consultations") setConsultationDetail(null);
  };
  const toast = (message: string) => {
    setToastMessage(message);
    window.setTimeout(() => setToastMessage(""), 3500);
  };
  const viewAppointment = (a: Appointment) => {
    setPage("appointments");
    setAppointmentDetail(a);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };
  const createFollowUp = (appointment: Appointment) => {
    setAppointments((current) => [appointment, ...current]);
  };
  const render = () => {
    if (appointmentDetail)
      return (
        <AppointmentDetail
          appointment={appointmentDetail}
          setAppointments={setAppointments}
          back={() => setAppointmentDetail(null)}
          toast={toast}
          startConsultation={() => {
            setAppointmentDetail(null);
            setPage("consultations");
            setConsultationDetail("PK-25061801");
          }}
        />
      );
    if (patientDetail)
      return (
        <PatientDetail
          patient={patientDetail}
          back={() => setPatientDetail(null)}
          openConsultations={() => {
            setPatientDetail(null);
            setPage("consultations");
          }}
          openRecords={() => {
            setPatientDetail(null);
            setPage("records");
          }}
          openPrescriptions={() => {
            setPatientDetail(null);
            setPage("prescriptions");
          }}
        />
      );
    switch (page) {
      case "dashboard":
        return (
          <Dashboard
            appointments={appointments}
            navigate={navigate}
            viewAppointment={viewAppointment}
          />
        );
      case "appointments":
        return (
          <AppointmentsPage
            appointments={appointments}
            setAppointments={setAppointments}
            viewAppointment={viewAppointment}
            toast={toast}
          />
        );
      case "schedule":
        return <SchedulePage appointments={appointments} viewAppointment={viewAppointment} />;
      case "patients":
        return <PatientsPage openPatient={setPatientDetail} />;
      case "consultations":
        return (
          <ConsultationsPage
            selected={consultationDetail}
            setSelected={setConsultationDetail}
            toast={toast}
            createFollowUp={createFollowUp}
          />
        );
      case "records":
        return <MedicalRecordsPage />;
      case "prescriptions":
        return <PrescriptionsPage toast={toast} />;
      case "profile":
        return <ProfilePage toast={toast} />;
    }
  };
  return (
    <div className="app-shell">
      <Sidebar
        page={page}
        setPage={navigate}
        open={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
      />
      <div className="main-shell">
        <Header title={title} onMenu={() => setSidebarOpen(true)} />
        <main className="content">{render()}</main>
      </div>
      {toastMessage && <Toast message={toastMessage} onClose={() => setToastMessage("")} />}
    </div>
  );
}
