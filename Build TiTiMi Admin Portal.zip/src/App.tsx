import { useMemo, useState } from "react";
import titimiHatLogo from "./assets/titimi-hat-logo.png";

type Page =
  | "dashboard"
  | "users"
  | "doctors"
  | "patients"
  | "specialties"
  | "appointments"
  | "schedule"
  | "reports"
  | "settings";
type User = {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: "Admin" | "Bác sĩ" | "Bệnh nhân";
  status: "Hoạt động" | "Tạm khóa";
  created: string;
};
type Doctor = {
  id: string;
  name: string;
  specialty: string;
  email: string;
  phone: string;
  status: "Hoạt động" | "Tạm khóa";
  gender: string;
  dob: string;
};
type Patient = {
  id: string;
  name: string;
  gender: string;
  dob: string;
  phone: string;
  email: string;
  created: string;
  status: "Hoạt động" | "Tạm khóa";
};
type Specialty = {
  id: string;
  name: string;
  description: string;
  doctors: number;
  status: "Hoạt động" | "Tạm ngưng";
};
type Appointment = {
  id: string;
  patient: string;
  patientId?: string;
  doctor: string;
  specialty: string;
  date: string;
  time: string;
  reason: string;
  visitType?: "Khám trực tiếp" | "Tư vấn trực tuyến";
  isFollowUp?: boolean;
  fee?: number;
  status: "Chờ xác nhận" | "Đã xác nhận" | "Hoàn thành" | "Đã hủy";
};

const NAV: { page: Page; label: string; icon: string }[] = [
  { page: "dashboard", label: "Dashboard", icon: "grid" },
  { page: "users", label: "Quản lý người dùng", icon: "users" },
  { page: "doctors", label: "Quản lý bác sĩ", icon: "doctor" },
  { page: "patients", label: "Quản lý bệnh nhân", icon: "heart" },
  { page: "specialties", label: "Chuyên khoa", icon: "briefcase" },
  { page: "appointments", label: "Quản lý lịch hẹn", icon: "calendar" },
  { page: "schedule", label: "Quản lý lịch làm việc", icon: "clock" },
  { page: "reports", label: "Báo cáo hệ thống", icon: "chart" },
  { page: "settings", label: "Cài đặt", icon: "settings" },
];

const initialUsers: User[] = [
  {
    id: "USR-001",
    name: "Nguyễn Minh Anh",
    email: "minhanh@titimi.vn",
    phone: "090 234 5678",
    role: "Admin",
    status: "Hoạt động",
    created: "12/05/2024",
  },
  {
    id: "USR-102",
    name: "BS. Trần Quốc Huy",
    email: "quochuy@titimi.vn",
    phone: "091 568 2034",
    role: "Bác sĩ",
    status: "Hoạt động",
    created: "18/08/2024",
  },
  {
    id: "USR-208",
    name: "Lê Hoàng Nam",
    email: "hoangnam@gmail.com",
    phone: "098 321 4076",
    role: "Bệnh nhân",
    status: "Hoạt động",
    created: "05/01/2025",
  },
  {
    id: "USR-211",
    name: "Phạm Ngọc Lan",
    email: "ngoclan@gmail.com",
    phone: "093 745 1290",
    role: "Bệnh nhân",
    status: "Tạm khóa",
    created: "16/01/2025",
  },
  {
    id: "USR-118",
    name: "BS. Vũ Thu Hà",
    email: "thuha@titimi.vn",
    phone: "097 551 8203",
    role: "Bác sĩ",
    status: "Hoạt động",
    created: "09/11/2024",
  },
];
const initialDoctors: Doctor[] = [
  {
    id: "BS-102",
    name: "Trần Quốc Huy",
    specialty: "Tim mạch",
    email: "quochuy@titimi.vn",
    phone: "091 568 2034",
    status: "Hoạt động",
    gender: "Nam",
    dob: "21/06/1984",
  },
  {
    id: "BS-118",
    name: "Vũ Thu Hà",
    specialty: "Nhi khoa",
    email: "thuha@titimi.vn",
    phone: "097 551 8203",
    status: "Hoạt động",
    gender: "Nữ",
    dob: "14/03/1988",
  },
  {
    id: "BS-126",
    name: "Đặng Minh Khôi",
    specialty: "Da liễu",
    email: "minhkhoi@titimi.vn",
    phone: "090 881 7264",
    status: "Hoạt động",
    gender: "Nam",
    dob: "02/12/1981",
  },
  {
    id: "BS-131",
    name: "Nguyễn Tú Uyên",
    specialty: "Nội tổng quát",
    email: "tuyen@titimi.vn",
    phone: "093 427 1180",
    status: "Tạm khóa",
    gender: "Nữ",
    dob: "18/09/1990",
  },
  {
    id: "BS-144",
    name: "Lê Đức Phúc",
    specialty: "Tai Mũi Họng",
    email: "ducphuc@titimi.vn",
    phone: "096 214 6630",
    status: "Hoạt động",
    gender: "Nam",
    dob: "10/01/1986",
  },
];
const initialPatients: Patient[] = [
  {
    id: "BN-208",
    name: "Lê Hoàng Nam",
    gender: "Nam",
    dob: "12/08/1992",
    phone: "098 321 4076",
    email: "hoangnam@gmail.com",
    created: "05/01/2025",
    status: "Hoạt động",
  },
  {
    id: "BN-211",
    name: "Phạm Ngọc Lan",
    gender: "Nữ",
    dob: "24/11/1989",
    phone: "093 745 1290",
    email: "ngoclan@gmail.com",
    created: "16/01/2025",
    status: "Tạm khóa",
  },
  {
    id: "BN-225",
    name: "Đỗ Thanh Tâm",
    gender: "Nữ",
    dob: "06/04/1997",
    phone: "090 527 6198",
    email: "thanhtam@gmail.com",
    created: "02/02/2025",
    status: "Hoạt động",
  },
  {
    id: "BN-231",
    name: "Hoàng Gia Bảo",
    gender: "Nam",
    dob: "19/02/1985",
    phone: "097 653 8812",
    email: "giabao@gmail.com",
    created: "12/02/2025",
    status: "Hoạt động",
  },
];
const initialSpecialties: Specialty[] = [
  {
    id: "CK-01",
    name: "Tim mạch",
    description: "Chẩn đoán và điều trị các bệnh lý tim mạch.",
    doctors: 4,
    status: "Hoạt động",
  },
  {
    id: "CK-02",
    name: "Nhi khoa",
    description: "Chăm sóc sức khỏe toàn diện cho trẻ em.",
    doctors: 6,
    status: "Hoạt động",
  },
  {
    id: "CK-03",
    name: "Da liễu",
    description: "Điều trị các bệnh lý về da và tóc.",
    doctors: 3,
    status: "Hoạt động",
  },
  {
    id: "CK-04",
    name: "Nội tổng quát",
    description: "Khám và điều trị bệnh lý nội khoa.",
    doctors: 8,
    status: "Hoạt động",
  },
  {
    id: "CK-05",
    name: "Tai Mũi Họng",
    description: "Chăm sóc tai, mũi, họng và đường hô hấp.",
    doctors: 5,
    status: "Hoạt động",
  },
];
const initialAppointments: Appointment[] = [
  {
    id: "LH-2401",
    patient: "Lê Hoàng Nam",
    doctor: "Trần Quốc Huy",
    specialty: "Tim mạch",
    date: "20/06/2025",
    time: "08:30",
    reason: "Tái khám định kỳ",
    status: "Đã xác nhận",
  },
  {
    id: "LH-2402",
    patient: "Đỗ Thanh Tâm",
    doctor: "Vũ Thu Hà",
    specialty: "Nhi khoa",
    date: "20/06/2025",
    time: "09:15",
    reason: "Khám tổng quát",
    status: "Chờ xác nhận",
  },
  {
    id: "LH-2403",
    patient: "Phạm Ngọc Lan",
    doctor: "Đặng Minh Khôi",
    specialty: "Da liễu",
    date: "20/06/2025",
    time: "10:00",
    reason: "Khám dị ứng da",
    status: "Hoàn thành",
  },
  {
    id: "LH-2404",
    patient: "Hoàng Gia Bảo",
    doctor: "Nguyễn Tú Uyên",
    specialty: "Nội tổng quát",
    date: "21/06/2025",
    time: "14:30",
    reason: "Đau đầu kéo dài",
    status: "Đã hủy",
  },
  {
    id: "LH-2405",
    patient: "Lê Hoàng Nam",
    doctor: "Lê Đức Phúc",
    specialty: "Tai Mũi Họng",
    date: "22/06/2025",
    time: "11:00",
    reason: "Đau họng",
    status: "Chờ xác nhận",
  },
];

function Icon({ name, size = 20 }: { name: string; size?: number }) {
  const paths: Record<string, React.ReactNode> = {
    grid: (
      <>
        <rect x="3" y="3" width="7" height="7" rx="1" />
        <rect x="14" y="3" width="7" height="7" rx="1" />
        <rect x="3" y="14" width="7" height="7" rx="1" />
        <rect x="14" y="14" width="7" height="7" rx="1" />
      </>
    ),
    users: (
      <>
        <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
        <circle cx="9" cy="7" r="4" />
        <path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" />
      </>
    ),
    doctor: (
      <>
        <circle cx="12" cy="7" r="4" />
        <path d="M5.5 21a6.5 6.5 0 0 1 13 0M12 14v7M9 18h6" />
      </>
    ),
    heart: (
      <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78L12 21.23l8.84-8.84a5.5 5.5 0 0 0 0-7.78z" />
    ),
    briefcase: (
      <>
        <rect x="3" y="7" width="18" height="13" rx="2" />
        <path d="M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M3 12h18" />
      </>
    ),
    calendar: (
      <>
        <rect x="3" y="5" width="18" height="16" rx="2" />
        <path d="M16 3v4M8 3v4M3 11h18" />
      </>
    ),
    clock: (
      <>
        <circle cx="12" cy="12" r="9" />
        <path d="M12 7v5l3 2" />
      </>
    ),
    chart: (
      <>
        <path d="M3 3v18h18" />
        <path d="m7 16 4-5 3 3 5-7" />
      </>
    ),
    settings: (
      <>
        <circle cx="12" cy="12" r="3" />
        <path d="M19.4 15a1.7 1.7 0 0 0 .34 1.88l.06.06-2.83 2.83-.06-.06A1.7 1.7 0 0 0 15 19.4a1.7 1.7 0 0 0-1 .6 1.7 1.7 0 0 0-.4 1v.1h-4v-.1a1.7 1.7 0 0 0-1.1-1.6 1.7 1.7 0 0 0-1.88.34l-.06.06-2.83-2.83.06-.06A1.7 1.7 0 0 0 4.1 15a1.7 1.7 0 0 0-1.6-1H2.4v-4h.1A1.7 1.7 0 0 0 4.1 9a1.7 1.7 0 0 0-.34-1.88l-.06-.06 2.83-2.83.06.06A1.7 1.7 0 0 0 8.5 4.6a1.7 1.7 0 0 0 1-1.6v-.1h4V3a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.88-.34l.06-.06 2.83 2.83-.06.06A1.7 1.7 0 0 0 18.9 9a1.7 1.7 0 0 0 1.6 1h.1v4h-.1a1.7 1.7 0 0 0-1.1 1z" />
      </>
    ),
    search: (
      <>
        <circle cx="11" cy="11" r="7" />
        <path d="m20 20-4-4" />
      </>
    ),
    bell: (
      <>
        <path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4" />
      </>
    ),
    plus: <path d="M12 5v14M5 12h14" />,
    close: <path d="m6 6 12 12M18 6 6 18" />,
    menu: <path d="M4 6h16M4 12h16M4 18h16" />,
    dots: (
      <>
        <circle cx="5" cy="12" r="1" />
        <circle cx="12" cy="12" r="1" />
        <circle cx="19" cy="12" r="1" />
      </>
    ),
    chevron: <path d="m9 18 6-6-6-6" />,
    download: (
      <>
        <path d="M12 3v12M7 10l5 5 5-5" />
        <path d="M5 21h14" />
      </>
    ),
    check: <path d="m5 12 4 4L19 6" />,
    edit: (
      <>
        <path d="M12 20h9" />
        <path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L8 18l-4 1 1-4z" />
      </>
    ),
    eye: (
      <>
        <path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6S2 12 2 12z" />
        <circle cx="12" cy="12" r="2.5" />
      </>
    ),
    logout: (
      <>
        <path d="M10 17l5-5-5-5M15 12H3" />
        <path d="M14 3h6a1 1 0 0 1 1 1v16a1 1 0 0 1-1 1h-6" />
      </>
    ),
  };
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {paths[name] || paths.grid}
    </svg>
  );
}

function Button({
  children,
  variant = "primary",
  onClick,
  type = "button",
  disabled = false,
}: {
  children: React.ReactNode;
  variant?: "primary" | "secondary" | "ghost" | "danger";
  onClick?: () => void;
  type?: "button" | "submit";
  disabled?: boolean;
}) {
  return (
    <button className={`btn btn-${variant}`} onClick={onClick} type={type} disabled={disabled}>
      {children}
    </button>
  );
}
function Input(props: React.InputHTMLAttributes<HTMLInputElement>) {
  return <input {...props} className={`field ${props.className || ""}`} />;
}
function Select(props: React.SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <select {...props} className="field select">
      {props.children}
    </select>
  );
}
function SearchBar({
  value,
  onChange,
  placeholder = "Tìm kiếm...",
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
}) {
  return (
    <div className="search">
      <Icon name="search" size={18} />
      <Input value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} />
      {value && (
        <button aria-label="Xóa tìm kiếm" onClick={() => onChange("")}>
          <Icon name="close" size={15} />
        </button>
      )}
    </div>
  );
}
function StatusBadge({ status }: { status: string }) {
  const tone =
    status.includes("Hoạt động") || status.includes("Hoàn thành")
      ? "success"
      : status.includes("xác nhận")
        ? "warning"
        : status.includes("hủy") || status.includes("khóa") || status.includes("ngưng")
          ? "danger"
          : "info";
  return (
    <span className={`badge badge-${tone}`}>
      <span />
      {status}
    </span>
  );
}
function Avatar({ name, size = "md" }: { name: string; size?: "sm" | "md" | "lg" }) {
  return (
    <div className={`avatar avatar-${size}`}>
      {name
        .split(" ")
        .slice(-2)
        .map((x) => x[0])
        .join("")}
    </div>
  );
}
function StatCard({
  label,
  value,
  detail,
  icon,
  tone = "teal",
}: {
  label: string;
  value: string | number;
  detail: string;
  icon: string;
  tone?: string;
}) {
  return (
    <div className={`stat-card stat-${tone}`}>
      <div className={`stat-icon tone-${tone}`}>
        <Icon name={icon} />
      </div>
      <div>
        <p>{label}</p>
        <strong>{value}</strong>
        <small>{detail}</small>
      </div>
    </div>
  );
}
function EmptyState() {
  return <div className="empty">Không tìm thấy dữ liệu phù hợp. Hãy thử thay đổi bộ lọc.</div>;
}
function Pagination({ total }: { total: number }) {
  return (
    <div className="pagination">
      <span>
        Hiển thị 1–{total} trong {total} kết quả
      </span>
      <div>
        <Button variant="secondary">Trước</Button>
        <button className="page-active">1</button>
        <Button variant="secondary">Sau</Button>
      </div>
    </div>
  );
}

function Modal({
  title,
  children,
  onClose,
  wide = false,
}: {
  title: string;
  children: React.ReactNode;
  onClose: () => void;
  wide?: boolean;
}) {
  return (
    <div className="modal-backdrop" onMouseDown={onClose}>
      <div className={`modal ${wide ? "modal-wide" : ""}`} onMouseDown={(e) => e.stopPropagation()}>
        <div className="modal-head">
          <div>
            <span className="eyebrow">TiTiMi Admin</span>
            <h2>{title}</h2>
          </div>
          <button className="icon-btn" onClick={onClose} aria-label="Đóng">
            <Icon name="close" />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}
function ConfirmDialog({
  title,
  description,
  onConfirm,
  onClose,
}: {
  title: string;
  description: string;
  onConfirm: () => void;
  onClose: () => void;
}) {
  return (
    <Modal title={title} onClose={onClose}>
      <p className="modal-copy">{description}</p>
      <div className="modal-actions">
        <Button variant="secondary" onClick={onClose}>
          Hủy
        </Button>
        <Button variant="danger" onClick={onConfirm}>
          Xác nhận
        </Button>
      </div>
    </Modal>
  );
}

function MiniLineChart({ variant = 0 }: { variant?: number }) {
  const lines = variant
    ? "M8 78 C28 64,38 72,58 54 S88 64,108 36 S138 46,158 24 S188 42,212 18 S240 26,272 10"
    : "M8 72 C30 68,36 48,60 55 S90 72,110 42 S140 30,160 46 S188 58,208 25 S242 32,272 12";
  return (
    <svg className="line-chart" viewBox="0 0 280 90" preserveAspectRatio="none">
      <defs>
        <linearGradient id={`area${variant}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#286A9B" stopOpacity=".24" />
          <stop offset="1" stopColor="#286A9B" stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d={`${lines} L272 90 L8 90 Z`} fill={`url(#area${variant})`} />
      <path d={lines} fill="none" stroke="#286A9B" strokeWidth="3" strokeLinecap="round" />
    </svg>
  );
}
function Donut({
  parts,
  center,
}: {
  parts: { label: string; value: number; color: string }[];
  center: string;
}) {
  let acc = 0;
  const stops = parts
    .map((p) => {
      const from = acc;
      acc += p.value;
      return `${p.color} ${from}% ${acc}%`;
    })
    .join(",");
  return (
    <div className="donut-wrap">
      <div className="donut" style={{ background: `conic-gradient(${stops})` }}>
        <div>
          <strong>{center}</strong>
          <small>Tổng số</small>
        </div>
      </div>
      <div className="legend">
        {parts.map((p) => (
          <div key={p.label}>
            <i style={{ background: p.color }} />
            <span>{p.label}</span>
            <b>{p.value}%</b>
          </div>
        ))}
      </div>
    </div>
  );
}
function BarChart({ compact = false }: { compact?: boolean }) {
  const values = compact ? [42, 55, 38, 70, 62] : [34, 58, 46, 72, 61, 83, 68];
  return (
    <div className="bars">
      {values.map((v, i) => (
        <div key={i}>
          <div className="bar-tooltip">{v}</div>
          <span style={{ height: `${v}%` }} />
          <small>
            {compact
              ? ["Tim mạch", "Nhi", "Da liễu", "Nội", "TMH"][i]
              : ["T2", "T3", "T4", "T5", "T6", "T7", "CN"][i]}
          </small>
        </div>
      ))}
    </div>
  );
}

function Dashboard({
  setPage,
  appointments,
}: {
  setPage: (p: Page) => void;
  appointments: Appointment[];
}) {
  return (
    <div className="page-stack">
      <section className="welcome">
        <div>
          <span className="eyebrow">Thứ Sáu, 20 tháng 06, 2025</span>
          <h2>Tổng quan hệ thống</h2>
          <p>Xin chào, Quản trị viên. Hệ thống đang hoạt động ổn định.</p>
        </div>
        <div className="system-status">
          <span />
          <div>
            <b>Hệ thống bình thường</b>
            <small>Cập nhật 2 phút trước</small>
          </div>
        </div>
      </section>
      <div className="stat-grid six">
        <StatCard
          label="Tổng người dùng"
          value="2.486"
          detail="+8,2% so với tháng trước"
          icon="users"
        />
        <StatCard
          label="Tổng bác sĩ"
          value="126"
          detail="+4 bác sĩ mới"
          icon="doctor"
          tone="blue"
        />
        <StatCard
          label="Tổng bệnh nhân"
          value="2.352"
          detail="+126 trong tháng"
          icon="heart"
          tone="violet"
        />
        <StatCard
          label="Tổng lịch hẹn"
          value="8.942"
          detail="+12,5% so với tháng trước"
          icon="calendar"
          tone="orange"
        />
        <StatCard
          label="Chờ xác nhận"
          value="48"
          detail="Cần xử lý hôm nay"
          icon="clock"
          tone="yellow"
        />
        <StatCard
          label="Đã hoàn thành"
          value="7.684"
          detail="Tỷ lệ hoàn thành 85,9%"
          icon="check"
          tone="green"
        />
      </div>
      <div className="dashboard-grid">
        <div className="card chart-large">
          <div className="card-head">
            <div>
              <h3>Thống kê lịch hẹn</h3>
              <p>7 ngày gần nhất</p>
            </div>
            <Select defaultValue="week">
              <option value="week">Tuần này</option>
              <option value="month">Tháng này</option>
            </Select>
          </div>
          <MiniLineChart />
          <div className="axis">
            <span>T2</span>
            <span>T3</span>
            <span>T4</span>
            <span>T5</span>
            <span>T6</span>
            <span>T7</span>
            <span>CN</span>
          </div>
        </div>
        <div className="card">
          <div className="card-head">
            <div>
              <h3>Phân bổ người dùng</h3>
              <p>Theo vai trò</p>
            </div>
          </div>
          <Donut
            center="2.478"
            parts={[
              { label: "Bệnh nhân", value: 78, color: "#286A9B" },
              { label: "Bác sĩ", value: 17, color: "#438FC2" },
              { label: "Quản trị viên", value: 5, color: "#E98DAE" },
            ]}
          />
        </div>
      </div>
      <div className="dashboard-grid three">
        <div className="card">
          <div className="card-head">
            <div>
              <h3>Trạng thái lịch hẹn</h3>
              <p>Trong tháng 06/2025</p>
            </div>
          </div>
          <Donut
            center="892"
            parts={[
              { label: "Hoàn thành", value: 64, color: "#286A9B" },
              { label: "Đã xác nhận", value: 21, color: "#438FC2" },
              { label: "Chờ xác nhận", value: 10, color: "#E9A23B" },
              { label: "Đã hủy", value: 5, color: "#DF6B68" },
            ]}
          />
        </div>
        <div className="card">
          <div className="card-head">
            <div>
              <h3>Lịch hẹn theo chuyên khoa</h3>
              <p>Top 5 chuyên khoa</p>
            </div>
          </div>
          <BarChart compact />
        </div>
        <div className="card quick">
          <div className="card-head">
            <div>
              <h3>Thao tác nhanh</h3>
              <p>Lối tắt quản trị</p>
            </div>
          </div>
          {[
            ["doctor", "Thêm bác sĩ", "doctors"],
            ["users", "Xem người dùng", "users"],
            ["briefcase", "Quản lý chuyên khoa", "specialties"],
            ["calendar", "Xem lịch hẹn", "appointments"],
          ].map((x) => (
            <button key={x[1]} onClick={() => setPage(x[2] as Page)}>
              <span>
                <Icon name={x[0]} />
              </span>
              {x[1]}
              <Icon name="chevron" size={16} />
            </button>
          ))}
        </div>
      </div>
      <div className="card">
        <div className="card-head">
          <div>
            <h3>Hoạt động gần đây</h3>
            <p>Cập nhật mới nhất trên hệ thống</p>
          </div>
          <Button variant="ghost" onClick={() => setPage("users")}>
            Xem tất cả
          </Button>
        </div>
        <div className="activity-list">
          {[
            [
              "doctor",
              "Tài khoản bác sĩ mới đã được tạo",
              "BS. Lê Đức Phúc · 10 phút trước",
              "Tài khoản",
            ],
            ["users", "Bệnh nhân mới đăng ký", "Đỗ Thanh Tâm · 35 phút trước", "Người dùng"],
            [
              "check",
              "Lịch hẹn LH-2401 đã được xác nhận",
              `${appointments[0].patient} · 1 giờ trước`,
              "Lịch hẹn",
            ],
            ["close", "Lịch hẹn LH-2404 đã bị hủy", "Hoàng Gia Bảo · 2 giờ trước", "Lịch hẹn"],
          ].map((a, i) => (
            <div className="activity" key={i}>
              <span className={`activity-icon a${i}`}>
                <Icon name={a[0]} size={18} />
              </span>
              <div>
                <b>{a[1]}</b>
                <small>{a[2]}</small>
              </div>
              <StatusBadge status={a[3]} />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function DataPageHeader({
  eyebrow,
  title,
  description,
  action,
  onAction,
}: {
  eyebrow: string;
  title: string;
  description: string;
  action?: string;
  onAction?: () => void;
}) {
  return (
    <div className="page-title">
      <div>
        <span className="eyebrow">{eyebrow}</span>
        <h2>{title}</h2>
        <p>{description}</p>
      </div>
      {action && (
        <Button onClick={onAction}>
          <Icon name="plus" size={18} />
          {action}
        </Button>
      )}
    </div>
  );
}

function UserForm({
  initial,
  onSave,
  onClose,
}: {
  initial?: User;
  onSave: (u: User) => void;
  onClose: () => void;
}) {
  const [form, setForm] = useState<User>(
    initial || {
      id: `USR-${Math.floor(300 + Math.random() * 600)}`,
      name: "",
      email: "",
      phone: "",
      role: "Bệnh nhân",
      status: "Hoạt động",
      created: "20/06/2025",
    },
  );
  const [error, setError] = useState("");
  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
      setError("Vui lòng nhập đầy đủ họ tên và email hợp lệ.");
      return;
    }
    onSave(form);
  };
  return (
    <form onSubmit={submit}>
      <div className="form-grid">
        <label className="span-2">
          Họ và tên *
          <Input
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            placeholder="Nguyễn Văn A"
          />
        </label>
        <label>
          Email *
          <Input
            type="email"
            value={form.email}
            onChange={(e) => setForm({ ...form, email: e.target.value })}
            placeholder="email@example.com"
          />
        </label>
        <label>
          Số điện thoại
          <Input
            value={form.phone}
            onChange={(e) => setForm({ ...form, phone: e.target.value })}
            placeholder="090 000 0000"
          />
        </label>
        <label>
          Vai trò
          <Select
            value={form.role}
            onChange={(e) => setForm({ ...form, role: e.target.value as User["role"] })}
          >
            <option>Admin</option>
            <option>Bác sĩ</option>
            <option>Bệnh nhân</option>
          </Select>
        </label>
        <label>
          Trạng thái
          <Select
            value={form.status}
            onChange={(e) => setForm({ ...form, status: e.target.value as User["status"] })}
          >
            <option>Hoạt động</option>
            <option>Tạm khóa</option>
          </Select>
        </label>
        {!initial && (
          <label className="span-2">
            Mật khẩu tạm thời *<Input type="password" placeholder="Tối thiểu 8 ký tự" />
          </label>
        )}
      </div>
      {error && <p className="form-error">{error}</p>}
      <div className="modal-actions">
        <Button variant="secondary" onClick={onClose}>
          Hủy
        </Button>
        <Button type="submit">{initial ? "Lưu thay đổi" : "Tạo người dùng"}</Button>
      </div>
    </form>
  );
}

function UsersPage({
  users,
  setUsers,
  notify,
}: {
  users: User[];
  setUsers: React.Dispatch<React.SetStateAction<User[]>>;
  notify: (s: string) => void;
}) {
  const [q, setQ] = useState(""),
    [role, setRole] = useState("Tất cả"),
    [status, setStatus] = useState("Tất cả"),
    [modal, setModal] = useState<"add" | "edit" | "confirm" | null>(null),
    [selected, setSelected] = useState<User>();
  const filtered = users.filter(
    (u) =>
      `${u.name} ${u.email} ${u.id}`.toLowerCase().includes(q.toLowerCase()) &&
      (role === "Tất cả" || u.role === role) &&
      (status === "Tất cả" || u.status === status),
  );
  const save = (u: User) => {
    setUsers((v) =>
      v.some((x) => x.id === u.id) ? v.map((x) => (x.id === u.id ? u : x)) : [u, ...v],
    );
    setModal(null);
    notify("Đã lưu thông tin người dùng");
  };
  const toggle = () => {
    if (selected)
      setUsers((v) =>
        v.map((x) =>
          x.id === selected.id
            ? { ...x, status: x.status === "Hoạt động" ? "Tạm khóa" : "Hoạt động" }
            : x,
        ),
      );
    setModal(null);
    notify("Đã cập nhật trạng thái tài khoản");
  };
  return (
    <div className="page-stack">
      <DataPageHeader
        eyebrow={`${users.length.toLocaleString("vi-VN")} tài khoản`}
        title="Quản lý người dùng"
        description="Quản lý tài khoản và quyền truy cập trên toàn hệ thống."
        action="Thêm người dùng"
        onAction={() => setModal("add")}
      />
      <div className="stat-grid three">
        <StatCard
          label="Tổng người dùng"
          value={users.length + 2480}
          detail="+126 trong tháng này"
          icon="users"
        />
        <StatCard
          label="Đang hoạt động"
          value="2.421"
          detail="97,4% tổng tài khoản"
          icon="check"
          tone="green"
        />
        <StatCard
          label="Tạm khóa"
          value="65"
          detail="2,6% tổng tài khoản"
          icon="clock"
          tone="orange"
        />
      </div>
      <div className="card table-card">
        <div className="toolbar">
          <SearchBar value={q} onChange={setQ} placeholder="Tên, email hoặc mã người dùng" />
          <div className="filters">
            <Select value={role} onChange={(e) => setRole(e.target.value)}>
              <option>Tất cả</option>
              <option>Admin</option>
              <option>Bác sĩ</option>
              <option>Bệnh nhân</option>
            </Select>
            <Select value={status} onChange={(e) => setStatus(e.target.value)}>
              <option>Tất cả</option>
              <option>Hoạt động</option>
              <option>Tạm khóa</option>
            </Select>
          </div>
        </div>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Mã người dùng ↕</th>
                <th>Họ và tên</th>
                <th>Email</th>
                <th>Số điện thoại</th>
                <th>Vai trò</th>
                <th>Trạng thái</th>
                <th>Ngày tạo</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((u) => (
                <tr key={u.id}>
                  <td>
                    <b>{u.id}</b>
                  </td>
                  <td>
                    <div className="person">
                      <Avatar name={u.name} size="sm" />
                      <b>{u.name}</b>
                    </div>
                  </td>
                  <td>{u.email}</td>
                  <td>{u.phone}</td>
                  <td>{u.role}</td>
                  <td>
                    <StatusBadge status={u.status} />
                  </td>
                  <td>{u.created}</td>
                  <td>
                    <div className="row-actions">
                      <button
                        title="Xem"
                        onClick={() => {
                          setSelected(u);
                          setModal("edit");
                        }}
                      >
                        <Icon name="eye" size={17} />
                      </button>
                      <button
                        title="Sửa"
                        onClick={() => {
                          setSelected(u);
                          setModal("edit");
                        }}
                      >
                        <Icon name="edit" size={17} />
                      </button>
                      <button
                        title="Đổi trạng thái"
                        onClick={() => {
                          setSelected(u);
                          setModal("confirm");
                        }}
                      >
                        <Icon name="dots" size={17} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {!filtered.length && <EmptyState />}
        </div>
        <Pagination total={filtered.length} />
      </div>
      {modal === "add" && (
        <Modal title="Thêm người dùng" onClose={() => setModal(null)}>
          <UserForm onSave={save} onClose={() => setModal(null)} />
        </Modal>
      )}
      {modal === "edit" && selected && (
        <Modal title="Thông tin người dùng" onClose={() => setModal(null)}>
          <UserForm initial={selected} onSave={save} onClose={() => setModal(null)} />
        </Modal>
      )}
      {modal === "confirm" && selected && (
        <ConfirmDialog
          title={selected.status === "Hoạt động" ? "Tạm khóa tài khoản?" : "Kích hoạt tài khoản?"}
          description={`Bạn có chắc muốn cập nhật trạng thái tài khoản của ${selected.name}?`}
          onConfirm={toggle}
          onClose={() => setModal(null)}
        />
      )}
    </div>
  );
}

function DoctorForm({
  initial,
  onSave,
  onClose,
}: {
  initial?: Doctor;
  onSave: (d: Doctor) => void;
  onClose: () => void;
}) {
  const [f, setF] = useState<Doctor>(
    initial || {
      id: `BS-${150 + Math.floor(Math.random() * 30)}`,
      name: "",
      specialty: "Tim mạch",
      email: "",
      phone: "",
      status: "Hoạt động",
      gender: "Nam",
      dob: "",
    },
  );
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        if (f.name && f.email) onSave(f);
      }}
    >
      <div className="form-grid">
        <label className="span-2">
          Họ và tên *
          <Input required value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
        </label>
        <label>
          Chuyên khoa
          <Select value={f.specialty} onChange={(e) => setF({ ...f, specialty: e.target.value })}>
            {initialSpecialties.map((s) => (
              <option key={s.id}>{s.name}</option>
            ))}
          </Select>
        </label>
        <label>
          Giới tính
          <Select value={f.gender} onChange={(e) => setF({ ...f, gender: e.target.value })}>
            <option>Nam</option>
            <option>Nữ</option>
            <option>Khác</option>
          </Select>
        </label>
        <label>
          Email *
          <Input
            required
            type="email"
            value={f.email}
            onChange={(e) => setF({ ...f, email: e.target.value })}
          />
        </label>
        <label>
          Số điện thoại
          <Input value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} />
        </label>
        <label>
          Ngày sinh
          <Input
            value={f.dob}
            onChange={(e) => setF({ ...f, dob: e.target.value })}
            placeholder="dd/mm/yyyy"
          />
        </label>
        <label>
          Trạng thái
          <Select
            value={f.status}
            onChange={(e) => setF({ ...f, status: e.target.value as Doctor["status"] })}
          >
            <option>Hoạt động</option>
            <option>Tạm khóa</option>
          </Select>
        </label>
      </div>
      <div className="modal-actions">
        <Button variant="secondary" onClick={onClose}>
          Hủy
        </Button>
        <Button type="submit">Lưu thông tin</Button>
      </div>
    </form>
  );
}
function DoctorsPage({
  doctors,
  setDoctors,
  notify,
}: {
  doctors: Doctor[];
  setDoctors: React.Dispatch<React.SetStateAction<Doctor[]>>;
  notify: (s: string) => void;
}) {
  const [q, setQ] = useState(""),
    [specialty, setSpecialty] = useState("Tất cả"),
    [modal, setModal] = useState<"add" | "edit" | "detail" | null>(null),
    [selected, setSelected] = useState<Doctor>();
  const list = doctors.filter(
    (d) =>
      (d.name.toLowerCase().includes(q.toLowerCase()) ||
        d.id.toLowerCase().includes(q.toLowerCase())) &&
      (specialty === "Tất cả" || d.specialty === specialty),
  );
  const save = (d: Doctor) => {
    setDoctors((v) =>
      v.some((x) => x.id === d.id) ? v.map((x) => (x.id === d.id ? d : x)) : [d, ...v],
    );
    setModal(null);
    notify("Đã lưu hồ sơ bác sĩ");
  };
  return (
    <div className="page-stack">
      <DataPageHeader
        eyebrow="Danh mục nhân sự y tế"
        title="Quản lý bác sĩ"
        description="Theo dõi hồ sơ, chuyên khoa và trạng thái hoạt động."
        action="Thêm bác sĩ"
        onAction={() => setModal("add")}
      />
      <div className="stat-grid three">
        <StatCard
          label="Tổng bác sĩ"
          value={doctors.length + 121}
          detail="Trên 5 chuyên khoa"
          icon="doctor"
        />
        <StatCard
          label="Đang hoạt động"
          value={doctors.filter((d) => d.status === "Hoạt động").length + 117}
          detail="96,8% tổng bác sĩ"
          icon="check"
          tone="green"
        />
        <StatCard
          label="Tạm khóa"
          value={doctors.filter((d) => d.status === "Tạm khóa").length}
          detail="Cần rà soát"
          icon="clock"
          tone="orange"
        />
      </div>
      <div className="card table-card">
        <div className="toolbar">
          <SearchBar value={q} onChange={setQ} placeholder="Tên hoặc mã bác sĩ" />
          <div className="filters">
            <Select value={specialty} onChange={(e) => setSpecialty(e.target.value)}>
              <option>Tất cả</option>
              {initialSpecialties.map((s) => (
                <option key={s.id}>{s.name}</option>
              ))}
            </Select>
          </div>
        </div>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Mã bác sĩ</th>
                <th>Bác sĩ</th>
                <th>Chuyên khoa</th>
                <th>Email</th>
                <th>Số điện thoại</th>
                <th>Trạng thái</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {list.map((d) => (
                <tr key={d.id}>
                  <td>
                    <b>{d.id}</b>
                  </td>
                  <td>
                    <div className="person">
                      <Avatar name={d.name} size="sm" />
                      <b>BS. {d.name}</b>
                    </div>
                  </td>
                  <td>{d.specialty}</td>
                  <td>{d.email}</td>
                  <td>{d.phone}</td>
                  <td>
                    <StatusBadge status={d.status} />
                  </td>
                  <td>
                    <div className="row-actions">
                      <button
                        onClick={() => {
                          setSelected(d);
                          setModal("detail");
                        }}
                      >
                        <Icon name="eye" size={17} />
                      </button>
                      <button
                        onClick={() => {
                          setSelected(d);
                          setModal("edit");
                        }}
                      >
                        <Icon name="edit" size={17} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {!list.length && <EmptyState />}
        </div>
        <Pagination total={list.length} />
      </div>
      {modal === "add" && (
        <Modal title="Thêm bác sĩ" onClose={() => setModal(null)}>
          <DoctorForm onSave={save} onClose={() => setModal(null)} />
        </Modal>
      )}
      {modal === "edit" && selected && (
        <Modal title="Chỉnh sửa bác sĩ" onClose={() => setModal(null)}>
          <DoctorForm initial={selected} onSave={save} onClose={() => setModal(null)} />
        </Modal>
      )}
      {modal === "detail" && selected && (
        <Modal title="Hồ sơ bác sĩ" onClose={() => setModal(null)} wide>
          <ProfileDetail
            avatar={selected.name}
            title={`BS. ${selected.name}`}
            subtitle={selected.specialty}
            fields={[
              ["Mã bác sĩ", selected.id],
              ["Email", selected.email],
              ["Số điện thoại", selected.phone],
              ["Giới tính", selected.gender],
              ["Ngày sinh", selected.dob],
              ["Trạng thái", selected.status],
            ]}
          />
          <div className="detail-panels">
            <div>
              <h4>Thông tin chuyên môn</h4>
              <p>
                Đang công tác tại chuyên khoa {selected.specialty}. Hồ sơ chuyên môn được quản lý
                nội bộ tại TiTiMi.
              </p>
            </div>
            <div>
              <h4>Thống kê lịch hẹn</h4>
              <strong>148</strong>
              <p>Lịch hẹn trong 30 ngày · 92% hoàn thành</p>
            </div>
          </div>
          <div className="modal-actions">
            <Button onClick={() => setModal("edit")}>Chỉnh sửa hồ sơ</Button>
          </div>
        </Modal>
      )}
    </div>
  );
}
function ProfileDetail({
  avatar,
  title,
  subtitle,
  fields,
}: {
  avatar: string;
  title: string;
  subtitle: string;
  fields: string[][];
}) {
  return (
    <>
      <div className="profile-hero">
        <Avatar name={avatar} size="lg" />
        <div>
          <h3>{title}</h3>
          <p>{subtitle}</p>
        </div>
      </div>
      <div className="detail-grid">
        {fields.map((f) => (
          <div key={f[0]}>
            <small>{f[0]}</small>
            <b>{f[1]}</b>
          </div>
        ))}
      </div>
    </>
  );
}

function PatientsPage({
  patients,
  setPatients,
  notify,
}: {
  patients: Patient[];
  setPatients: React.Dispatch<React.SetStateAction<Patient[]>>;
  notify: (s: string) => void;
}) {
  const [q, setQ] = useState(""),
    [gender, setGender] = useState("Tất cả"),
    [modal, setModal] = useState<"add" | "edit" | "detail" | null>(null),
    [selected, setSelected] = useState<Patient>();
  const list = patients.filter(
    (p) =>
      `${p.name} ${p.id} ${p.phone}`.toLowerCase().includes(q.toLowerCase()) &&
      (gender === "Tất cả" || p.gender === gender),
  );
  const save = (p: Patient) => {
    setPatients((v) =>
      v.some((x) => x.id === p.id) ? v.map((x) => (x.id === p.id ? p : x)) : [p, ...v],
    );
    setModal(null);
    notify("Đã lưu hồ sơ bệnh nhân");
  };
  return (
    <div className="page-stack">
      <DataPageHeader
        eyebrow={`${patients.length + 2348} hồ sơ`}
        title="Quản lý bệnh nhân"
        description="Quản lý thông tin cơ bản và lịch sử tương tác của bệnh nhân."
        action="Thêm bệnh nhân"
        onAction={() => setModal("add")}
      />
      <div className="card table-card">
        <div className="toolbar">
          <SearchBar value={q} onChange={setQ} placeholder="Tên, mã hoặc số điện thoại" />
          <div className="filters">
            <Select value={gender} onChange={(e) => setGender(e.target.value)}>
              <option>Tất cả</option>
              <option>Nam</option>
              <option>Nữ</option>
            </Select>
            <Input type="date" title="Ngày đăng ký" />
          </div>
        </div>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Mã bệnh nhân</th>
                <th>Họ và tên</th>
                <th>Giới tính</th>
                <th>Ngày sinh</th>
                <th>Số điện thoại</th>
                <th>Email</th>
                <th>Ngày đăng ký</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {list.map((p) => (
                <tr key={p.id}>
                  <td>
                    <b>{p.id}</b>
                  </td>
                  <td>
                    <div className="person">
                      <Avatar name={p.name} size="sm" />
                      <b>{p.name}</b>
                    </div>
                  </td>
                  <td>{p.gender}</td>
                  <td>{p.dob}</td>
                  <td>{p.phone}</td>
                  <td>{p.email}</td>
                  <td>{p.created}</td>
                  <td>
                    <div className="row-actions">
                      <button
                        onClick={() => {
                          setSelected(p);
                          setModal("detail");
                        }}
                      >
                        <Icon name="eye" size={17} />
                      </button>
                      <button
                        onClick={() => {
                          setSelected(p);
                          setModal("edit");
                        }}
                      >
                        <Icon name="edit" size={17} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {!list.length && <EmptyState />}
        </div>
        <Pagination total={list.length} />
      </div>
      {(modal === "add" || modal === "edit") && (
        <Modal
          title={modal === "add" ? "Thêm bệnh nhân" : "Chỉnh sửa bệnh nhân"}
          onClose={() => setModal(null)}
        >
          <PatientForm
            initial={modal === "edit" ? selected : undefined}
            onSave={save}
            onClose={() => setModal(null)}
          />
        </Modal>
      )}
      {modal === "detail" && selected && (
        <Modal title="Hồ sơ bệnh nhân" onClose={() => setModal(null)} wide>
          <ProfileDetail
            avatar={selected.name}
            title={selected.name}
            subtitle={selected.id}
            fields={[
              ["Giới tính", selected.gender],
              ["Ngày sinh", selected.dob],
              ["Số điện thoại", selected.phone],
              ["Email", selected.email],
              ["Ngày đăng ký", selected.created],
              ["Trạng thái", selected.status],
            ]}
          />
          <div className="tabs">
            <button className="active">Lịch hẹn (12)</button>
            <button>Lịch sử khám (8)</button>
            <button>Hồ sơ y tế</button>
          </div>
          <div className="privacy-note">
            <Icon name="heart" />
            <div>
              <b>Tổng quan hồ sơ y tế</b>
              <p>
                Thông tin y tế chi tiết chỉ hiển thị theo quyền quản trị được cấp. Lần khám gần
                nhất: 12/06/2025.
              </p>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
function PatientForm({
  initial,
  onSave,
  onClose,
}: {
  initial?: Patient;
  onSave: (p: Patient) => void;
  onClose: () => void;
}) {
  const [f, setF] = useState<Patient>(
    initial || {
      id: `BN-${240 + Math.floor(Math.random() * 50)}`,
      name: "",
      gender: "Nam",
      dob: "",
      phone: "",
      email: "",
      created: "20/06/2025",
      status: "Hoạt động",
    },
  );
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        onSave(f);
      }}
    >
      <div className="form-grid">
        <label className="span-2">
          Họ và tên *
          <Input required value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
        </label>
        <label>
          Giới tính
          <Select value={f.gender} onChange={(e) => setF({ ...f, gender: e.target.value })}>
            <option>Nam</option>
            <option>Nữ</option>
            <option>Khác</option>
          </Select>
        </label>
        <label>
          Ngày sinh
          <Input
            value={f.dob}
            onChange={(e) => setF({ ...f, dob: e.target.value })}
            placeholder="dd/mm/yyyy"
          />
        </label>
        <label>
          Số điện thoại
          <Input value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} />
        </label>
        <label>
          Email
          <Input
            type="email"
            value={f.email}
            onChange={(e) => setF({ ...f, email: e.target.value })}
          />
        </label>
        <label>
          Trạng thái
          <Select
            value={f.status}
            onChange={(e) => setF({ ...f, status: e.target.value as Patient["status"] })}
          >
            <option>Hoạt động</option>
            <option>Tạm khóa</option>
          </Select>
        </label>
      </div>
      <div className="modal-actions">
        <Button variant="secondary" onClick={onClose}>
          Hủy
        </Button>
        <Button type="submit">Lưu thông tin</Button>
      </div>
    </form>
  );
}

function SpecialtiesPage({
  items,
  setItems,
  notify,
}: {
  items: Specialty[];
  setItems: React.Dispatch<React.SetStateAction<Specialty[]>>;
  notify: (s: string) => void;
}) {
  const [q, setQ] = useState(""),
    [modal, setModal] = useState<"form" | "confirm" | "doctors" | null>(null),
    [selected, setSelected] = useState<Specialty>(),
    list = items.filter((s) => s.name.toLowerCase().includes(q.toLowerCase()));
  const save = (s: Specialty) => {
    if (items.some((x) => x.name.toLowerCase() === s.name.toLowerCase() && x.id !== s.id)) {
      notify("Tên chuyên khoa đã tồn tại");
      return;
    }
    setItems((v) =>
      v.some((x) => x.id === s.id) ? v.map((x) => (x.id === s.id ? s : x)) : [s, ...v],
    );
    setModal(null);
    notify("Đã lưu chuyên khoa");
  };
  return (
    <div className="page-stack">
      <DataPageHeader
        eyebrow={`${items.length} chuyên khoa`}
        title="Quản lý chuyên khoa"
        description="Cấu hình danh mục chuyên môn đang hoạt động tại phòng khám."
        action="Thêm chuyên khoa"
        onAction={() => {
          setSelected(undefined);
          setModal("form");
        }}
      />
      <div className="card table-card">
        <div className="toolbar">
          <SearchBar value={q} onChange={setQ} placeholder="Tìm tên chuyên khoa" />
          <Select>
            <option>Tất cả trạng thái</option>
            <option>Hoạt động</option>
            <option>Tạm ngưng</option>
          </Select>
        </div>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Mã chuyên khoa</th>
                <th>Tên chuyên khoa</th>
                <th>Mô tả</th>
                <th>Số bác sĩ</th>
                <th>Trạng thái</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {list.map((s) => (
                <tr key={s.id}>
                  <td>
                    <b>{s.id}</b>
                  </td>
                  <td>
                    <b>{s.name}</b>
                  </td>
                  <td className="description-cell">{s.description}</td>
                  <td>{s.doctors} bác sĩ</td>
                  <td>
                    <StatusBadge status={s.status} />
                  </td>
                  <td>
                    <div className="row-actions">
                      <button
                        title="Xem bác sĩ"
                        onClick={() => {
                          setSelected(s);
                          setModal("doctors");
                        }}
                      >
                        <Icon name="users" size={17} />
                      </button>
                      <button
                        onClick={() => {
                          setSelected(s);
                          setModal("form");
                        }}
                      >
                        <Icon name="edit" size={17} />
                      </button>
                      <button
                        onClick={() => {
                          setSelected(s);
                          setModal("confirm");
                        }}
                      >
                        <Icon name="dots" size={17} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <Pagination total={list.length} />
      </div>
      {modal === "form" && (
        <Modal
          title={selected ? "Chỉnh sửa chuyên khoa" : "Thêm chuyên khoa"}
          onClose={() => setModal(null)}
        >
          <SpecialtyForm initial={selected} onSave={save} onClose={() => setModal(null)} />
        </Modal>
      )}
      {modal === "confirm" && selected && (
        <ConfirmDialog
          title="Cập nhật trạng thái chuyên khoa?"
          description={`Các lịch hẹn hiện tại không bị ảnh hưởng. Bạn có chắc muốn thay đổi trạng thái ${selected.name}?`}
          onClose={() => setModal(null)}
          onConfirm={() => {
            setItems((v) =>
              v.map((x) =>
                x.id === selected.id
                  ? { ...x, status: x.status === "Hoạt động" ? "Tạm ngưng" : "Hoạt động" }
                  : x,
              ),
            );
            setModal(null);
            notify("Đã cập nhật trạng thái chuyên khoa");
          }}
        />
      )}
      {modal === "doctors" && selected && (
        <Modal title={`Bác sĩ · ${selected.name}`} onClose={() => setModal(null)}>
          <p className="modal-copy">Hiện có {selected.doctors} bác sĩ thuộc chuyên khoa này.</p>
          {initialDoctors
            .filter((d) => d.specialty === selected.name)
            .map((d) => (
              <div className="mini-person" key={d.id}>
                <Avatar name={d.name} />
                <div>
                  <b>BS. {d.name}</b>
                  <small>
                    {d.id} · {d.email}
                  </small>
                </div>
              </div>
            ))}
        </Modal>
      )}
    </div>
  );
}
function SpecialtyForm({
  initial,
  onSave,
  onClose,
}: {
  initial?: Specialty;
  onSave: (s: Specialty) => void;
  onClose: () => void;
}) {
  const [f, setF] = useState<Specialty>(
    initial || {
      id: `CK-0${initialSpecialties.length + 1}`,
      name: "",
      description: "",
      doctors: 0,
      status: "Hoạt động",
    },
  );
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        onSave(f);
      }}
    >
      <div className="form-grid one">
        <label>
          Tên chuyên khoa *
          <Input required value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
        </label>
        <label>
          Mô tả
          <textarea
            className="field"
            rows={4}
            value={f.description}
            onChange={(e) => setF({ ...f, description: e.target.value })}
          />
        </label>
        <label>
          Trạng thái
          <Select
            value={f.status}
            onChange={(e) => setF({ ...f, status: e.target.value as Specialty["status"] })}
          >
            <option>Hoạt động</option>
            <option>Tạm ngưng</option>
          </Select>
        </label>
      </div>
      <div className="modal-actions">
        <Button variant="secondary" onClick={onClose}>
          Hủy
        </Button>
        <Button type="submit">Lưu chuyên khoa</Button>
      </div>
    </form>
  );
}

function AppointmentsPage({
  appointments,
  patients,
  doctors,
  specialties,
  onCreate,
  notify,
}: {
  appointments: Appointment[];
  patients: Patient[];
  doctors: Doctor[];
  specialties: Specialty[];
  onCreate: (appointment: Appointment) => void;
  notify: (message: string) => void;
}) {
  const [q, setQ] = useState(""),
    [status, setStatus] = useState("Tất cả"),
    [selected, setSelected] = useState<Appointment>(),
    [creating, setCreating] = useState(false),
    list = appointments.filter(
      (a) =>
        `${a.id} ${a.patient} ${a.doctor}`.toLowerCase().includes(q.toLowerCase()) &&
        (status === "Tất cả" || a.status === status),
    );
  return (
    <div className="page-stack">
      <DataPageHeader
        eyebrow="Theo dõi toàn hệ thống"
        title="Quản lý lịch hẹn"
        description="Tra cứu và giám sát hoạt động đặt lịch tại các chuyên khoa."
        action="Tạo lịch hẹn"
        onAction={() => setCreating(true)}
      />
      <div className="stat-grid five">
        <StatCard
          label="Tổng lịch hẹn"
          value={(8942 + appointments.length - initialAppointments.length).toLocaleString("vi-VN")}
          detail="Từ trước đến nay"
          icon="calendar"
        />
        <StatCard
          label="Chờ xác nhận"
          value={48 + appointments.length - initialAppointments.length}
          detail="Cần xử lý"
          icon="clock"
          tone="yellow"
        />
        <StatCard label="Đã xác nhận" value="162" detail="Sắp diễn ra" icon="check" tone="blue" />
        <StatCard
          label="Hoàn thành"
          value="7.684"
          detail="85,9% tổng số"
          icon="check"
          tone="green"
        />
        <StatCard label="Đã hủy" value="1.048" detail="11,7% tổng số" icon="close" tone="red" />
      </div>
      <div className="card table-card">
        <div className="toolbar">
          <SearchBar value={q} onChange={setQ} placeholder="Mã, bệnh nhân hoặc bác sĩ" />
          <div className="filters">
            <Input type="date" />
            <Select value={status} onChange={(e) => setStatus(e.target.value)}>
              <option>Tất cả</option>
              <option>Chờ xác nhận</option>
              <option>Đã xác nhận</option>
              <option>Hoàn thành</option>
              <option>Đã hủy</option>
            </Select>
            <Select>
              <option>Tất cả chuyên khoa</option>
              {initialSpecialties.map((s) => (
                <option key={s.id}>{s.name}</option>
              ))}
            </Select>
          </div>
        </div>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Mã lịch hẹn</th>
                <th>Bệnh nhân</th>
                <th>Bác sĩ</th>
                <th>Chuyên khoa</th>
                <th>Ngày & giờ</th>
                <th>Lý do khám</th>
                <th>Trạng thái</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {list.map((a) => (
                <tr key={a.id}>
                  <td>
                    <b>{a.id}</b>
                  </td>
                  <td>{a.patient}</td>
                  <td>BS. {a.doctor}</td>
                  <td>
                    {a.specialty}
                    {a.visitType && <small className="block">{a.visitType}</small>}
                  </td>
                  <td>
                    <b>{a.date}</b>
                    <small className="block">{a.time}</small>
                  </td>
                  <td>
                    {a.isFollowUp && <span className="follow-up-tag">Tái khám</span>}
                    {a.reason}
                  </td>
                  <td>
                    <StatusBadge status={a.status} />
                  </td>
                  <td>
                    <button className="icon-btn" onClick={() => setSelected(a)}>
                      <Icon name="eye" size={17} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {!list.length && <EmptyState />}
        </div>
        <Pagination total={list.length} />
      </div>
      {selected && (
        <AppointmentDetail appointment={selected} onClose={() => setSelected(undefined)} />
      )}
      {creating && (
        <CreateAppointmentModal
          appointments={appointments}
          patients={patients}
          doctors={doctors}
          specialties={specialties}
          onClose={() => setCreating(false)}
          onConfirm={(appointment) => {
            onCreate(appointment);
            setCreating(false);
            notify(`Đã tạo lịch hẹn ${appointment.id} thành công`);
          }}
        />
      )}
    </div>
  );
}

function CreateAppointmentModal({
  appointments,
  patients,
  doctors,
  specialties,
  onClose,
  onConfirm,
}: {
  appointments: Appointment[];
  patients: Patient[];
  doctors: Doctor[];
  specialties: Specialty[];
  onClose: () => void;
  onConfirm: (appointment: Appointment) => void;
}) {
  const [step, setStep] = useState(1);
  const [patientQuery, setPatientQuery] = useState("");
  const [doctorQuery, setDoctorQuery] = useState("");
  const [specialtyQuery, setSpecialtyQuery] = useState("");
  const [patient, setPatient] = useState<Patient>();
  const [visitType, setVisitType] = useState<Appointment["visitType"]>();
  const [specialty, setSpecialty] = useState("");
  const [doctor, setDoctor] = useState<Doctor>();
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [reason, setReason] = useState("");
  const [isFollowUp, setIsFollowUp] = useState(false);

  const stepLabels = ["Bệnh nhân", "Hình thức", "Chuyên khoa", "Bác sĩ", "Ngày & giờ", "Xác nhận"];
  const onlineDoctorIds = ["BS-102", "BS-118", "BS-126"];
  const patientResults = patients.filter(
    (item) =>
      item.status === "Hoạt động" &&
      `${item.name} ${item.id}`.toLowerCase().includes(patientQuery.toLowerCase()),
  );
  const specialtyResults = specialties.filter(
    (item) =>
      item.status === "Hoạt động" && item.name.toLowerCase().includes(specialtyQuery.toLowerCase()),
  );
  const doctorResults = doctors.filter(
    (item) =>
      item.status === "Hoạt động" &&
      item.specialty === specialty &&
      (visitType === "Khám trực tiếp" || onlineDoctorIds.includes(item.id)) &&
      item.name.toLowerCase().includes(doctorQuery.toLowerCase()),
  );
  const slots = ["08:00", "08:30", "09:15", "10:00", "10:45", "13:30", "14:30", "15:15", "16:00"];
  const formattedDate = date ? date.split("-").reverse().join("/") : "";
  const unavailableSlots = slots.filter((slot) =>
    appointments.some(
      (item) =>
        item.doctor === doctor?.name &&
        item.date === formattedDate &&
        item.time === slot &&
        item.status !== "Đã hủy",
    ),
  );
  const isSunday = date ? new Date(`${date}T12:00:00`).getDay() === 0 : false;
  const availableSlots = isSunday ? [] : slots.filter((slot) => !unavailableSlots.includes(slot));
  const fee = visitType === "Tư vấn trực tuyến" ? 250000 : 350000;
  const canContinue =
    (step === 1 && Boolean(patient)) ||
    (step === 2 && Boolean(visitType)) ||
    (step === 3 && Boolean(specialty)) ||
    (step === 4 && Boolean(doctor)) ||
    (step === 5 && Boolean(date && time));

  const createAppointment = () => {
    if (!patient || !visitType || !specialty || !doctor || !date || !time) return;
    const highestId = appointments.reduce((max, item) => {
      const number = Number(item.id.replace(/\D/g, ""));
      return Number.isFinite(number) ? Math.max(max, number) : max;
    }, 2400);
    onConfirm({
      id: `LH-${highestId + 1}`,
      patient: patient.name,
      patientId: patient.id,
      doctor: doctor.name,
      specialty,
      date: formattedDate,
      time,
      reason: reason.trim() || (isFollowUp ? "Tái khám theo lịch" : "Khám theo lịch hẹn"),
      visitType,
      isFollowUp,
      fee,
      status: "Chờ xác nhận",
    });
  };

  return (
    <Modal title="Tạo lịch hẹn mới" onClose={onClose} wide>
      <div className="appointment-steps" aria-label={`Bước ${step} trên 6`}>
        {stepLabels.map((label, index) => (
          <div
            className={`${index + 1 === step ? "active" : ""} ${index + 1 < step ? "done" : ""}`}
            key={label}
          >
            <span>{index + 1 < step ? <Icon name="check" size={13} /> : index + 1}</span>
            <small>{label}</small>
          </div>
        ))}
      </div>

      <div className="appointment-step-content">
        {step === 1 && (
          <div className="selection-step">
            <div className="step-heading">
              <span>Bước 1</span>
              <h3>Chọn bệnh nhân</h3>
              <p>Tìm theo họ tên hoặc mã bệnh nhân đang hoạt động.</p>
            </div>
            <SearchBar
              value={patientQuery}
              onChange={setPatientQuery}
              placeholder="Nhập tên hoặc mã bệnh nhân..."
            />
            <div className="selection-list">
              {patientResults.map((item) => (
                <button
                  className={`selection-card ${patient?.id === item.id ? "selected" : ""}`}
                  key={item.id}
                  onClick={() => setPatient(item)}
                >
                  <Avatar name={item.name} />
                  <div>
                    <b>{item.name}</b>
                    <small>
                      {item.id} · {item.phone}
                    </small>
                    <small>{item.email}</small>
                  </div>
                  <span className="selection-check">
                    {patient?.id === item.id && <Icon name="check" size={14} />}
                  </span>
                </button>
              ))}
              {!patientResults.length && <EmptyState />}
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="selection-step">
            <div className="step-heading">
              <span>Bước 2</span>
              <h3>Chọn hình thức khám</h3>
              <p>Chọn hình thức phù hợp với nhu cầu của bệnh nhân.</p>
            </div>
            <div className="visit-type-grid">
              {[
                ["Khám trực tiếp", "calendar", "Khám tại phòng khám TiTiMi"],
                ["Tư vấn trực tuyến", "doctor", "Tư vấn từ xa với bác sĩ hỗ trợ"],
              ].map(([type, icon, description]) => (
                <button
                  className={visitType === type ? "selected" : ""}
                  key={type}
                  onClick={() => {
                    setVisitType(type as Appointment["visitType"]);
                    setDoctor(undefined);
                    setTime("");
                  }}
                >
                  <span>
                    <Icon name={icon} />
                  </span>
                  <b>{type}</b>
                  <small>{description}</small>
                  <i>{visitType === type && <Icon name="check" size={13} />}</i>
                </button>
              ))}
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="selection-step">
            <div className="step-heading">
              <span>Bước 3</span>
              <h3>Chọn chuyên khoa</h3>
              <p>Danh sách chỉ gồm các chuyên khoa đang hoạt động.</p>
            </div>
            <SearchBar
              value={specialtyQuery}
              onChange={setSpecialtyQuery}
              placeholder="Tìm chuyên khoa..."
            />
            <div className="specialty-choice-grid">
              {specialtyResults.map((item) => (
                <button
                  className={specialty === item.name ? "selected" : ""}
                  key={item.id}
                  onClick={() => {
                    setSpecialty(item.name);
                    setDoctor(undefined);
                    setTime("");
                  }}
                >
                  <span>
                    <Icon name="briefcase" />
                  </span>
                  <div>
                    <b>{item.name}</b>
                    <small>{item.description}</small>
                  </div>
                  {specialty === item.name && <Icon name="check" size={16} />}
                </button>
              ))}
            </div>
          </div>
        )}

        {step === 4 && (
          <div className="selection-step">
            <div className="step-heading">
              <span>Bước 4</span>
              <h3>Chọn bác sĩ</h3>
              <p>
                Bác sĩ thuộc chuyên khoa {specialty} và hỗ trợ {visitType?.toLowerCase()}.
              </p>
            </div>
            <SearchBar
              value={doctorQuery}
              onChange={setDoctorQuery}
              placeholder="Tìm bác sĩ theo tên..."
            />
            <div className="selection-list">
              {doctorResults.map((item) => (
                <button
                  className={`selection-card ${doctor?.id === item.id ? "selected" : ""}`}
                  key={item.id}
                  onClick={() => {
                    setDoctor(item);
                    setTime("");
                  }}
                >
                  <Avatar name={item.name} />
                  <div>
                    <b>BS. {item.name}</b>
                    <small>
                      {item.id} · {item.specialty}
                    </small>
                    <small>
                      {visitType === "Tư vấn trực tuyến"
                        ? "Có hỗ trợ tư vấn trực tuyến"
                        : "Khám trực tiếp tại TiTiMi"}
                    </small>
                  </div>
                  <span className="selection-check">
                    {doctor?.id === item.id && <Icon name="check" size={14} />}
                  </span>
                </button>
              ))}
              {!doctorResults.length && (
                <div className="slot-message">
                  Không có bác sĩ phù hợp với chuyên khoa và hình thức khám đã chọn.
                </div>
              )}
            </div>
          </div>
        )}

        {step === 5 && (
          <div className="selection-step">
            <div className="step-heading">
              <span>Bước 5</span>
              <h3>Chọn ngày và giờ</h3>
              <p>Khung giờ đã có lịch được khóa tự động.</p>
            </div>
            <div className="date-reason-grid">
              <label>
                Ngày khám *
                <Input
                  type="date"
                  min="2025-06-20"
                  value={date}
                  onChange={(event) => {
                    setDate(event.target.value);
                    setTime("");
                  }}
                />
              </label>
              <label>
                Lý do khám
                <Input
                  value={reason}
                  onChange={(event) => setReason(event.target.value)}
                  placeholder="Ví dụ: Khám đau đầu"
                />
              </label>
            </div>
            <label className="follow-up-option">
              <input
                type="checkbox"
                checked={isFollowUp}
                onChange={(event) => setIsFollowUp(event.target.checked)}
              />
              <span />
              <div>
                <b>Đây là lịch tái khám</b>
                <small>Lịch sẽ được đánh dấu riêng trong danh sách quản trị.</small>
              </div>
            </label>
            {date && availableSlots.length > 0 && (
              <>
                <div className="slot-label">
                  <b>Khung giờ còn trống</b>
                  <small>{formattedDate}</small>
                </div>
                <div className="time-slots">
                  {slots.map((slot) => {
                    const unavailable = unavailableSlots.includes(slot);
                    return (
                      <button
                        className={time === slot ? "selected" : ""}
                        disabled={unavailable}
                        key={slot}
                        onClick={() => setTime(slot)}
                      >
                        {slot}
                        {unavailable && <small>Đã đặt</small>}
                      </button>
                    );
                  })}
                </div>
              </>
            )}
            {date && !availableSlots.length && (
              <div className="slot-message">
                <Icon name="clock" />
                <div>
                  <b>Không còn khung giờ phù hợp</b>
                  <p>Vui lòng chọn một ngày khác để tiếp tục.</p>
                </div>
              </div>
            )}
          </div>
        )}

        {step === 6 && patient && doctor && (
          <div className="selection-step">
            <div className="step-heading">
              <span>Bước 6</span>
              <h3>Xác nhận lịch hẹn</h3>
              <p>Kiểm tra thông tin trước khi tạo lịch trên hệ thống.</p>
            </div>
            <div className="appointment-summary">
              <div className="summary-person">
                <Avatar name={patient.name} />
                <div>
                  <small>Bệnh nhân</small>
                  <b>{patient.name}</b>
                  <span>
                    {patient.id} · {patient.phone}
                  </span>
                </div>
              </div>
              <div className="summary-grid">
                {[
                  ["Hình thức khám", visitType || ""],
                  ["Chuyên khoa", specialty],
                  ["Bác sĩ", `BS. ${doctor.name}`],
                  ["Ngày khám", formattedDate],
                  ["Giờ khám", time],
                  ["Phí khám dự kiến", `${fee.toLocaleString("vi-VN")} ₫`],
                ].map(([label, value]) => (
                  <div key={label}>
                    <small>{label}</small>
                    <b>{value}</b>
                  </div>
                ))}
              </div>
              {isFollowUp && (
                <div className="summary-follow-up">
                  <Icon name="clock" size={17} />
                  Lịch tái khám
                </div>
              )}
              <p className="summary-note">
                Lịch hẹn sẽ có trạng thái ban đầu là “Chờ xác nhận” và cần bác sĩ xác nhận.
              </p>
            </div>
          </div>
        )}
      </div>

      <div className="appointment-wizard-actions">
        <Button variant="secondary" onClick={step === 1 ? onClose : () => setStep(step - 1)}>
          {step === 1 ? "Hủy" : "Quay lại"}
        </Button>
        {step < 6 ? (
          <Button disabled={!canContinue} onClick={() => setStep(step + 1)}>
            Tiếp tục
            <Icon name="chevron" size={16} />
          </Button>
        ) : (
          <Button onClick={createAppointment}>
            <Icon name="check" size={17} />
            Xác nhận tạo lịch
          </Button>
        )}
      </div>
    </Modal>
  );
}

function AppointmentDetail({
  appointment,
  onClose,
}: {
  appointment: Appointment;
  onClose: () => void;
}) {
  return (
    <Modal title="Chi tiết lịch hẹn" onClose={onClose} wide>
      <div className="appointment-code">
        <span>
          <Icon name="calendar" />
        </span>
        <div>
          <small>Mã lịch hẹn</small>
          <h3>{appointment.id}</h3>
        </div>
        <StatusBadge status={appointment.status} />
      </div>
      <div className="detail-grid">
        {[
          ["Bệnh nhân", appointment.patient],
          ["Bác sĩ", `BS. ${appointment.doctor}`],
          ["Chuyên khoa", appointment.specialty],
          ["Ngày khám", appointment.date],
          ["Giờ khám", appointment.time],
          ["Hình thức", appointment.visitType || "Khám trực tiếp"],
          ["Loại lịch", appointment.isFollowUp ? "Tái khám" : "Khám thông thường"],
          [
            "Phí khám",
            appointment.fee ? `${appointment.fee.toLocaleString("vi-VN")} ₫` : "Chưa cập nhật",
          ],
          ["Lý do khám", appointment.reason],
        ].map((x) => (
          <div key={x[0]}>
            <small>{x[0]}</small>
            <b>{x[1]}</b>
          </div>
        ))}
      </div>
      <div className="privacy-note">
        <Icon name="heart" />
        <div>
          <b>Quyền quản trị</b>
          <p>
            Quản trị viên chỉ theo dõi lịch hẹn và không thể thay đổi chẩn đoán hoặc quyết định y
            khoa.
          </p>
        </div>
      </div>
      <div className="modal-actions">
        <Button variant="secondary" onClick={onClose}>
          Đóng
        </Button>
      </div>
    </Modal>
  );
}

function SchedulePage({ appointments }: { appointments: Appointment[] }) {
  const [view, setView] = useState("Tuần"),
    [offset, setOffset] = useState(0),
    [selected, setSelected] = useState<Appointment>(),
    days = [
      "Thứ Hai, 16/06",
      "Thứ Ba, 17/06",
      "Thứ Tư, 18/06",
      "Thứ Năm, 19/06",
      "Thứ Sáu, 20/06",
      "Thứ Bảy, 21/06",
      "Chủ Nhật, 22/06",
    ];
  return (
    <div className="page-stack">
      <DataPageHeader
        eyebrow="Lịch toàn phòng khám"
        title="Quản lý lịch làm việc"
        description="Theo dõi lịch khám, tình trạng đặt hẹn và thời gian khả dụng."
      />
      <div className="card calendar-card">
        <div className="calendar-toolbar">
          <div className="cal-nav">
            <button onClick={() => setOffset(offset - 1)}>‹</button>
            <button onClick={() => setOffset(offset + 1)}>›</button>
            <Button variant="secondary" onClick={() => setOffset(0)}>
              Hôm nay
            </Button>
            <h3>
              16 – 22 tháng 06, 2025 {offset !== 0 && `(${offset > 0 ? "+" : ""}${offset} tuần)`}
            </h3>
          </div>
          <div className="segmented">
            {["Ngày", "Tuần", "Tháng"].map((v) => (
              <button className={view === v ? "active" : ""} onClick={() => setView(v)} key={v}>
                {v}
              </button>
            ))}
          </div>
        </div>
        <div className="toolbar sub">
          <div className="filters">
            <Select>
              <option>Tất cả bác sĩ</option>
              {initialDoctors.map((d) => (
                <option key={d.id}>{d.name}</option>
              ))}
            </Select>
            <Select>
              <option>Tất cả chuyên khoa</option>
              {initialSpecialties.map((s) => (
                <option key={s.id}>{s.name}</option>
              ))}
            </Select>
          </div>
          <div className="schedule-legend">
            <span>
              <i className="confirmed" />
              Đã xác nhận
            </span>
            <span>
              <i className="pending" />
              Chờ xác nhận
            </span>
            <span>
              <i className="done" />
              Hoàn thành
            </span>
          </div>
        </div>
        {view === "Tuần" ? (
          <div className="week-grid">
            <div className="time-col">
              <span />
              {["08:00", "09:00", "10:00", "11:00", "13:00", "14:00", "15:00", "16:00"].map((t) => (
                <small key={t}>{t}</small>
              ))}
            </div>
            {days.map((d, i) => (
              <div className={`day-col ${i === 4 ? "today" : ""}`} key={d}>
                <div>
                  <b>{d.split(", ")[0]}</b>
                  <span>{d.split(", ")[1]}</span>
                </div>
                {appointments
                  .filter((_, j) => j % 7 === i || (i === 4 && j < 3))
                  .map((a, j) => (
                    <button
                      key={a.id}
                      className={`cal-event ${a.status === "Chờ xác nhận" ? "pending" : a.status === "Hoàn thành" ? "done" : ""}`}
                      style={{ top: `${66 + j * 88}px` }}
                      onClick={() => setSelected(a)}
                    >
                      <b>
                        {a.time} · {a.patient}
                      </b>
                      <span>BS. {a.doctor}</span>
                    </button>
                  ))}
              </div>
            ))}
          </div>
        ) : (
          <div className="calendar-placeholder">
            <Icon name="calendar" size={32} />
            <h3>Chế độ xem {view.toLowerCase()}</h3>
            <p>
              Dữ liệu mẫu được tổng hợp theo {view.toLowerCase()}. Chọn chế độ Tuần để xem chi tiết
              từng lịch hẹn.
            </p>
          </div>
        )}
      </div>
      {selected && (
        <AppointmentDetail appointment={selected} onClose={() => setSelected(undefined)} />
      )}
    </div>
  );
}

function ReportsPage({ notify }: { notify: (s: string) => void }) {
  const [range, setRange] = useState("30"),
    factor = range === "7" ? 0.28 : range === "90" ? 2.4 : 1;
  const exportCsv = () => {
    const csv =
      "Hạng mục,Số lượng\nTổng người dùng," +
      Math.round(2486 * factor) +
      "\nBác sĩ," +
      Math.round(126 * factor) +
      "\nBệnh nhân," +
      Math.round(2352 * factor) +
      "\nLịch hẹn," +
      Math.round(892 * factor);
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
    a.download = "titimi-bao-cao-mau.csv";
    a.click();
    notify("Đã tải báo cáo CSV mẫu");
  };
  return (
    <div className="page-stack">
      <DataPageHeader
        eyebrow="Phân tích dữ liệu mẫu"
        title="Báo cáo hệ thống"
        description="Theo dõi xu hướng người dùng, lịch hẹn và hiệu suất hoạt động."
      />
      <div className="report-filter card">
        <div>
          <label>
            Khoảng thời gian
            <Select value={range} onChange={(e) => setRange(e.target.value)}>
              <option value="7">7 ngày gần nhất</option>
              <option value="30">30 ngày gần nhất</option>
              <option value="90">90 ngày gần nhất</option>
            </Select>
          </label>
        </div>
        <Button onClick={exportCsv}>
          <Icon name="download" size={18} />
          Xuất báo cáo CSV
        </Button>
      </div>
      <div className="section-label">
        <h3>Báo cáo người dùng</h3>
        <span>Dữ liệu đã cập nhật theo bộ lọc</span>
      </div>
      <div className="stat-grid three">
        <StatCard
          label="Tổng người dùng"
          value={Math.round(2486 * factor).toLocaleString("vi-VN")}
          detail="+8,2% so với kỳ trước"
          icon="users"
        />
        <StatCard
          label="Bác sĩ"
          value={Math.round(126 * factor)}
          detail="5,1% người dùng"
          icon="doctor"
          tone="blue"
        />
        <StatCard
          label="Bệnh nhân"
          value={Math.round(2352 * factor).toLocaleString("vi-VN")}
          detail="94,6% người dùng"
          icon="heart"
          tone="violet"
        />
      </div>
      <div className="dashboard-grid">
        <div className="card chart-large">
          <div className="card-head">
            <div>
              <h3>Đăng ký người dùng mới</h3>
              <p>Xu hướng trong kỳ đã chọn</p>
            </div>
          </div>
          <MiniLineChart variant={range === "7" ? 1 : 0} />
          <div className="axis">
            <span>Tuần 1</span>
            <span>Tuần 2</span>
            <span>Tuần 3</span>
            <span>Tuần 4</span>
          </div>
        </div>
        <div className="card">
          <div className="card-head">
            <div>
              <h3>Phân bổ người dùng</h3>
              <p>Theo vai trò</p>
            </div>
          </div>
          <Donut
            center={Math.round(2486 * factor).toString()}
            parts={[
              { label: "Bệnh nhân", value: 78, color: "#286A9B" },
              { label: "Bác sĩ", value: 17, color: "#438FC2" },
              { label: "Admin", value: 5, color: "#E98DAE" },
            ]}
          />
        </div>
      </div>
      <div className="section-label">
        <h3>Báo cáo lịch hẹn & bác sĩ</h3>
      </div>
      <div className="dashboard-grid three">
        <div className="card">
          <div className="card-head">
            <div>
              <h3>Xu hướng lịch hẹn</h3>
              <p>{Math.round(892 * factor)} lịch hẹn trong kỳ</p>
            </div>
          </div>
          <MiniLineChart variant={1} />
        </div>
        <div className="card">
          <div className="card-head">
            <div>
              <h3>Trạng thái lịch hẹn</h3>
            </div>
          </div>
          <Donut
            center={Math.round(892 * factor).toString()}
            parts={[
              { label: "Hoàn thành", value: 64, color: "#286A9B" },
              { label: "Chờ xử lý", value: 23, color: "#E9A23B" },
              { label: "Đã hủy", value: 13, color: "#DF6B68" },
            ]}
          />
        </div>
        <div className="card">
          <div className="card-head">
            <div>
              <h3>Lịch hẹn theo bác sĩ</h3>
              <p>Top 5 trong kỳ</p>
            </div>
          </div>
          <BarChart compact />
        </div>
      </div>
    </div>
  );
}

function SettingsPage({ notify }: { notify: (s: string) => void }) {
  const [name, setName] = useState("Nguyễn Minh Anh"),
    [email, setEmail] = useState("minhanh@titimi.vn"),
    [phone, setPhone] = useState("090 234 5678"),
    [theme, setTheme] = useState("Sáng");
  return (
    <div className="page-stack">
      <DataPageHeader
        eyebrow="Tùy chỉnh quản trị"
        title="Cài đặt"
        description="Quản lý hồ sơ, thông báo và tùy chọn hiển thị của bạn."
      />
      <div className="settings-layout">
        <div className="settings-nav card">
          <button className="active">
            <Icon name="users" />
            Hồ sơ quản trị
          </button>
          <button>
            <Icon name="settings" />
            Tài khoản
          </button>
          <button>
            <Icon name="bell" />
            Thông báo
          </button>
          <button>
            <Icon name="grid" />
            Giao diện
          </button>
        </div>
        <div className="settings-content">
          <div className="card settings-section">
            <div className="card-head">
              <div>
                <h3>Hồ sơ quản trị</h3>
                <p>Thông tin hiển thị trong hệ thống TiTiMi</p>
              </div>
            </div>
            <div className="avatar-edit">
              <Avatar name={name} size="lg" />
              <div>
                <Button
                  variant="secondary"
                  onClick={() => notify("Tính năng tải ảnh đang ở chế độ mẫu")}
                >
                  Thay ảnh đại diện
                </Button>
                <small>JPG hoặc PNG, tối đa 2MB</small>
              </div>
            </div>
            <div className="form-grid">
              <label className="span-2">
                Họ và tên
                <Input value={name} onChange={(e) => setName(e.target.value)} />
              </label>
              <label>
                Email
                <Input value={email} onChange={(e) => setEmail(e.target.value)} />
              </label>
              <label>
                Số điện thoại
                <Input value={phone} onChange={(e) => setPhone(e.target.value)} />
              </label>
              <label>
                Vai trò
                <Input value="System Administrator" disabled />
              </label>
            </div>
            <div className="settings-save">
              <Button onClick={() => notify("Đã lưu thông tin hồ sơ")}>Lưu thay đổi</Button>
            </div>
          </div>
          <div className="card settings-section">
            <div className="card-head">
              <div>
                <h3>Tài khoản & thông báo</h3>
                <p>Các cài đặt chỉ áp dụng cho tài khoản này</p>
              </div>
            </div>
            <div className="setting-row">
              <div>
                <b>Thông báo lịch hẹn</b>
                <p>Nhận thông báo về lịch hẹn mới và thay đổi trạng thái</p>
              </div>
              <label className="switch">
                <input type="checkbox" defaultChecked />
                <span />
              </label>
            </div>
            <div className="setting-row">
              <div>
                <b>Báo cáo tuần</b>
                <p>Nhận bản tóm tắt hoạt động vào mỗi thứ Hai</p>
              </div>
              <label className="switch">
                <input type="checkbox" defaultChecked />
                <span />
              </label>
            </div>
            <div className="setting-row">
              <div>
                <b>Đổi mật khẩu</b>
                <p>Cập nhật mật khẩu quản trị (giao diện mẫu)</p>
              </div>
              <Button variant="secondary" onClick={() => notify("Đã gửi yêu cầu đổi mật khẩu mẫu")}>
                Đổi mật khẩu
              </Button>
            </div>
          </div>
          <div className="card settings-section">
            <div className="card-head">
              <div>
                <h3>Giao diện & hệ thống</h3>
                <p>Tùy chọn hiển thị và thông tin phiên bản</p>
              </div>
            </div>
            <div className="setting-row">
              <div>
                <b>Chế độ hiển thị</b>
                <p>Sử dụng bảng màu TiTiMi hiện tại</p>
              </div>
              <Select
                value={theme}
                onChange={(e) => {
                  setTheme(e.target.value);
                  notify(`Đã chọn chế độ ${e.target.value.toLowerCase()}`);
                }}
              >
                <option>Sáng</option>
                <option>Tự động</option>
              </Select>
            </div>
            <div className="system-info">
              <div>
                <small>Ứng dụng</small>
                <b>TiTiMi Admin Portal</b>
              </div>
              <div>
                <small>Phiên bản</small>
                <b>v1.8.4 (Bản mẫu)</b>
              </div>
              <div>
                <small>Mô tả</small>
                <b>Hệ thống quản trị phòng khám TiTiMi</b>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Sidebar({
  page,
  setPage,
  open,
  setOpen,
}: {
  page: Page;
  setPage: (p: Page) => void;
  open: boolean;
  setOpen: (v: boolean) => void;
}) {
  return (
    <>
      <aside className={`sidebar ${open ? "open" : ""}`}>
        <div className="brand">
          <div className="brand-mark">
            <img src={titimiHatLogo} alt="TiTiMi" />
          </div>
          <div>
            <b>TiTiMi</b>
            <small>ADMIN PORTAL</small>
          </div>
          <button className="mobile-close" onClick={() => setOpen(false)}>
            <Icon name="close" />
          </button>
        </div>
        <nav>
          {NAV.map((n) => (
            <button
              key={n.page}
              className={page === n.page ? "active" : ""}
              onClick={() => {
                setPage(n.page);
                setOpen(false);
              }}
            >
              <Icon name={n.icon} />
              <span>{n.label}</span>
              {page === n.page && <i />}
            </button>
          ))}
        </nav>
        <div className="sidebar-profile">
          <Avatar name="Nguyễn Minh Anh" />
          <div>
            <b>Nguyễn Minh Anh</b>
            <small>System Administrator</small>
          </div>
          <button onClick={() => setPage("settings")}>
            <Icon name="settings" size={17} />
          </button>
        </div>
        <button className="logout" onClick={() => alert("Đã đăng xuất khỏi phiên mẫu.")}>
          <Icon name="logout" size={18} />
          Đăng xuất
        </button>
      </aside>
      {open && <div className="sidebar-overlay" onClick={() => setOpen(false)} />}
    </>
  );
}
function Header({
  page,
  onMenu,
  globalSearch,
  setGlobalSearch,
  notify,
}: {
  page: Page;
  onMenu: () => void;
  globalSearch: string;
  setGlobalSearch: (v: string) => void;
  notify: (s: string) => void;
}) {
  const [notifications, setNotifications] = useState(false),
    [profile, setProfile] = useState(false),
    title = NAV.find((n) => n.page === page)?.label;
  return (
    <header>
      <div className="header-title">
        <button className="menu-btn" onClick={onMenu}>
          <Icon name="menu" />
        </button>
        <div>
          <small>TiTiMi / {title}</small>
          <h1>{title}</h1>
        </div>
      </div>
      <div className="header-actions">
        <div className="global-search">
          <SearchBar
            value={globalSearch}
            onChange={setGlobalSearch}
            placeholder="Tìm kiếm toàn hệ thống..."
          />
        </div>
        <span className="date">
          <Icon name="calendar" size={16} />
          20/06/2025
        </span>
        <div className="popover-wrap">
          <button
            className="header-icon"
            onClick={() => {
              setNotifications(!notifications);
              setProfile(false);
            }}
          >
            <Icon name="bell" />
            <i />
          </button>
          {notifications && (
            <div className="popover notifications">
              <div>
                <b>Thông báo</b>
                <button onClick={() => notify("Đã đánh dấu tất cả là đã đọc")}>
                  Đánh dấu đã đọc
                </button>
              </div>
              {[
                ["Lịch hẹn mới", "Đỗ Thanh Tâm vừa đặt lịch · 5 phút"],
                ["Bác sĩ mới", "Hồ sơ BS. Lê Đức Phúc đã được tạo"],
                ["Báo cáo tuần", "Báo cáo tuần đã sẵn sàng"],
              ].map((x) => (
                <button key={x[0]}>
                  <span />
                  <div>
                    <b>{x[0]}</b>
                    <small>{x[1]}</small>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
        <div className="popover-wrap">
          <button
            className="profile-trigger"
            onClick={() => {
              setProfile(!profile);
              setNotifications(false);
            }}
          >
            <Avatar name="Nguyễn Minh Anh" size="sm" />
            <div>
              <b>Minh Anh</b>
              <small>Quản trị viên</small>
            </div>
            <span>⌄</span>
          </button>
          {profile && (
            <div className="popover profile-menu">
              <button onClick={() => notify("Đã mở hồ sơ quản trị")}>
                <Icon name="users" />
                Hồ sơ cá nhân
              </button>
              <button onClick={() => notify("Đã mở cài đặt tài khoản")}>
                <Icon name="settings" />
                Cài đặt tài khoản
              </button>
              <button onClick={() => alert("Đã đăng xuất khỏi phiên mẫu.")}>
                <Icon name="logout" />
                Đăng xuất
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}

export default function App() {
  const [page, setPage] = useState<Page>("dashboard"),
    [sidebar, setSidebar] = useState(false),
    [globalSearch, setGlobalSearch] = useState(""),
    [toast, setToast] = useState(""),
    [users, setUsers] = useState(initialUsers),
    [doctors, setDoctors] = useState(initialDoctors),
    [patients, setPatients] = useState(initialPatients),
    [specialties, setSpecialties] = useState(initialSpecialties),
    [appointments, setAppointments] = useState(initialAppointments);
  const notify = (s: string) => {
    setToast(s);
    window.setTimeout(() => setToast(""), 2600);
  };
  const content = useMemo(() => {
    switch (page) {
      case "dashboard":
        return <Dashboard setPage={setPage} appointments={appointments} />;
      case "users":
        return <UsersPage users={users} setUsers={setUsers} notify={notify} />;
      case "doctors":
        return <DoctorsPage doctors={doctors} setDoctors={setDoctors} notify={notify} />;
      case "patients":
        return <PatientsPage patients={patients} setPatients={setPatients} notify={notify} />;
      case "specialties":
        return <SpecialtiesPage items={specialties} setItems={setSpecialties} notify={notify} />;
      case "appointments":
        return (
          <AppointmentsPage
            appointments={appointments}
            patients={patients}
            doctors={doctors}
            specialties={specialties}
            onCreate={(appointment) => setAppointments((current) => [appointment, ...current])}
            notify={notify}
          />
        );
      case "schedule":
        return <SchedulePage appointments={appointments} />;
      case "reports":
        return <ReportsPage notify={notify} />;
      case "settings":
        return <SettingsPage notify={notify} />;
    }
  }, [page, users, doctors, patients, specialties, appointments]);
  return (
    <div className="app-shell">
      <Sidebar page={page} setPage={setPage} open={sidebar} setOpen={setSidebar} />
      <main>
        <Header
          page={page}
          onMenu={() => setSidebar(true)}
          globalSearch={globalSearch}
          setGlobalSearch={(v) => {
            setGlobalSearch(v);
            if (v.length > 2) notify(`Đang tìm kiếm “${v}” trên hệ thống`);
          }}
          notify={notify}
        />
        <div className="content">{content}</div>
      </main>
      {toast && (
        <div className="toast">
          <span>
            <Icon name="check" size={17} />
          </span>
          {toast}
        </div>
      )}
    </div>
  );
}
