import { FormEvent, ReactNode, useMemo, useState } from "react";
import titimiLogo from "./assets/titimi-logo.png";

type Page =
  | "dashboard"
  | "doctors"
  | "doctor-detail"
  | "booking"
  | "appointments"
  | "appointment-detail"
  | "consultations"
  | "consultation-detail"
  | "history"
  | "history-detail"
  | "prescriptions"
  | "prescription-detail"
  | "profile";

type IconName =
  | "grid"
  | "search"
  | "calendar"
  | "chat"
  | "history"
  | "pill"
  | "user"
  | "bell"
  | "chevron"
  | "arrow"
  | "clock"
  | "video"
  | "building"
  | "stethoscope"
  | "file"
  | "plus"
  | "check"
  | "close"
  | "menu"
  | "logout"
  | "edit"
  | "phone"
  | "mail"
  | "map"
  | "activity";

const paths: Record<IconName, ReactNode> = {
  grid: (
    <>
      <rect x="3" y="3" width="7" height="7" rx="2" />
      <rect x="14" y="3" width="7" height="7" rx="2" />
      <rect x="3" y="14" width="7" height="7" rx="2" />
      <rect x="14" y="14" width="7" height="7" rx="2" />
    </>
  ),
  search: (
    <>
      <circle cx="11" cy="11" r="7" />
      <path d="m20 20-4-4" />
    </>
  ),
  calendar: (
    <>
      <rect x="3" y="5" width="18" height="16" rx="2" />
      <path d="M16 3v4M8 3v4M3 10h18" />
    </>
  ),
  chat: (
    <>
      <path d="M21 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4z" />
      <path d="M8 9h8M8 13h5" />
    </>
  ),
  history: (
    <>
      <path d="M3 12a9 9 0 1 0 3-6.7L3 8" />
      <path d="M3 3v5h5M12 7v5l3 2" />
    </>
  ),
  pill: (
    <>
      <path d="m10.5 4.5 9 9a4.2 4.2 0 0 1-6 6l-9-9a4.2 4.2 0 0 1 6-6Z" />
      <path d="m8 14 6-6" />
    </>
  ),
  user: (
    <>
      <circle cx="12" cy="8" r="4" />
      <path d="M4 21a8 8 0 0 1 16 0" />
    </>
  ),
  bell: (
    <>
      <path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9" />
      <path d="M10 21h4" />
    </>
  ),
  chevron: <path d="m9 18 6-6-6-6" />,
  arrow: (
    <>
      <path d="M19 12H5M12 19l-7-7 7-7" />
    </>
  ),
  clock: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="M12 7v5l3 2" />
    </>
  ),
  video: (
    <>
      <rect x="3" y="5" width="14" height="14" rx="2" />
      <path d="m17 10 4-3v10l-4-3" />
    </>
  ),
  building: (
    <>
      <path d="M3 21h18M6 21V5l6-3 6 3v16" />
      <path d="M9 9h6M9 13h6M10 21v-4h4v4" />
    </>
  ),
  stethoscope: (
    <>
      <path d="M6 3v7a6 6 0 0 0 12 0V3M4 3h4M16 3h4" />
      <circle cx="18" cy="15" r="3" />
    </>
  ),
  file: (
    <>
      <path d="M6 2h8l4 4v16H6z" />
      <path d="M14 2v5h5M9 12h6M9 16h6" />
    </>
  ),
  plus: <path d="M12 5v14M5 12h14" />,
  check: <path d="m5 12 4 4L19 6" />,
  close: <path d="M18 6 6 18M6 6l12 12" />,
  menu: <path d="M4 7h16M4 12h16M4 17h16" />,
  logout: (
    <>
      <path d="M10 17l5-5-5-5M15 12H3" />
      <path d="M14 3h7v18h-7" />
    </>
  ),
  edit: (
    <>
      <path d="m4 16-1 5 5-1L19 9l-4-4Z" />
      <path d="m13 7 4 4" />
    </>
  ),
  phone: (
    <path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 2 .7 2.8a2 2 0 0 1-.5 2.1L8 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.5c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.8 2.1z" />
  ),
  mail: (
    <>
      <rect x="3" y="5" width="18" height="14" rx="2" />
      <path d="m3 7 9 6 9-6" />
    </>
  ),
  map: (
    <>
      <path d="M20 10c0 5-8 12-8 12S4 15 4 10a8 8 0 1 1 16 0Z" />
      <circle cx="12" cy="10" r="2.5" />
    </>
  ),
  activity: <path d="M3 12h4l2-6 4 12 2-6h6" />,
};

function Icon({ name, size = 20 }: { name: IconName; size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {paths[name]}
    </svg>
  );
}

const doctors = [
  {
    name: "Dr. Maya Okafor",
    specialty: "Tim mạch",
    experience: "12 năm kinh nghiệm",
    next: "Hôm nay, 2:30 PM",
    available: true,
    rating: "4.9",
  },
  {
    name: "Dr. Daniel Chen",
    specialty: "Nội tổng quát",
    experience: "9 năm kinh nghiệm",
    next: "Ngày mai, 9:00 AM",
    available: true,
    rating: "4.8",
  },
  {
    name: "Dr. Noah Williams",
    specialty: "Da liễu",
    experience: "15 năm kinh nghiệm",
    next: "May 24, 11:30 AM",
    available: false,
    rating: "4.9",
  },
];

const appointments = [
  {
    doctor: "Dr. Maya Okafor",
    specialty: "Tim mạch",
    date: "May 22, 2025",
    time: "10:30 AM",
    type: "Khám trực tiếp",
    status: "Đã xác nhận",
  },
  {
    doctor: "Dr. Daniel Chen",
    specialty: "Nội tổng quát",
    date: "May 12, 2025",
    time: "2:00 PM",
    type: "Trực tuyến",
    status: "Đã hoàn thành",
  },
  {
    doctor: "Dr. Noah Williams",
    specialty: "Da liễu",
    date: "Apr 28, 2025",
    time: "9:15 AM",
    type: "Khám trực tiếp",
    status: "Đã hoàn thành",
  },
  {
    doctor: "Dr. Maya Okafor",
    specialty: "Tim mạch",
    date: "Mar 14, 2025",
    time: "11:00 AM",
    type: "Trực tuyến",
    status: "Đã hủy",
  },
];

const navItems: { id: Page; label: string; icon: IconName }[] = [
  { id: "dashboard", label: "Tổng quan", icon: "grid" },
  { id: "doctors", label: "Tìm bác sĩ", icon: "search" },
  { id: "appointments", label: "Lịch hẹn của tôi", icon: "calendar" },
  { id: "consultations", label: "Phiên khám", icon: "chat" },
  { id: "history", label: "Bệnh sử", icon: "history" },
  { id: "prescriptions", label: "Đơn thuốc", icon: "pill" },
  { id: "profile", label: "Hồ sơ cá nhân", icon: "user" },
];

const pageTitles: Partial<Record<Page, string>> = {
  dashboard: "Tổng quan",
  doctors: "Tìm bác sĩ",
  "doctor-detail": "Hồ sơ bác sĩ",
  booking: "Đặt lịch khám",
  appointments: "Lịch hẹn của tôi",
  "appointment-detail": "Chi tiết lịch hẹn",
  consultations: "Phiên khám",
  "consultation-detail": "Chi tiết phiên khám",
  history: "Bệnh sử",
  "history-detail": "Hồ sơ bệnh án",
  prescriptions: "Đơn thuốc",
  "prescription-detail": "Chi tiết đơn thuốc",
  profile: "Hồ sơ cá nhân",
};

function Button({
  children,
  onClick,
  variant = "primary",
  icon,
  type = "button",
  disabled = false,
  className = "",
}: {
  children: ReactNode;
  onClick?: () => void;
  variant?: "primary" | "secondary" | "ghost" | "danger";
  icon?: IconName;
  type?: "button" | "submit";
  disabled?: boolean;
  className?: string;
}) {
  return (
    <button
      type={type}
      disabled={disabled}
      onClick={onClick}
      className={`btn btn-${variant} ${className}`}
    >
      {icon && <Icon name={icon} size={18} />}
      <span>{children}</span>
    </button>
  );
}

function Badge({
  children,
  tone = "green",
}: {
  children: ReactNode;
  tone?: "green" | "gray" | "blue" | "red" | "amber";
}) {
  return (
    <span className={`badge badge-${tone}`}>
      <span className="badge-dot" />
      {children}
    </span>
  );
}

function PageHeader({
  title,
  description,
  action,
}: {
  title: string;
  description: string;
  action?: ReactNode;
}) {
  return (
    <div className="page-header">
      <div>
        <h1>{title}</h1>
        <p>{description}</p>
      </div>
      {action}
    </div>
  );
}

function BackButton({ onClick, label = "Quay lại" }: { onClick: () => void; label?: string }) {
  return (
    <button className="back-button" onClick={onClick}>
      <Icon name="arrow" size={18} />
      {label}
    </button>
  );
}

function DoctorAvatar({ size = "medium" }: { size?: "small" | "medium" | "large" }) {
  return (
    <span className={`doctor-avatar doctor-avatar-${size}`} aria-hidden="true">
      <Icon name="stethoscope" size={size === "large" ? 32 : size === "small" ? 17 : 22} />
    </span>
  );
}

function EmptyState({ onClear }: { onClear: () => void }) {
  return (
    <div className="empty-state">
      <div className="empty-icon">
        <Icon name="search" size={26} />
      </div>
      <h3>Không tìm thấy bác sĩ</h3>
      <p>Không tìm thấy bác sĩ phù hợp với bộ lọc. Hãy thử chuyên khoa hoặc từ khóa khác.</p>
      <Button variant="secondary" onClick={onClear}>
        Xóa tất cả bộ lọc
      </Button>
    </div>
  );
}

function Dashboard({ go }: { go: (p: Page) => void }) {
  const quickActions: { title: string; text: string; icon: IconName; page: Page }[] = [
    { title: "Tìm bác sĩ", text: "Tìm theo chuyên khoa", icon: "stethoscope", page: "doctors" },
    { title: "Đặt lịch khám", text: "Chọn thời gian khám", icon: "calendar", page: "booking" },
    { title: "Bệnh sử", text: "Xem hồ sơ bệnh án", icon: "file", page: "history" },
    { title: "Đơn thuốc", text: "Xem danh sách thuốc", icon: "pill", page: "prescriptions" },
  ];
  return (
    <>
      <div className="welcome-banner">
        <div>
          <span className="eyebrow">Thursday, May 22</span>
          <h1>Xin chào, Amara!</h1>
          <p>Dưới đây là tổng quan hoạt động sức khỏe và kế hoạch chăm sóc sắp tới của bạn.</p>
        </div>
        <Button icon="plus" onClick={() => go("booking")}>
          Đặt lịch khám
        </Button>
      </div>
      <div className="demo-note">
        <Icon name="file" size={16} />
        <span>Bạn đang xem dữ liệu sức khỏe minh họa trên cổng thông tin bệnh nhân TiTiMi.</span>
      </div>
      <div className="stats-grid">
        {[
          ["calendar", "Tổng số lịch hẹn", "12", "2 lịch sắp tới"],
          ["file", "Hồ sơ bệnh án", "8", "Cập nhật May 12"],
          ["pill", "Đơn thuốc", "3", "1 đơn đang dùng"],
        ].map(([icon, label, value, meta]) => (
          <div className="stat-card" key={label}>
            <div className="stat-icon">
              <Icon name={icon as IconName} />
            </div>
            <div>
              <span>{label}</span>
              <strong>{value}</strong>
              <small>{meta}</small>
            </div>
          </div>
        ))}
      </div>
      <section className="section-block">
        <div className="section-title">
          <div>
            <h2>Thao tác nhanh</h2>
            <p>Truy cập nhanh các chức năng bạn cần.</p>
          </div>
        </div>
        <div className="quick-grid">
          {quickActions.map((a) => (
            <button key={a.title} className="quick-card" onClick={() => go(a.page)}>
              <span className="quick-icon">
                <Icon name={a.icon} />
              </span>
              <span>
                <strong>{a.title}</strong>
                <small>{a.text}</small>
              </span>
              <Icon name="chevron" size={18} />
            </button>
          ))}
        </div>
      </section>
      <div className="dashboard-grid">
        <section className="card upcoming-card">
          <div className="section-title">
            <div>
              <h2>Lịch hẹn sắp tới</h2>
              <p>Lịch khám tiếp theo của bạn</p>
            </div>
            <button className="text-button" onClick={() => go("appointments")}>
              Xem tất cả
            </button>
          </div>
          <div className="appointment-feature">
            <div className="doctor-line">
              <DoctorAvatar />
              <div>
                <h3>Dr. Maya Okafor</h3>
                <p>Tim mạch</p>
              </div>
              <Badge>Đã xác nhận</Badge>
            </div>
            <div className="appointment-meta">
              <span>
                <Icon name="calendar" size={18} />
                May 22, 2025
              </span>
              <span>
                <Icon name="clock" size={18} />
                10:30 AM
              </span>
              <span>
                <Icon name="building" size={18} />
                Khám trực tiếp
              </span>
            </div>
            <Button variant="secondary" onClick={() => go("appointment-detail")}>
              Xem chi tiết
            </Button>
          </div>
        </section>
        <section className="card health-card">
          <div className="section-title">
            <div>
              <h2>Nhắc nhở chăm sóc</h2>
              <p>Chủ động theo dõi sức khỏe</p>
            </div>
          </div>
          <div className="reminder-visual">
            <div className="pulse-ring">
              <Icon name="stethoscope" size={28} />
            </div>
            <div>
              <h3>Kiểm tra sức khỏe định kỳ</h3>
              <p>Bạn cần thực hiện kiểm tra sức khỏe định kỳ vào tháng tới.</p>
            </div>
          </div>
          <Button variant="ghost" onClick={() => go("doctors")}>
            Tìm bác sĩ chăm sóc ban đầu <Icon name="chevron" size={16} />
          </Button>
        </section>
      </div>
      <section className="card table-card">
        <div className="section-title">
          <div>
            <h2>Lịch hẹn gần đây</h2>
            <p>Các lịch hẹn và phiên khám gần đây của bạn</p>
          </div>
          <button className="text-button" onClick={() => go("appointments")}>
            Xem tất cả
          </button>
        </div>
        <AppointmentTable rows={appointments.slice(1)} onView={() => go("appointment-detail")} />
      </section>
    </>
  );
}

function AppointmentTable({ rows, onView }: { rows: typeof appointments; onView: () => void }) {
  return (
    <div className="table-wrap">
      <table>
        <thead>
          <tr>
            <th>Bác sĩ</th>
            <th>Ngày và giờ</th>
            <th>Hình thức</th>
            <th>Trạng thái</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {rows.map((a) => (
            <tr key={a.date + a.doctor}>
              <td>
                <strong>{a.doctor}</strong>
                <small>{a.specialty}</small>
              </td>
              <td>
                <strong>{a.date}</strong>
                <small>{a.time}</small>
              </td>
              <td>{a.type}</td>
              <td>
                <Badge
                  tone={
                    a.status === "Đã hoàn thành" ? "blue" : a.status === "Đã hủy" ? "red" : "green"
                  }
                >
                  {a.status}
                </Badge>
              </td>
              <td>
                <button className="table-action" onClick={onView}>
                  Xem chi tiết
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function FindDoctors({ go }: { go: (p: Page) => void }) {
  const [query, setQuery] = useState("");
  const [specialty, setSpecialty] = useState("Tất cả chuyên khoa");
  const [availability, setAvailability] = useState("Mọi lịch trống");
  const filtered = useMemo(
    () =>
      doctors.filter(
        (d) =>
          (d.name.toLowerCase().includes(query.toLowerCase()) ||
            d.specialty.toLowerCase().includes(query.toLowerCase())) &&
          (specialty === "Tất cả chuyên khoa" || d.specialty === specialty) &&
          (availability === "Mọi lịch trống" ||
            (availability === "Có lịch hôm nay" ? d.next.includes("Hôm nay") : d.available)),
      ),
    [query, specialty, availability],
  );
  const clear = () => {
    setQuery("");
    setSpecialty("Tất cả chuyên khoa");
    setAvailability("Mọi lịch trống");
  };
  return (
    <>
      <PageHeader
        title="Tìm bác sĩ"
        description="Tìm bác sĩ chuyên khoa phù hợp và đặt lịch khám thuận tiện."
        action={
          <Button icon="calendar" variant="secondary" onClick={() => go("appointments")}>
            Lịch hẹn của tôi
          </Button>
        }
      />
      <div className="card filter-bar">
        <label className="search-field">
          <span>Tìm kiếm bác sĩ</span>
          <div>
            <Icon name="search" size={19} />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Tên bác sĩ hoặc chuyên khoa"
            />
          </div>
        </label>
        <label>
          <span>Chuyên khoa</span>
          <select value={specialty} onChange={(e) => setSpecialty(e.target.value)}>
            <option>Tất cả chuyên khoa</option>
            <option>Tim mạch</option>
            <option>Nội tổng quát</option>
            <option>Da liễu</option>
          </select>
        </label>
        <label>
          <span>Lịch trống</span>
          <select value={availability} onChange={(e) => setAvailability(e.target.value)}>
            <option>Mọi lịch trống</option>
            <option>Có lịch hôm nay</option>
            <option>Lịch gần nhất</option>
          </select>
        </label>
        <Button icon="search">Tìm kiếm</Button>
      </div>
      <div className="results-head">
        <div>
          <h2>{filtered.length} bác sĩ có lịch trống</h2>
          <p>Đang hiển thị hồ sơ bác sĩ minh họa</p>
        </div>
        <select aria-label="Sắp xếp bác sĩ">
          <option>Đề xuất</option>
          <option>Lịch gần nhất</option>
          <option>Kinh nghiệm</option>
        </select>
      </div>
      {filtered.length ? (
        <div className="doctor-grid">
          {filtered.map((d) => (
            <article className="doctor-card card" key={d.name}>
              <div className="doctor-avatar-panel">
                <DoctorAvatar size="large" />
                <span className={d.available ? "online-dot" : "online-dot offline"} />
              </div>
              <div className="doctor-card-body">
                <div className="doctor-top">
                  <span className="specialty-tag">{d.specialty}</span>
                  <span className="rating">★ {d.rating}</span>
                </div>
                <h3>{d.name}</h3>
                <p>{d.experience}</p>
                <div className="next-slot">
                  <Icon name="calendar" size={18} />
                  <span>
                    <small>Lịch gần nhất</small>
                    <strong>{d.next}</strong>
                  </span>
                </div>
                <div className="doctor-actions">
                  <Button variant="secondary" onClick={() => go("doctor-detail")}>
                    Xem hồ sơ
                  </Button>
                  <Button onClick={() => go("booking")}>Đặt lịch</Button>
                </div>
              </div>
            </article>
          ))}
        </div>
      ) : (
        <EmptyState onClear={clear} />
      )}
    </>
  );
}

function DoctorDetail({ go }: { go: (p: Page) => void }) {
  return (
    <>
      <BackButton onClick={() => go("doctors")} label="Quay lại danh sách bác sĩ" />
      <section className="card doctor-hero">
        <DoctorAvatar size="large" />
        <div className="doctor-hero-copy">
          <span className="specialty-tag">Tim mạch</span>
          <h1>Dr. Maya Okafor</h1>
          <p>MD, FACC · Bác sĩ chuyên khoa Tim mạch</p>
          <div className="hero-facts">
            <span>
              <strong>12+</strong> Năm kinh nghiệm
            </span>
            <span>
              <strong>4.9</strong> Đánh giá của bệnh nhân
            </span>
            <span>
              <strong>1.2k</strong> Phiên khám
            </span>
          </div>
        </div>
        <Button icon="calendar" onClick={() => go("booking")}>
          Đặt lịch khám
        </Button>
      </section>
      <div className="detail-grid">
        <div className="detail-main">
          <section className="card content-card">
            <h2>Giới thiệu bác sĩ Okafor</h2>
            <p>
              Bác sĩ Maya Okafor là bác sĩ tim mạch được cấp chứng nhận chuyên khoa, tập trung vào
              tim mạch dự phòng, kiểm soát tăng huyết áp và các rối loạn nhịp tim. Bác sĩ được đánh
              giá cao nhờ phương pháp chăm sóc chu đáo, dựa trên bằng chứng và giao tiếp rõ ràng.
            </p>
          </section>
          <section className="card content-card">
            <h2>Thông tin chuyên môn</h2>
            <div className="info-rows">
              <div>
                <Icon name="stethoscope" />
                <span>
                  <small>Chuyên môn</small>
                  <strong>Tim mạch và chăm sóc tim mạch dự phòng</strong>
                </span>
              </div>
              <div>
                <Icon name="building" />
                <span>
                  <small>Phòng khám</small>
                  <strong>TiTiMi Medical Centre, Central Campus</strong>
                </span>
              </div>
              <div>
                <Icon name="file" />
                <span>
                  <small>Ngôn ngữ</small>
                  <strong>Tiếng Anh, Tiếng Pháp</strong>
                </span>
              </div>
            </div>
          </section>
        </div>
        <aside className="card schedule-card">
          <h2>Lịch khám còn trống</h2>
          <p>Chọn một ngày để bắt đầu đặt lịch.</p>
          {["Hôm nay, May 22", "Friday, May 23", "Monday, May 26"].map((d, i) => (
            <button key={d} onClick={() => go("booking")}>
              <span>
                <strong>{d}</strong>
                <small>{i === 1 ? "Còn 5 khung giờ" : "Còn 3 khung giờ"}</small>
              </span>
              <Icon name="chevron" size={18} />
            </button>
          ))}
          <div className="consult-fee">
            <span>Phí khám</span>
            <strong>$85.00</strong>
          </div>
        </aside>
      </div>
    </>
  );
}

function Booking({ go, showToast }: { go: (p: Page) => void; showToast: (s: string) => void }) {
  const [step, setStep] = useState(1);
  const [type, setType] = useState("");
  const [specialty, setSpecialty] = useState("");
  const [doctor, setDoctor] = useState("");
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [doctorQuery, setDoctorQuery] = useState("");
  const specialties: { name: string; description: string; icon: IconName; available: boolean }[] = [
    {
      name: "Nội tổng quát",
      description: "Khám và chăm sóc sức khỏe tổng quát",
      icon: "stethoscope",
      available: true,
    },
    {
      name: "Tim mạch",
      description: "Chăm sóc tim và hệ tuần hoàn",
      icon: "history",
      available: true,
    },
    {
      name: "Da liễu",
      description: "Chẩn đoán và điều trị bệnh về da",
      icon: "user",
      available: true,
    },
    { name: "Nhi khoa", description: "Chăm sóc sức khỏe trẻ em", icon: "user", available: false },
    {
      name: "Tai Mũi Họng",
      description: "Điều trị tai, mũi và họng",
      icon: "activity",
      available: false,
    },
    { name: "Thần kinh", description: "Chăm sóc hệ thần kinh", icon: "activity", available: false },
    {
      name: "Cơ xương khớp",
      description: "Điều trị cơ, xương và khớp",
      icon: "history",
      available: false,
    },
  ];
  const availableDoctors = doctors.filter(
    (item) =>
      item.specialty === specialty && item.name.toLowerCase().includes(doctorQuery.toLowerCase()),
  );
  const selectedDoctor = doctors.find((item) => item.name === doctor);
  const canContinue =
    (step === 1 && Boolean(type)) ||
    (step === 2 && Boolean(specialty)) ||
    (step === 3 && Boolean(doctor)) ||
    (step === 4 && Boolean(date && time)) ||
    step === 5;
  const chooseType = (value: string) => {
    if (value !== type) {
      setSpecialty("");
      setDoctor("");
      setDate("");
      setTime("");
    }
    setType(value);
  };
  const chooseSpecialty = (value: string) => {
    if (value !== specialty) {
      setDoctor("");
      setDate("");
      setTime("");
      setDoctorQuery("");
    }
    setSpecialty(value);
  };
  const chooseDoctor = (value: string) => {
    if (value !== doctor) {
      setDate("");
      setTime("");
    }
    setDoctor(value);
  };
  const next = () => canContinue && setStep((current) => Math.min(5, current + 1));
  const back = () => (step === 1 ? go("doctors") : setStep((current) => current - 1));
  const confirm = () => {
    setStep(6);
    showToast("Đặt lịch thành công");
  };
  return (
    <>
      {step < 6 && (
        <BackButton
          onClick={back}
          label={step === 1 ? "Quay lại danh sách bác sĩ" : "Bước trước"}
        />
      )}
      <PageHeader
        title={step === 6 ? "Đặt lịch thành công" : "Đặt lịch khám"}
        description={
          step === 6
            ? "Lịch hẹn đã được thêm vào lịch của bạn."
            : "Hoàn thành 5 bước dưới đây để đặt lịch khám."
        }
      />
      <div className="booking-steps">
        {["Hình thức khám", "Chuyên khoa", "Bác sĩ", "Ngày & giờ", "Xác nhận"].map(
          (label, index) => (
            <div
              key={label}
              className={step > index + 1 ? "done" : step === index + 1 ? "active" : ""}
            >
              <span>{step > index + 1 ? <Icon name="check" size={15} /> : index + 1}</span>
              <small>{label}</small>
            </div>
          ),
        )}
      </div>
      {step === 6 ? (
        <div className="confirmation-card card">
          <div className="success-mark">
            <Icon name="check" size={36} />
          </div>
          <span className="eyebrow">ĐẶT LỊCH THÀNH CÔNG</span>
          <h2>Amara, lịch hẹn của bạn đã được xác nhận.</h2>
          <p>
            Mã lịch hẹn: <strong>TIT-250522-1042</strong>
          </p>
          <div className="confirmation-summary booking-confirmation-summary">
            <DoctorAvatar />
            <div>
              <small>Bác sĩ</small>
              <strong>{selectedDoctor?.name}</strong>
              <span>{specialty}</span>
            </div>
            <div>
              <small>Ngày và giờ</small>
              <strong>
                {date} · {time}
              </strong>
            </div>
            <div>
              <small>Hình thức khám</small>
              <strong>{type}</strong>
              <span>Trạng thái: Đã xác nhận</span>
            </div>
          </div>
          <div className="confirmation-actions">
            <Button onClick={() => go("appointments")}>Xem lịch hẹn</Button>
            <Button variant="secondary" onClick={() => go("dashboard")}>
              Quay về tổng quan
            </Button>
          </div>
        </div>
      ) : (
        <div className="booking-layout">
          <section className="card booking-panel">
            {step === 1 && (
              <>
                <h2>Chọn hình thức khám</h2>
                <p>Chọn hình thức phù hợp với nhu cầu của bạn.</p>
                <div className="type-options booking-type-options">
                  {[
                    ["building", "Khám trực tiếp", "Người bệnh đến phòng khám để gặp bác sĩ."],
                    [
                      "video",
                      "Tư vấn trực tuyến",
                      "Người bệnh tư vấn với bác sĩ qua nền tảng trực tuyến.",
                    ],
                  ].map(([icon, title, text]) => (
                    <button
                      key={title}
                      className={type === title ? "selected" : ""}
                      onClick={() => chooseType(title)}
                    >
                      <span className="type-icon">
                        <Icon name={icon as IconName} />
                      </span>
                      <span>
                        <strong>{title}</strong>
                        <small>{text}</small>
                      </span>
                      <span className="radio" />
                    </button>
                  ))}
                </div>
              </>
            )}
            {step === 2 && (
              <>
                <h2>Chọn chuyên khoa</h2>
                <p>Chọn chuyên khoa phù hợp với nhu cầu thăm khám.</p>
                <div className="specialty-grid">
                  {specialties.map((item) => (
                    <button
                      key={item.name}
                      disabled={!item.available}
                      className={specialty === item.name ? "selected" : ""}
                      onClick={() => chooseSpecialty(item.name)}
                    >
                      <span className="specialty-icon">
                        <Icon name={item.icon} />
                      </span>
                      <span>
                        <strong>{item.name}</strong>
                        <small>{item.description}</small>
                        {!item.available && <em>Sắp cập nhật</em>}
                      </span>
                      {item.available && <span className="radio" />}
                    </button>
                  ))}
                </div>
              </>
            )}
            {step === 3 && (
              <>
                <h2>Chọn bác sĩ</h2>
                <p>
                  Danh sách bác sĩ chuyên khoa {specialty} hỗ trợ {type.toLowerCase()}.
                </p>
                <label className="booking-doctor-search">
                  <Icon name="search" size={18} />
                  <input
                    value={doctorQuery}
                    onChange={(event) => setDoctorQuery(event.target.value)}
                    placeholder="Tìm bác sĩ theo tên"
                  />
                </label>
                <div className="selection-list doctor-selection-list">
                  {availableDoctors.map((item) => (
                    <button
                      key={item.name}
                      className={doctor === item.name ? "selection-row selected" : "selection-row"}
                      onClick={() => chooseDoctor(item.name)}
                    >
                      <DoctorAvatar />
                      <span>
                        <strong>{item.name}</strong>
                        <small>MD · Bác sĩ chuyên khoa {item.specialty}</small>
                      </span>
                      <span className="select-doctor-label">
                        {doctor === item.name ? "Đã chọn" : "Chọn bác sĩ"}
                      </span>
                      <span className="radio" />
                    </button>
                  ))}
                </div>
              </>
            )}
            {step === 4 && (
              <>
                <h2>Chọn ngày và giờ khám</h2>
                <p>Chỉ những ngày và khung giờ còn trống mới có thể được lựa chọn.</p>
                <div className="date-time-layout">
                  <div className="mini-calendar">
                    <div className="calendar-head">
                      <button aria-label="Tháng trước">‹</button>
                      <strong>May 2025</strong>
                      <button aria-label="Tháng sau">›</button>
                    </div>
                    <div className="calendar-grid">
                      {["S", "M", "T", "W", "T", "F", "S"].map((day, index) => (
                        <b key={`${day}-${index}`}>{day}</b>
                      ))}
                      {Array.from({ length: 31 }, (_, index) => index + 1).map((day) => {
                        const unavailable = [3, 4, 10, 11, 17, 18, 25].includes(day);
                        return (
                          <button
                            key={day}
                            disabled={unavailable}
                            className={date.endsWith(`May ${day}`) ? "selected" : ""}
                            onClick={() => {
                              setDate(`Thu, May ${day}`);
                              setTime("");
                            }}
                          >
                            {day}
                          </button>
                        );
                      })}
                    </div>
                    <div className="calendar-legend">
                      <span>
                        <i className="available" />
                        Còn trống
                      </span>
                      <span>
                        <i className="unavailable" />
                        Không khả dụng
                      </span>
                    </div>
                  </div>
                  <div className="slot-group compact-slots">
                    <h3>Khung giờ còn trống</h3>
                    {!date ? (
                      <div className="slot-placeholder">
                        <Icon name="calendar" />
                        <span>Vui lòng chọn ngày khám trước.</span>
                      </div>
                    ) : (
                      <>
                        <div className="slots">
                          {[
                            "8:30 AM",
                            "9:00 AM",
                            "9:30 AM",
                            "10:00 AM",
                            "10:30 AM",
                            "11:00 AM",
                          ].map((slot, index) => (
                            <button
                              key={slot}
                              disabled={index === 1 || index === 3}
                              className={time === slot ? "selected" : ""}
                              onClick={() => setTime(slot)}
                            >
                              {slot}
                            </button>
                          ))}
                        </div>
                        <h3>Buổi chiều</h3>
                        <div className="slots">
                          {["1:00 PM", "1:30 PM", "2:00 PM", "2:30 PM"].map((slot) => (
                            <button
                              key={slot}
                              className={time === slot ? "selected" : ""}
                              onClick={() => setTime(slot)}
                            >
                              {slot}
                            </button>
                          ))}
                        </div>
                      </>
                    )}
                  </div>
                </div>
              </>
            )}
            {step === 5 && (
              <>
                <h2>Xác nhận thông tin đặt lịch</h2>
                <p>Kiểm tra thông tin trước khi xác nhận lịch khám.</p>
                <div className="review-doctor">
                  <DoctorAvatar />
                  <div>
                    <strong>{selectedDoctor?.name}</strong>
                    <span>{specialty} · TiTiMi Medical Centre</span>
                  </div>
                </div>
                <div className="review-list booking-review-list">
                  <div>
                    <span>Hình thức khám</span>
                    <strong>{type}</strong>
                  </div>
                  <div>
                    <span>Chuyên khoa</span>
                    <strong>{specialty}</strong>
                  </div>
                  <div>
                    <span>Bác sĩ</span>
                    <strong>{selectedDoctor?.name}</strong>
                  </div>
                  <div>
                    <span>Ngày khám</span>
                    <strong>{date}, 2025</strong>
                  </div>
                  <div>
                    <span>Giờ khám</span>
                    <strong>{time}</strong>
                  </div>
                  <div>
                    <span>Phí khám</span>
                    <strong>$85.00</strong>
                  </div>
                </div>
                <div className="patient-booking-info">
                  <div className="patient-info-head">
                    <span className="quick-icon">
                      <Icon name="user" />
                    </span>
                    <div>
                      <strong>Thông tin bệnh nhân</strong>
                      <small>Tự động điền từ hồ sơ cá nhân</small>
                    </div>
                  </div>
                  <div className="patient-info-grid">
                    <span>
                      <small>Họ và tên</small>
                      <strong>Amara Johnson</strong>
                    </span>
                    <span>
                      <small>Số điện thoại</small>
                      <strong>+1 (555) 014-8290</strong>
                    </span>
                    <span>
                      <small>Ngày sinh</small>
                      <strong>August 16, 1992</strong>
                    </span>
                    <span>
                      <small>Email</small>
                      <strong>amara.johnson@example.com</strong>
                    </span>
                  </div>
                </div>
                <div className="review-note">
                  <Icon name="check" size={18} />
                  Bạn có thể quay lại các bước trước để điều chỉnh thông tin trước khi xác nhận.
                </div>
              </>
            )}
            <div className="booking-buttons">
              <Button variant="secondary" onClick={back}>
                Quay lại
              </Button>
              <Button disabled={!canContinue} onClick={step === 5 ? confirm : next}>
                {step === 5 ? "Xác nhận đặt lịch" : "Tiếp tục"}
              </Button>
            </div>
          </section>
          <aside className="card booking-summary">
            <h3>Tóm tắt lịch hẹn</h3>
            {selectedDoctor ? (
              <div className="summary-doctor">
                <DoctorAvatar size="small" />
                <span>
                  <strong>{selectedDoctor.name}</strong>
                  <small>{specialty}</small>
                </span>
              </div>
            ) : (
              <div className="summary-empty">
                <Icon name="stethoscope" />
                <span>Chưa chọn bác sĩ</span>
              </div>
            )}
            <div className="summary-lines">
              <span>
                <Icon name={type === "Tư vấn trực tuyến" ? "video" : "building"} size={18} />
                {type || "Chọn hình thức khám"}
              </span>
              <span>
                <Icon name="stethoscope" size={18} />
                {specialty || "Chọn chuyên khoa"}
              </span>
              <span>
                <Icon name="calendar" size={18} />
                {date || "Chọn ngày khám"}
              </span>
              <span>
                <Icon name="clock" size={18} />
                {time || "Chọn giờ khám"}
              </span>
            </div>
          </aside>
        </div>
      )}
    </>
  );
}

function Appointments({ go, askCancel }: { go: (p: Page) => void; askCancel: () => void }) {
  const [filter, setFilter] = useState("Tất cả");
  const tabs = [
    "Tất cả",
    "Đã xác nhận",
    "Đã tiếp nhận",
    "Đã hoàn thành",
    "Đã hủy",
    "Không đến khám",
  ];
  const rows = filter === "Tất cả" ? appointments : appointments.filter((a) => a.status === filter);
  return (
    <>
      <PageHeader
        title="Lịch hẹn của tôi"
        description="Xem và quản lý các lịch hẹn sắp tới và đã qua."
        action={
          <Button icon="plus" onClick={() => go("booking")}>
            Đặt lịch khám
          </Button>
        }
      />
      <div className="status-tabs">
        {tabs.map((t) => (
          <button key={t} className={filter === t ? "active" : ""} onClick={() => setFilter(t)}>
            {t}
            {t === "Đã xác nhận" && <span>1</span>}
          </button>
        ))}
      </div>
      {rows.length ? (
        <section className="card table-card appointments-card">
          <AppointmentTable rows={rows} onView={() => go("appointment-detail")} />
          {filter === "Đã xác nhận" && (
            <div className="cancel-row">
              <span>Bạn cần thay đổi kế hoạch?</span>
              <Button variant="danger" onClick={askCancel}>
                Hủy lịch hẹn
              </Button>
            </div>
          )}
        </section>
      ) : (
        <div className="empty-state card">
          <div className="empty-icon">
            <Icon name="calendar" size={26} />
          </div>
          <h3>Không có lịch hẹn ở trạng thái {filter.toLowerCase()}</h3>
          <p>Các lịch hẹn có trạng thái này sẽ hiển thị tại đây.</p>
          <Button variant="secondary" onClick={() => setFilter("Tất cả")}>
            Xem tất cả lịch hẹn
          </Button>
        </div>
      )}
    </>
  );
}

function AppointmentDetail({ go, askCancel }: { go: (p: Page) => void; askCancel: () => void }) {
  return (
    <>
      <BackButton onClick={() => go("appointments")} label="Quay lại lịch hẹn" />
      <PageHeader title="Chi tiết lịch hẹn" description="Mã lịch hẹn: TIT-250522-1042" />
      <div className="detail-grid">
        <section className="card content-card">
          <div className="doctor-line large">
            <DoctorAvatar size="large" />
            <div>
              <h2>Dr. Maya Okafor</h2>
              <p>Tim mạch · Bác sĩ chuyên khoa Tim mạch</p>
            </div>
            <Badge>Đã xác nhận</Badge>
          </div>
          <div className="detail-facts">
            <div>
              <Icon name="calendar" />
              <span>
                <small>Ngày khám</small>
                <strong>Thursday, May 22, 2025</strong>
              </span>
            </div>
            <div>
              <Icon name="clock" />
              <span>
                <small>Giờ khám</small>
                <strong>10:30 AM – 11:00 AM</strong>
              </span>
            </div>
            <div>
              <Icon name="building" />
              <span>
                <small>Hình thức khám</small>
                <strong>Khám trực tiếp</strong>
              </span>
            </div>
            <div>
              <Icon name="map" />
              <span>
                <small>Địa điểm</small>
                <strong>TiTiMi Medical Centre, Floor 2</strong>
              </span>
            </div>
          </div>
          <div className="visit-note">
            <h3>Trước khi đến khám</h3>
            <p>
              Vui lòng đến sớm 10 phút, mang theo giấy tờ tùy thân có ảnh còn hiệu lực và danh sách
              thuốc đang sử dụng.
            </p>
          </div>
        </section>
        <aside className="card content-card">
          <h2>Thao tác lịch hẹn</h2>
          <Button className="full-btn" onClick={() => go("doctor-detail")}>
            Xem hồ sơ bác sĩ
          </Button>
          <Button className="full-btn" variant="danger" onClick={askCancel}>
            Hủy lịch hẹn
          </Button>
          <hr />
          <small className="support-copy">
            Bạn cần hỗ trợ? Hãy liên hệ bộ phận hỗ trợ bệnh nhân TiTiMi qua số +1 (555) 018-2200.
          </small>
        </aside>
      </div>
    </>
  );
}

function Consultations({ go }: { go: (p: Page) => void }) {
  const list = [
    ["Dr. Daniel Chen", "Nội tổng quát", "May 12, 2025", "Đã hoàn thành", "Tư vấn trực tuyến"],
    ["Dr. Noah Williams", "Da liễu", "April 28, 2025", "Đã hoàn thành", "Khám trực tiếp"],
    ["Dr. Maya Okafor", "Tim mạch", "February 18, 2025", "Đã hoàn thành", "Tư vấn trực tuyến"],
  ];
  return (
    <>
      <PageHeader
        title="Phiên khám"
        description="Xem ghi chú và kết quả từ các phiên khám đã hoàn thành."
      />
      <div className="list-stack">
        {list.map((c, i) => (
          <article className="card consultation-row" key={c[2]}>
            <div className="consult-icon">
              <Icon name="chat" />
            </div>
            <div className="consult-main">
              <span className="consult-date">{c[2]}</span>
              <h3>{c[0]}</h3>
              <p>
                {c[1]} · {c[4]}
              </p>
            </div>
            <Badge tone="blue">{c[3]}</Badge>
            <Button variant="secondary" onClick={() => go("consultation-detail")}>
              Xem chi tiết
            </Button>
          </article>
        ))}
      </div>
    </>
  );
}

function ConsultationDetail({ go }: { go: (p: Page) => void }) {
  return (
    <>
      <BackButton onClick={() => go("consultations")} label="Quay lại phiên khám" />
      <PageHeader
        title="Chi tiết phiên khám"
        description="Phiên khám hoàn thành vào May 12, 2025"
      />
      <div className="record-layout">
        <section className="card record-card">
          <div className="record-head">
            <div>
              <span className="eyebrow">NỘI TỔNG QUÁT</span>
              <h2>Phiên khám theo dõi định kỳ</h2>
              <p>Dr. Daniel Chen · Tư vấn trực tuyến</p>
            </div>
            <Badge tone="blue">Đã hoàn thành</Badge>
          </div>
          <div className="record-section">
            <h3>Triệu chứng đã ghi nhận</h3>
            <p>Đau đầu từng lúc, mệt mỏi nhẹ và khó ngủ trong hai tuần vừa qua.</p>
          </div>
          <div className="record-section">
            <h3>Đánh giá và chẩn đoán</h3>
            <p>
              <strong>Đau đầu do căng thẳng</strong>
            </p>
            <p>
              Không ghi nhận triệu chứng cảnh báo nguy hiểm. Các triệu chứng phù hợp với tình trạng
              căng thẳng và rối loạn giấc ngủ.
            </p>
          </div>
          <div className="record-section">
            <h3>Ghi chú của bác sĩ</h3>
            <p>
              Đã trao đổi về việc bổ sung đủ nước, nghỉ ngơi khi sử dụng màn hình, vệ sinh giấc ngủ
              và theo dõi triệu chứng. Tái khám sau bốn tuần nếu triệu chứng kéo dài hoặc sớm hơn
              nếu trở nặng.
            </p>
          </div>
          <div className="record-section">
            <h3>Đơn thuốc liên quan</h3>
            <button className="related-link" onClick={() => go("prescription-detail")}>
              <span className="quick-icon">
                <Icon name="pill" />
              </span>
              <span>
                <strong>Paracetamol 500mg</strong>
                <small>1 thuốc · Dùng khi cần</small>
              </span>
              <Icon name="chevron" size={18} />
            </button>
          </div>
        </section>
        <aside className="card patient-mini">
          <h3>Thông tin phiên khám</h3>
          <div>
            <span>Mã tham chiếu</span>
            <strong>CON-0512-208</strong>
          </div>
          <div>
            <span>Lịch hẹn liên quan</span>
            <strong>APT-0512-932</strong>
          </div>
          <div>
            <span>Ngày khám</span>
            <strong>May 12, 2025</strong>
          </div>
          <div>
            <span>Thời lượng</span>
            <strong>28 phút</strong>
          </div>
        </aside>
      </div>
    </>
  );
}

function MedicalHistory({ go }: { go: (p: Page) => void }) {
  const records = [
    ["May 12, 2025", "Đau đầu do căng thẳng", "Dr. Daniel Chen", "Nội tổng quát"],
    ["April 28, 2025", "Viêm da tiếp xúc", "Dr. Noah Williams", "Da liễu"],
    [
      "February 18, 2025",
      "Tăng huyết áp nguyên phát — đã kiểm soát",
      "Dr. Maya Okafor",
      "Tim mạch",
    ],
    ["November 07, 2024", "Viêm mũi dị ứng theo mùa", "Dr. Daniel Chen", "Nội tổng quát"],
  ];
  return (
    <>
      <PageHeader
        title="Bệnh sử"
        description="Theo dõi hồ sơ bệnh án rõ ràng theo trình tự thời gian."
      />
      <div className="history-summary card">
        <div className="stat-icon">
          <Icon name="file" />
        </div>
        <div>
          <strong>8</strong>
          <span>Tổng số hồ sơ bệnh án</span>
        </div>
        <label>
          <Icon name="search" size={18} />
          <input placeholder="Tìm kiếm hồ sơ" />
        </label>
        <select>
          <option>Tất cả ngày</option>
          <option>2025</option>
          <option>2024</option>
        </select>
      </div>
      <div className="timeline">
        {records.map((r) => (
          <article key={r[0]}>
            <div className="timeline-dot" />
            <div className="card history-record">
              <div>
                <span className="record-date">{r[0]}</span>
                <h3>{r[1]}</h3>
                <p>
                  Các triệu chứng đã được đánh giá và kế hoạch chăm sóc được ghi nhận trong phiên
                  khám.
                </p>
                <span className="doctor-ref">
                  <Icon name="stethoscope" size={16} />
                  {r[2]} · {r[3]}
                </span>
              </div>
              <Button variant="secondary" onClick={() => go("history-detail")}>
                Xem hồ sơ
              </Button>
            </div>
          </article>
        ))}
      </div>
    </>
  );
}

function HistoryDetail({ go }: { go: (p: Page) => void }) {
  return (
    <>
      <BackButton onClick={() => go("history")} label="Quay lại bệnh sử" />
      <PageHeader title="Hồ sơ bệnh án" description="Được ghi nhận vào May 12, 2025" />
      <section className="card record-card">
        <div className="record-head">
          <div>
            <span className="eyebrow">HỒ SƠ BỆNH ÁN · MR-2025-084</span>
            <h2>Đau đầu do căng thẳng</h2>
            <p>Được ghi nhận bởi Dr. Daniel Chen, Nội tổng quát</p>
          </div>
          <Badge tone="blue">Hoàn tất</Badge>
        </div>
        <div className="patient-strip">
          <div>
            <small>Bệnh nhân</small>
            <strong>Amara Johnson</strong>
          </div>
          <div>
            <small>Ngày sinh</small>
            <strong>August 16, 1992</strong>
          </div>
          <div>
            <small>Phiên khám</small>
            <strong>CON-0512-208</strong>
          </div>
        </div>
        <div className="record-section">
          <h3>Triệu chứng</h3>
          <p>
            Đau đầu hai bên từng lúc, mệt mỏi nhẹ và khó ngủ trong khoảng hai tuần. Không ghi nhận
            thay đổi thị lực, buồn nôn hoặc triệu chứng thần kinh.
          </p>
        </div>
        <div className="record-section">
          <h3>Chẩn đoán</h3>
          <p>
            <strong>Đau đầu do căng thẳng, từng đợt</strong>
          </p>
        </div>
        <div className="record-section">
          <h3>Ghi chú lâm sàng</h3>
          <p>
            Bệnh nhân có thể trạng ổn định. Đã trao đổi về việc bổ sung đủ nước, điều chỉnh tư thế
            làm việc, vệ sinh giấc ngủ và sử dụng thuốc giảm đau không kê đơn phù hợp. Đã hướng dẫn
            các dấu hiệu cần lưu ý.
          </p>
        </div>
      </section>
    </>
  );
}

function Prescriptions({ go }: { go: (p: Page) => void }) {
  const rx = [
    ["May 12, 2025", "Dr. Daniel Chen", "1 thuốc", "Đang sử dụng"],
    ["April 28, 2025", "Dr. Noah Williams", "2 thuốc", "Đã hoàn thành"],
    ["February 18, 2025", "Dr. Maya Okafor", "1 thuốc", "Đang sử dụng"],
  ];
  return (
    <>
      <PageHeader
        title="Đơn thuốc"
        description="Xem hướng dẫn sử dụng thuốc từ đội ngũ chăm sóc."
      />
      <div className="prescription-grid">
        {rx.map((r, i) => (
          <article className="card rx-card" key={r[0]}>
            <div className="rx-top">
              <span className="rx-icon">
                <Icon name="pill" />
              </span>
              <Badge tone={r[3] === "Đang sử dụng" ? "green" : "gray"}>{r[3]}</Badge>
            </div>
            <span className="record-date">KÊ ĐƠN NGÀY {r[0].toUpperCase()}</span>
            <h3>
              {i === 0
                ? "Paracetamol 500mg"
                : i === 1
                  ? "Hydrocortisone & Cetirizine"
                  : "Amlodipine 5mg"}
            </h3>
            <p>{r[2]} · Phiên khám liên quan</p>
            <div className="rx-doctor">
              <Icon name="stethoscope" size={17} />
              {r[1]}
            </div>
            <Button variant="secondary" onClick={() => go("prescription-detail")}>
              Xem chi tiết
            </Button>
          </article>
        ))}
      </div>
    </>
  );
}

function PrescriptionDetail({ go }: { go: (p: Page) => void }) {
  return (
    <>
      <BackButton onClick={() => go("prescriptions")} label="Quay lại đơn thuốc" />
      <PageHeader title="Chi tiết đơn thuốc" description="Mã đơn thuốc: RX-2025-0512-18" />
      <section className="card rx-detail">
        <div className="rx-detail-head">
          <div>
            <span className="eyebrow">KÊ ĐƠN NGÀY MAY 12, 2025</span>
            <h2>Đơn thuốc điều trị</h2>
            <p>Kê bởi Dr. Daniel Chen · Nội tổng quát</p>
          </div>
          <Badge>Đang sử dụng</Badge>
        </div>
        <div className="med-table">
          <div className="med-head">
            <span>Thuốc</span>
            <span>Liều lượng</span>
            <span>Tần suất sử dụng</span>
            <span>Thời gian sử dụng</span>
          </div>
          <div className="med-row">
            <span>
              <strong>Paracetamol</strong>
              <small>Viên nén 500 mg</small>
            </span>
            <strong>1 viên</strong>
            <strong>Mỗi 6–8 giờ khi cần</strong>
            <strong>Tối đa 5 ngày</strong>
          </div>
        </div>
        <div className="instruction-box">
          <h3>Hướng dẫn sử dụng</h3>
          <p>
            Uống với nước sau bữa ăn khi cần giảm đau đầu. Không dùng quá 4.000 mg trong 24 giờ.
            Ngừng thuốc và liên hệ đội ngũ chăm sóc nếu triệu chứng trở nặng hoặc kéo dài.
          </p>
        </div>
        <div className="safety-note">
          <strong>Lưu ý:</strong> Hãy làm theo hướng dẫn của bác sĩ. Thông tin trên cổng thông tin
          này không thay thế tư vấn y tế từ đội ngũ chăm sóc của bạn.
        </div>
      </section>
    </>
  );
}

function Profile({ showToast }: { showToast: (s: string) => void }) {
  const [editing, setEditing] = useState(false);
  const [saved, setSaved] = useState(false);
  const [form, setForm] = useState({
    name: "Amara Johnson",
    username: "amara.j",
    email: "amara.johnson@example.com",
    phone: "+1 (555) 014-8290",
    dob: "1992-08-16",
    gender: "Nữ",
    address: "184 Willow Street, Brookfield, NY 11220",
  });
  const submit = (e: FormEvent) => {
    e.preventDefault();
    setEditing(false);
    setSaved(true);
    showToast("Đã lưu thay đổi hồ sơ");
  };
  return (
    <>
      <PageHeader
        title="Hồ sơ cá nhân"
        description="Xem và cập nhật thông tin cá nhân của bạn."
        action={
          !editing ? (
            <Button
              icon="edit"
              onClick={() => {
                setEditing(true);
                setSaved(false);
              }}
            >
              Chỉnh sửa hồ sơ
            </Button>
          ) : undefined
        }
      />
      {saved && (
        <div className="inline-success">
          <Icon name="check" size={19} />
          <div>
            <strong>Hồ sơ đã cập nhật</strong>
            <span>Các thay đổi của bạn đã được lưu thành công.</span>
          </div>
          <button onClick={() => setSaved(false)}>
            <Icon name="close" size={18} />
          </button>
        </div>
      )}
      <div className="profile-layout">
        <aside className="card profile-card">
          <div className="profile-avatar">AJ</div>
          <h2>{form.name}</h2>
          <p>Bệnh nhân</p>
          <span className="patient-id">Mã bệnh nhân · PT-10482</span>
          <div className="profile-contact">
            <span>
              <Icon name="mail" size={17} />
              {form.email}
            </span>
            <span>
              <Icon name="phone" size={17} />
              {form.phone}
            </span>
            <span>
              <Icon name="map" size={17} />
              Brookfield, New York
            </span>
          </div>
        </aside>
        <form className="card profile-form" onSubmit={submit}>
          <div className="profile-form-head">
            <div>
              <h2>Thông tin cá nhân</h2>
              <p>
                {editing
                  ? "Cập nhật các trường bên dưới, sau đó lưu thay đổi."
                  : "Thông tin bệnh nhân đã đăng ký của bạn."}
              </p>
            </div>
            {editing && <Badge tone="amber">Đang chỉnh sửa</Badge>}
          </div>
          <div className="form-grid">
            <label>
              <span>Họ và tên</span>
              <input
                disabled={!editing}
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
              />
            </label>
            <label>
              <span>Tên đăng nhập</span>
              <input
                disabled={!editing}
                value={form.username}
                onChange={(e) => setForm({ ...form, username: e.target.value })}
              />
            </label>
            <label>
              <span>Địa chỉ email</span>
              <input
                type="email"
                disabled={!editing}
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
              />
            </label>
            <label>
              <span>Số điện thoại</span>
              <input
                disabled={!editing}
                value={form.phone}
                onChange={(e) => setForm({ ...form, phone: e.target.value })}
              />
            </label>
            <label>
              <span>Ngày sinh</span>
              <input
                type="date"
                disabled={!editing}
                value={form.dob}
                onChange={(e) => setForm({ ...form, dob: e.target.value })}
              />
            </label>
            <label>
              <span>Giới tính</span>
              <select
                disabled={!editing}
                value={form.gender}
                onChange={(e) => setForm({ ...form, gender: e.target.value })}
              >
                <option>Nữ</option>
                <option>Nam</option>
                <option>Phi nhị nguyên giới</option>
                <option>Không muốn tiết lộ</option>
              </select>
            </label>
            <label className="full-field">
              <span>Địa chỉ</span>
              <textarea
                disabled={!editing}
                value={form.address}
                onChange={(e) => setForm({ ...form, address: e.target.value })}
              />
            </label>
          </div>
          {editing && (
            <div className="form-actions">
              <Button variant="secondary" onClick={() => setEditing(false)}>
                Hủy
              </Button>
              <Button type="submit">Lưu thay đổi</Button>
            </div>
          )}
        </form>
      </div>
    </>
  );
}

export default function App() {
  const [page, setPage] = useState<Page>("dashboard");
  const [mobileOpen, setMobileOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [noticeOpen, setNoticeOpen] = useState(false);
  const [cancelOpen, setCancelOpen] = useState(false);
  const [toast, setToast] = useState("");
  const go = (p: Page) => {
    setPage(p);
    setMobileOpen(false);
    setProfileOpen(false);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };
  const showToast = (message: string) => {
    setToast(message);
    window.setTimeout(() => setToast(""), 3500);
  };
  const currentNav =
    page.includes("doctor") || page === "booking"
      ? "doctors"
      : page.includes("appointment")
        ? "appointments"
        : page.includes("consultation")
          ? "consultations"
          : page.includes("history")
            ? "history"
            : page.includes("prescription")
              ? "prescriptions"
              : page;
  return (
    <div className="app-shell">
      <aside className={`sidebar ${mobileOpen ? "open" : ""}`}>
        <div className="brand">
          <img className="brand-logo" src={titimiLogo} alt="TiTiMi" />
          <div>
            <strong>TiTiMi</strong>
            <small>PHÒNG KHÁM & Y TẾ TỪ XA</small>
          </div>
          <button
            className="mobile-close"
            onClick={() => setMobileOpen(false)}
            aria-label="Đóng menu"
          >
            <Icon name="close" />
          </button>
        </div>
        <nav>
          <span className="nav-label">CỔNG THÔNG TIN BỆNH NHÂN</span>
          {navItems.map((item) => (
            <button
              key={item.id}
              className={currentNav === item.id ? "active" : ""}
              onClick={() => go(item.id)}
            >
              <Icon name={item.icon} />
              <span>{item.label}</span>
              {currentNav === item.id && <i />}
            </button>
          ))}
        </nav>
        <div className="sidebar-help">
          <div className="help-icon">
            <Icon name="chat" />
          </div>
          <strong>Bạn cần hỗ trợ?</strong>
          <p>Đội ngũ hỗ trợ bệnh nhân luôn sẵn sàng giúp đỡ.</p>
          <button>Liên hệ hỗ trợ</button>
        </div>
        <button className="sidebar-logout">
          <Icon name="logout" />
          <span>Đăng xuất</span>
        </button>
      </aside>
      {mobileOpen && (
        <button
          className="scrim"
          onClick={() => setMobileOpen(false)}
          aria-label="Đóng điều hướng"
        />
      )}
      <div className="main-shell">
        <header className="topbar">
          <button
            className="menu-button"
            onClick={() => setMobileOpen(true)}
            aria-label="Mở điều hướng"
          >
            <Icon name="menu" />
          </button>
          <div className="breadcrumb">
            <span>Cổng thông tin bệnh nhân</span>
            <Icon name="chevron" size={14} />
            <strong>{pageTitles[page]}</strong>
          </div>
          <div className="top-actions">
            <button
              className="notification-button"
              onClick={() => setNoticeOpen(!noticeOpen)}
              aria-label="Thông báo"
            >
              <Icon name="bell" />
              <span />
            </button>
            <button className="user-button" onClick={() => setProfileOpen(!profileOpen)}>
              <span className="avatar">AJ</span>
              <span className="user-copy">
                <strong>Amara Johnson</strong>
                <small>Bệnh nhân</small>
              </span>
              <Icon name="chevron" size={15} />
            </button>
          </div>
          {noticeOpen && (
            <div className="popover notifications">
              <div>
                <h3>Thông báo</h3>
                <button onClick={() => setNoticeOpen(false)}>Đánh dấu đã đọc</button>
              </div>
              <article>
                <span className="notice-icon">
                  <Icon name="calendar" size={18} />
                </span>
                <p>
                  <strong>Lịch hẹn ngày mai</strong>Lịch khám với bác sĩ Maya Okafor diễn ra lúc
                  10:30 AM.
                </p>
              </article>
              <article>
                <span className="notice-icon">
                  <Icon name="pill" size={18} />
                </span>
                <p>
                  <strong>Đã thêm đơn thuốc</strong>Một đơn thuốc mới đã sẵn sàng để xem.
                </p>
              </article>
            </div>
          )}
          {profileOpen && (
            <div className="popover profile-menu">
              <button onClick={() => go("profile")}>
                <Icon name="user" size={18} />
                Xem hồ sơ
              </button>
              <button>
                <Icon name="logout" size={18} />
                Đăng xuất
              </button>
            </div>
          )}
        </header>
        <main className="main-content">
          {page === "dashboard" && <Dashboard go={go} />}
          {page === "doctors" && <FindDoctors go={go} />}
          {page === "doctor-detail" && <DoctorDetail go={go} />}
          {page === "booking" && <Booking go={go} showToast={showToast} />}
          {page === "appointments" && (
            <Appointments go={go} askCancel={() => setCancelOpen(true)} />
          )}
          {page === "appointment-detail" && (
            <AppointmentDetail go={go} askCancel={() => setCancelOpen(true)} />
          )}
          {page === "consultations" && <Consultations go={go} />}
          {page === "consultation-detail" && <ConsultationDetail go={go} />}
          {page === "history" && <MedicalHistory go={go} />}
          {page === "history-detail" && <HistoryDetail go={go} />}
          {page === "prescriptions" && <Prescriptions go={go} />}
          {page === "prescription-detail" && <PrescriptionDetail go={go} />}
          {page === "profile" && <Profile showToast={showToast} />}
        </main>
        <nav className="mobile-tabs">
          {navItems.slice(0, 4).map((item) => (
            <button
              key={item.id}
              className={currentNav === item.id ? "active" : ""}
              onClick={() => go(item.id)}
            >
              <Icon name={item.icon} />
              <small>{item.label.replace("My ", "")}</small>
            </button>
          ))}
          <button onClick={() => setMobileOpen(true)}>
            <Icon name="menu" />
            <small>Thêm</small>
          </button>
        </nav>
      </div>
      {cancelOpen && (
        <div className="modal-layer">
          <button className="modal-scrim" onClick={() => setCancelOpen(false)} />
          <div className="modal">
            <div className="modal-icon">
              <Icon name="calendar" />
            </div>
            <h2>Hủy lịch hẹn này?</h2>
            <p>
              Lịch hẹn với bác sĩ Maya Okafor vào May 22 lúc 10:30 AM sẽ bị hủy. Bạn không thể hoàn
              tác hành động này.
            </p>
            <div>
              <Button variant="secondary" onClick={() => setCancelOpen(false)}>
                Giữ lịch hẹn
              </Button>
              <Button
                variant="danger"
                onClick={() => {
                  setCancelOpen(false);
                  showToast("Đã hủy lịch hẹn");
                }}
              >
                Có, hủy lịch
              </Button>
            </div>
          </div>
        </div>
      )}
      {toast && (
        <div className="toast">
          <span>
            <Icon name="check" size={18} />
          </span>
          <div>
            <strong>{toast}</strong>
            <small>Tài khoản TiTiMi của bạn đã được cập nhật.</small>
          </div>
          <button onClick={() => setToast("")}>
            <Icon name="close" size={17} />
          </button>
        </div>
      )}
    </div>
  );
}
